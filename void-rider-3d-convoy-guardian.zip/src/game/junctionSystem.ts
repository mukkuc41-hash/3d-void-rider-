import * as THREE from 'three';
import { TrackId, AIDifficulty, AIPersonality } from '../types';
import { CosmicTrack, SamplePoint } from './trackData';
import {
  TrackGraph,
  TrackSegment,
  RouteAwareCheckpoint,
  TrackGraphValidationResult,
  validateTrackGraph as validateGraphUtil,
  TrackManager,
  TrackGenerator,
  RespawnManager,
} from './trackGraph';

export type {
  TrackSegment,
  RouteAwareCheckpoint,
  TrackGraphValidationResult,
  SamplePoint,
};

export {
  TrackGraph,
  validateGraphUtil as validateTrackGraph,
  TrackManager,
  TrackGenerator,
  RespawnManager,
};

export type BranchRouteDirection = 'LEFT' | 'RIGHT' | 'CENTER' | 'SHORTCUT';

export interface BranchRouteConfig {
  id: string;
  name: string;
  direction: BranchRouteDirection;
  subtitle: string;
  detail: string;
  themeColor: string;
  isShortcut: boolean;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
  hasBoostPads: boolean;
  boostPadFractions?: number[];
  hasObstacles: boolean;
  obstacleFractions?: number[];
  lengthMultiplier: number;
  width: number;
  lateralDivergence: number; // Max peak lateral offset from main track
  elevationOffset?: number; // Optional 3D flyover or dive
  requiredCheckpointIndices: number[]; // Checkpoints satisfied along this branch
  // Tactical telemetry and route-aware progress metadata
  entryJunctionId?: string;
  exitSegmentId?: string;
  requiredCheckpoints?: string[];
  difficulty?: 'EASY' | 'MEDIUM' | 'HARD' | 'EXTREME';
  hasShortcut?: boolean;
  description?: string;
  boostPadCount?: number;
  obstacleCount?: number;
  /** Mode 21/Submode 10 only: keep route endpoints physically separated. */
  terminalLateralOffset?: number;
  terminalElevationOffset?: number;
  terminalForwardExtension?: number;
  terminalRoute?: boolean;
  /** Optional normalized capture point for a physical terminal gate (0..1). */
  terminalCaptureFraction?: number;
}

export interface JunctionZoneConfig {
  id: string;
  name: string;
  trackId: TrackId;
  approachT: number;      // Spline T where HUD prompt appears (~120m out)
  junctionStartT: number; // Spline T where road splits
  junctionEndT: number;   // Spline T used as the base/end anchor; terminal routes may end separately
  routes: BranchRouteConfig[];
  defaultRouteId: string;
  bannerText: string;
}

export interface ActiveJunctionTelemetry {
  junctionId: string;
  junctionName: string;
  distanceToJunctionMeters: number;
  availableRoutes: BranchRouteConfig[];
  selectedRouteId: string | null;
  selectedRouteDirection: BranchRouteDirection | null;
  statusMessage: string | null;
  isInJunction: boolean;
  progressInRoute: number;
  bannerText: string;
  // Enhanced attributes for HUD & Mobile Controls
  isApproaching: boolean;
  distanceToJunction: number;
  name: string;
  timeRemainingSec: number;
  playerInBranch: boolean;
  branchProgress: number;
  status: 'APPROACHING' | 'COMMITMENT_ZONE' | 'ACTIVE' | 'PASSED';
  isLocked?: boolean;
}

export interface PlayerRouteProgress {
  isInBranch: boolean;
  activeJunctionId: string | null;
  activeRouteId: string | null;
  progress: number; // 0 to 1 along branch curve
  transitionBlend: number; // 0 to 1 smooth entry blend
  branchRouteInstance: BranchRouteInstance | null;
  entrySpeed: number;
  validatedCheckpointIndices: Set<number>;
}

export class BranchRouteInstance {
  public config: BranchRouteConfig;
  public curve: THREE.CatmullRomCurve3;
  public totalLength: number;
  public samples: SamplePoint[] = [];
  public meshGroup: THREE.Group = new THREE.Group();
  public boostPadPositions: THREE.Vector3[] = [];
  public obstaclePositions: THREE.Vector3[] = [];

  constructor(
    config: BranchRouteConfig,
    mainTrack: CosmicTrack,
    startT: number,
    endT: number
  ) {
    this.config = config;

    // Generate a smooth 3D Catmull-Rom route. Normal branches return to the
    // main-track anchor. Submode 10 terminal routes deliberately continue
    // past that anchor and finish at physically separated endpoints.
    const controlPoints: THREE.Vector3[] = [];
    const numPoints = 10;
    const isWrapping = endT < startT;
    const effectiveEndT = isWrapping ? endT + 1.0 : endT;
    const terminalLat = config.terminalLateralOffset || 0;
    const terminalElev = config.terminalElevationOffset || 0;
    const terminalExtension = config.terminalForwardExtension || 0;

    for (let i = 0; i <= numPoints; i++) {
      const frac = i / numPoints;
      const rawT = startT + frac * (effectiveEndT - startT);
      const wrappedT = ((rawT % 1.0) + 1.0) % 1.0;
      const mainSample = mainTrack.getSampleAt(wrappedT);

      // Arc opens the route away from the main track, while terminal offsets
      // keep dedicated Submode-10 endings separated instead of rejoining.
      const arcFactor = Math.sin(frac * Math.PI);
      const lateralOff = config.lateralDivergence * arcFactor + terminalLat * frac;
      const elevOff = (config.elevationOffset || 0) * arcFactor + terminalElev * frac;
      const forwardOff = terminalExtension * Math.pow(frac, 2);

      const pt = mainSample.point
        .clone()
        .add(mainSample.binormal.clone().multiplyScalar(lateralOff))
        .add(mainSample.normal.clone().multiplyScalar(elevOff))
        .add(mainSample.tangent.clone().multiplyScalar(forwardOff));

      controlPoints.push(pt);
    }

    this.curve = new THREE.CatmullRomCurve3(controlPoints, false, 'centripetal');
    this.totalLength = this.curve.getLength();

    // Precompute smooth samples
    const sampleCount = 90;
    const up = new THREE.Vector3(0, 1, 0);
    for (let i = 0; i <= sampleCount; i++) {
      const t = i / sampleCount;
      const point = this.curve.getPointAt(t);
      const tangent = this.curve.getTangentAt(t).normalize();

      let binormal = new THREE.Vector3().crossVectors(tangent, up).normalize();
      if (binormal.lengthSq() < 0.01) {
        binormal.set(1, 0, 0);
      }
      const normal = new THREE.Vector3().crossVectors(binormal, tangent).normalize();

      this.samples.push({ t, point, tangent, normal, binormal });
    }

    // Generate boost pads if configured
    if (config.hasBoostPads && config.boostPadFractions) {
      config.boostPadFractions.forEach(f => {
        const pt = this.curve.getPointAt(f).add(new THREE.Vector3(0, 0.35, 0));
        this.boostPadPositions.push(pt);
      });
    }

    // Generate hazards if configured
    if (config.hasObstacles && config.obstacleFractions) {
      config.obstacleFractions.forEach(f => {
        const s = this.getSampleAt(f);
        const jitter = (Math.random() - 0.5) * (config.width * 0.4);
        const pt = s.point.clone().add(s.binormal.clone().multiplyScalar(jitter)).add(s.normal.clone().multiplyScalar(1.5));
        this.obstaclePositions.push(pt);
      });
    }

    this.buildGeometry();
  }

  public getSampleAt(t: number): SamplePoint {
    if (!this.samples || this.samples.length === 0) {
      return {
        t: 0,
        point: new THREE.Vector3(0, 0, 0),
        tangent: new THREE.Vector3(0, 0, -1),
        normal: new THREE.Vector3(0, 1, 0),
        binormal: new THREE.Vector3(1, 0, 0),
      };
    }
    const safeT = isNaN(t) || !isFinite(t) ? 0 : t;
    const clamped = Math.max(0, Math.min(1, safeT));
    const maxIdx = this.samples.length - 1;
    const rawIdx = Math.floor(clamped * maxIdx);
    const index = isNaN(rawIdx) ? 0 : Math.max(0, Math.min(maxIdx, rawIdx));
    return this.samples[index] || this.samples[0];
  }

  private buildGeometry() {
    const count = this.samples.length;
    const halfW = this.config.width / 2;
    const vertices: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];

    // Road surface mesh
    for (let i = 0; i < count; i++) {
      const s = this.samples[i];
      const left = s.point.clone().add(s.binormal.clone().multiplyScalar(-halfW));
      const right = s.point.clone().add(s.binormal.clone().multiplyScalar(halfW));

      vertices.push(left.x, left.y, left.z);
      vertices.push(right.x, right.y, right.z);

      const v = (i / (count - 1)) * 25;
      uvs.push(0, v);
      uvs.push(1, v);

      if (i < count - 1) {
        const r1 = i * 2;
        const r2 = (i + 1) * 2;
        indices.push(r1, r2, r1 + 1);
        indices.push(r1 + 1, r2, r2 + 1);
      }
    }

    const roadGeo = new THREE.BufferGeometry();
    roadGeo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    roadGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    roadGeo.setIndex(indices);
    roadGeo.computeVertexNormals();

    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x090c18,
      roughness: 0.28,
      metalness: 0.85,
    });
    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    this.meshGroup.add(roadMesh);

    // Glowing boundary edge rails in route theme color
    const leftPoints: THREE.Vector3[] = [];
    const rightPoints: THREE.Vector3[] = [];
    const centerPoints: THREE.Vector3[] = [];

    for (let i = 0; i < count; i++) {
      const s = this.samples[i];
      leftPoints.push(
        s.point.clone().add(s.binormal.clone().multiplyScalar(-halfW)).add(new THREE.Vector3(0, 0.45, 0))
      );
      rightPoints.push(
        s.point.clone().add(s.binormal.clone().multiplyScalar(halfW)).add(new THREE.Vector3(0, 0.45, 0))
      );
      centerPoints.push(
        s.point.clone().add(new THREE.Vector3(0, 0.12, 0))
      );
    }

    const themeHex = parseInt(this.config.themeColor.replace('#', '0x'), 16);
    const railMat = new THREE.MeshStandardMaterial({
      color: themeHex,
      emissive: themeHex,
      emissiveIntensity: 2.8,
      roughness: 0.15,
    });

    const leftCurve = new THREE.CatmullRomCurve3(leftPoints);
    const rightCurve = new THREE.CatmullRomCurve3(rightPoints);
    const centerCurve = new THREE.CatmullRomCurve3(centerPoints);

    const leftRail = new THREE.Mesh(new THREE.TubeGeometry(leftCurve, 80, 0.32, 8, false), railMat);
    const rightRail = new THREE.Mesh(new THREE.TubeGeometry(rightCurve, 80, 0.32, 8, false), railMat);

    // Central pulsing neon strip
    const centerRail = new THREE.Mesh(
      new THREE.TubeGeometry(centerCurve, 60, 0.14, 6, false),
      new THREE.MeshBasicMaterial({ color: themeHex })
    );

    this.meshGroup.add(leftRail, rightRail, centerRail);

    // Boost Pads on this branch
    if (this.boostPadPositions.length > 0) {
      const padGeo = new THREE.PlaneGeometry(halfW * 1.3, 5.5);
      padGeo.rotateX(-Math.PI / 2);
      const padMat = new THREE.MeshBasicMaterial({
        color: themeHex,
        transparent: true,
        opacity: 0.9,
        side: THREE.DoubleSide,
      });

      this.boostPadPositions.forEach(pos => {
        const padMesh = new THREE.Mesh(padGeo, padMat);
        padMesh.position.copy(pos);
        this.meshGroup.add(padMesh);

        // Chevron indicator mesh
        const chevronGeo = new THREE.ConeGeometry(1.2, 2.5, 4);
        chevronGeo.rotateX(-Math.PI / 2);
        const chevronMesh = new THREE.Mesh(chevronGeo, new THREE.MeshBasicMaterial({ color: 0xffffff }));
        chevronMesh.position.copy(pos).add(new THREE.Vector3(0, 0.1, 0));
        this.meshGroup.add(chevronMesh);
      });
    }
  }
}

export class JunctionZoneInstance {
  public config: JunctionZoneConfig;
  public routeInstances: Map<string, BranchRouteInstance> = new Map();
  public gantryGroup: THREE.Group = new THREE.Group();
  public holographicArrows: THREE.Group[] = [];
  public selectedRouteId: string | null = null;
  public entranceSample: SamplePoint;
  public exitSample: SamplePoint;

  constructor(config: JunctionZoneConfig, mainTrack: CosmicTrack) {
    this.config = config;
    this.entranceSample = mainTrack.getSampleAt(config.junctionStartT);
    this.exitSample = mainTrack.getSampleAt(config.junctionEndT);

    // Create Route Instances
    config.routes.forEach(routeCfg => {
      const inst = new BranchRouteInstance(
        routeCfg,
        mainTrack,
        config.junctionStartT,
        config.junctionEndT
      );
      this.routeInstances.set(routeCfg.id, inst);
    });

    this.buildGantryAndSignage(mainTrack);
  }

  private buildGantryAndSignage(mainTrack: CosmicTrack) {
    const s = this.entranceSample;
    const trackWidth = mainTrack.width;
    const halfW = trackWidth / 2;

    this.gantryGroup.position.copy(s.point);
    const rotMatrix = new THREE.Matrix4();
    rotMatrix.makeBasis(s.binormal, s.normal, s.tangent.clone().negate());
    this.gantryGroup.quaternion.setFromRotationMatrix(rotMatrix);

    // Left and Right Pylons
    const pylonGeo = new THREE.BoxGeometry(1.4, 12, 2.2);
    const pylonMat = new THREE.MeshStandardMaterial({
      color: 0x121528,
      metalness: 0.9,
      roughness: 0.25,
    });

    const leftPylon = new THREE.Mesh(pylonGeo, pylonMat);
    leftPylon.position.set(-halfW - 2.5, 6, 0);

    const rightPylon = new THREE.Mesh(pylonGeo, pylonMat);
    rightPylon.position.set(halfW + 2.5, 6, 0);

    // Overhead Gantry Crossbar
    const crossbarGeo = new THREE.BoxGeometry(trackWidth + 6.5, 1.8, 2.4);
    const crossbar = new THREE.Mesh(crossbarGeo, pylonMat);
    crossbar.position.set(0, 11, 0);

    // Holographic Signboard Banner
    const bannerGeo = new THREE.PlaneGeometry(trackWidth + 3.0, 3.2);
    const bannerCanvas = document.createElement('canvas');
    bannerCanvas.width = 1024;
    bannerCanvas.height = 256;
    const ctx = bannerCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = 'rgba(5, 10, 25, 0.92)';
      ctx.fillRect(0, 0, 1024, 256);
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 8;
      ctx.strokeRect(10, 10, 1004, 236);

      // Title & Marquee
      ctx.fillStyle = '#00f0ff';
      ctx.font = 'bold 42px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`<< JUNCTION: ${this.config.name.toUpperCase()} >>`, 512, 70);

      // Left vs Right Route Labels
      const leftRoute = this.config.routes.find(r => r.direction === 'LEFT');
      const rightRoute = this.config.routes.find(r => r.direction === 'RIGHT' || r.direction === 'SHORTCUT');

      ctx.fillStyle = leftRoute?.themeColor || '#00f0ff';
      ctx.font = 'bold 36px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`◀ [A] ${leftRoute?.name || 'LEFT PATH'}`, 40, 150);

      ctx.font = '24px monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(leftRoute?.subtitle || '', 40, 195);

      ctx.fillStyle = rightRoute?.themeColor || '#ff00aa';
      ctx.font = 'bold 36px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`${rightRoute?.name || 'RIGHT PATH'} [D] ▶`, 984, 150);

      ctx.font = '24px monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(rightRoute?.subtitle || '', 984, 195);
    }

    const bannerTexture = new THREE.CanvasTexture(bannerCanvas);
    const bannerMat = new THREE.MeshBasicMaterial({
      map: bannerTexture,
      transparent: true,
      side: THREE.DoubleSide,
    });
    const bannerMesh = new THREE.Mesh(bannerGeo, bannerMat);
    bannerMesh.position.set(0, 11, -0.6);

    // Floating Holographic Directional Chevron Arrows
    this.config.routes.forEach(route => {
      const arrowGroup = new THREE.Group();
      const themeHex = parseInt(route.themeColor.replace('#', '0x'), 16);
      const isLeft = route.direction === 'LEFT';
      const lateralPos = isLeft ? -halfW * 0.55 : halfW * 0.55;

      const arrowMat = new THREE.MeshBasicMaterial({
        color: themeHex,
        transparent: true,
        opacity: 0.88,
      });

      // 3 nested holographic arrow chevrons
      for (let c = 0; c < 3; c++) {
        const chevGeo = new THREE.ConeGeometry(1.2, 2.4, 4);
        chevGeo.rotateZ(isLeft ? Math.PI / 2 : -Math.PI / 2);
        const chev = new THREE.Mesh(chevGeo, arrowMat);
        chev.position.set(0, 0, c * 3.5);
        chev.scale.set(1.4, 1.4, 1.4);
        arrowGroup.add(chev);
      }

      arrowGroup.position.set(lateralPos, 4.5, -4);
      arrowGroup.name = `arrow_${route.id}`;
      this.holographicArrows.push(arrowGroup);
      this.gantryGroup.add(arrowGroup);
    });

    // Central lane divider neon wedge barrier on the road surface
    const wedgeGeo = new THREE.ConeGeometry(1.8, 8, 3);
    wedgeGeo.rotateX(Math.PI / 2);
    const wedgeMat = new THREE.MeshStandardMaterial({
      color: 0x00f0ff,
      emissive: 0x00f0ff,
      emissiveIntensity: 2.2,
      roughness: 0.2,
    });
    const dividerWedge = new THREE.Mesh(wedgeGeo, wedgeMat);
    dividerWedge.position.set(0, 0.8, -4);

    this.gantryGroup.add(leftPylon, rightPylon, crossbar, bannerMesh, dividerWedge);
  }

  public updateAnimation(totalTimeSec: number, selectedRouteId: string | null) {
    this.selectedRouteId = selectedRouteId;

    this.holographicArrows.forEach(arrowGroup => {
      const isSelected = arrowGroup.name === `arrow_${selectedRouteId}`;
      const pulse = 1.0 + Math.sin(totalTimeSec * 8) * 0.2;
      const baseScale = isSelected ? 1.6 * pulse : 1.1 + Math.sin(totalTimeSec * 4) * 0.1;
      arrowGroup.scale.set(baseScale, baseScale, baseScale);

      // Float bobbing
      arrowGroup.position.y = 4.5 + Math.sin(totalTimeSec * 3 + arrowGroup.position.x) * 0.4;

      // Pulse brightness
      arrowGroup.traverse(child => {
        if ((child as THREE.Mesh).isMesh && (child as THREE.Mesh).material) {
          const mat = (child as THREE.Mesh).material as THREE.MeshBasicMaterial;
          mat.opacity = isSelected ? 1.0 : 0.6 + Math.sin(totalTimeSec * 6) * 0.2;
        }
      });
    });
  }
}

// Track-Specific Junction Configurations
export const TRACK_JUNCTIONS_CONFIG: Record<TrackId, JunctionZoneConfig[]> = {
  circuit_alpha: [
    {
      id: 'alpha_junction_canyon',
      name: 'Orbital Split Canyon',
      trackId: 'circuit_alpha',
      approachT: 0.24,
      junctionStartT: 0.30,
      junctionEndT: 0.48,
      bannerText: 'ORBITAL CANYON DIVERGENCE',
      defaultRouteId: 'alpha_canyon_center',
      routes: [
        {
          id: 'alpha_canyon_left',
          name: 'CYAN BOOST FREEWAY',
          direction: 'LEFT',
          subtitle: 'Banked Ridge Slipstream',
          detail: 'Wide banked outer curve with continuous energy refill & safe cornering clearance.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.55, 0.82],
          hasObstacles: false,
          lengthMultiplier: 1.08,
          width: 15,
          lateralDivergence: -28,
          elevationOffset: 12,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'alpha_canyon_center',
          name: 'SOLAR EXPRESS HIGHWAY',
          direction: 'CENTER',
          subtitle: 'Direct Mainline (Max Speed)',
          detail: 'Direct mainline through canyon center with twin boost pads and zero divergence penalty.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'alpha_canyon_right',
          name: 'ION RIFT SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'High-Risk Subterranean Dive (-16% Distance)',
          detail: 'Extreme hairpin descent cutting through the lower chasm. Demands tight drift precision.',
          themeColor: '#ff00aa',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.45],
          hasObstacles: true,
          obstacleFractions: [0.35, 0.70],
          lengthMultiplier: 0.84,
          width: 11,
          lateralDivergence: 26,
          elevationOffset: -18,
          requiredCheckpointIndices: [3, 4],
        },
      ],
    },
    {
      id: 'alpha_junction_spire',
      name: 'Warp Plaza Divergence',
      trackId: 'circuit_alpha',
      approachT: 0.62,
      junctionStartT: 0.68,
      junctionEndT: 0.84,
      bannerText: 'WARP PLAZA JUNCTION',
      defaultRouteId: 'alpha_spire_center',
      routes: [
        {
          id: 'alpha_spire_left',
          name: 'GRAV-SLIPSTREAM RIDGE',
          direction: 'LEFT',
          subtitle: 'Panoramic Zero-G Overlook',
          detail: 'High elevation scenic ridge overlooking planetary rings with low gravity handling.',
          themeColor: '#00ffcc',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.7],
          hasObstacles: false,
          lengthMultiplier: 1.04,
          width: 14,
          lateralDivergence: -25,
          elevationOffset: 16,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'alpha_spire_center',
          name: 'WARP PLAZA DIRECT',
          direction: 'CENTER',
          subtitle: 'Central Elevated Artery',
          detail: 'Direct central elevated route crossing the plaza with balanced acceleration pads.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.60],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 6,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'alpha_spire_right',
          name: 'HYPER-CONDUIT TUNNEL',
          direction: 'RIGHT',
          subtitle: 'Speed Tunnel with Laser Barriers',
          detail: 'Enclosed speed tube with high velocity straightaways and energy pickups.',
          themeColor: '#ffaa00',
          isShortcut: false,
          riskLevel: 'MEDIUM',
          hasBoostPads: true,
          boostPadFractions: [0.2, 0.5, 0.8],
          hasObstacles: true,
          obstacleFractions: [0.4, 0.75],
          lengthMultiplier: 0.94,
          width: 12,
          lateralDivergence: 24,
          elevationOffset: -10,
          requiredCheckpointIndices: [8, 9],
        },
      ],
    },
  ],
  neon_orbit: [
    {
      id: 'neon_junction_canyon',
      name: 'Orbital Split Canyon',
      trackId: 'neon_orbit',
      approachT: 0.24,
      junctionStartT: 0.30,
      junctionEndT: 0.48,
      bannerText: 'ORBITAL CANYON DIVERGENCE',
      defaultRouteId: 'neon_canyon_center',
      routes: [
        {
          id: 'neon_canyon_left',
          name: 'CYAN BOOST FREEWAY',
          direction: 'LEFT',
          subtitle: 'Triple Boost Pad Slipstream',
          detail: 'Wide banked outer curve with continuous energy refill & safe cornering clearance.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.55, 0.82],
          hasObstacles: false,
          lengthMultiplier: 1.08,
          width: 15,
          lateralDivergence: -28,
          elevationOffset: 12,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'neon_canyon_center',
          name: 'NEON EXPRESSWAY SPINE',
          direction: 'CENTER',
          subtitle: 'High-Speed Center Lane',
          detail: 'Direct mainline through neon canyon with dual speed pads and maximum top velocity.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'neon_canyon_right',
          name: 'ION RIFT SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'High-Risk Subterranean Dive (-16% Distance)',
          detail: 'Extreme hairpin descent cutting through the lower chasm. Demands tight drift precision.',
          themeColor: '#ff00aa',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.45],
          hasObstacles: true,
          obstacleFractions: [0.35, 0.70],
          lengthMultiplier: 0.84,
          width: 11,
          lateralDivergence: 26,
          elevationOffset: -18,
          requiredCheckpointIndices: [3, 4],
        },
      ],
    },
    {
      id: 'neon_junction_spire',
      name: 'Warp Plaza Divergence',
      trackId: 'neon_orbit',
      approachT: 0.62,
      junctionStartT: 0.68,
      junctionEndT: 0.84,
      bannerText: 'WARP PLAZA JUNCTION',
      defaultRouteId: 'neon_spire_center',
      routes: [
        {
          id: 'neon_spire_left',
          name: 'GRAV-SLIPSTREAM RIDGE',
          direction: 'LEFT',
          subtitle: 'Panoramic Zero-G Overlook',
          detail: 'High elevation scenic ridge overlooking planetary rings with low gravity handling.',
          themeColor: '#00ffcc',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.7],
          hasObstacles: false,
          lengthMultiplier: 1.04,
          width: 14,
          lateralDivergence: -25,
          elevationOffset: 16,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'neon_spire_center',
          name: 'PLAZA MERIDIAN CORE',
          direction: 'CENTER',
          subtitle: 'Direct Center Speed Conduit',
          detail: 'Central plaza bypass with magnetic acceleration strips and zero-drag clearance.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.60],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 6,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'neon_spire_right',
          name: 'HYPER-CONDUIT TUNNEL',
          direction: 'RIGHT',
          subtitle: 'Speed Tunnel with Laser Barriers',
          detail: 'Enclosed speed tube with high velocity straightaways and energy pickups.',
          themeColor: '#ffaa00',
          isShortcut: false,
          riskLevel: 'MEDIUM',
          hasBoostPads: true,
          boostPadFractions: [0.2, 0.5, 0.8],
          hasObstacles: true,
          obstacleFractions: [0.4, 0.75],
          lengthMultiplier: 0.94,
          width: 12,
          lateralDivergence: 24,
          elevationOffset: -10,
          requiredCheckpointIndices: [8, 9],
        },
      ],
    },
  ],
  asteroid_run: [
    {
      id: 'asteroid_junction_ore',
      name: 'Ore Processor Fork',
      trackId: 'asteroid_run',
      approachT: 0.20,
      junctionStartT: 0.26,
      junctionEndT: 0.44,
      bannerText: 'MINING ZONE SEPARATION',
      defaultRouteId: 'asteroid_ore_center',
      routes: [
        {
          id: 'asteroid_ore_left',
          name: 'BOULDER CHUTE SHORTCUT',
          direction: 'LEFT',
          subtitle: 'Extreme Kinetic Hazard Alley (-18% Time)',
          detail: 'Cuts straight through drilling core. Dense tumbling boulders require active beam fire!',
          themeColor: '#ff3300',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.65],
          hasObstacles: true,
          obstacleFractions: [0.25, 0.45, 0.7],
          lengthMultiplier: 0.82,
          width: 11,
          lateralDivergence: -26,
          elevationOffset: -14,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'asteroid_ore_center',
          name: 'CORE EXCAVATION HIGHWAY',
          direction: 'CENTER',
          subtitle: 'Shielded Industrial Central Conduit',
          detail: 'Reinforced central bridge bypassing mining machinery with continuous kinetic shields.',
          themeColor: '#00e5ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 15,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'asteroid_ore_right',
          name: 'MINING CRANEWAY',
          direction: 'RIGHT',
          subtitle: 'Shielded Industrial Highway',
          detail: 'Broad illuminated catwalk past ore freighters with repair cores and clear radar.',
          themeColor: '#ffaa00',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.35, 0.75],
          hasObstacles: false,
          lengthMultiplier: 1.05,
          width: 16,
          lateralDivergence: 25,
          elevationOffset: 10,
          requiredCheckpointIndices: [3, 4],
        },
      ],
    },
    {
      id: 'asteroid_junction_belt',
      name: 'Debris Field Divergence',
      trackId: 'asteroid_run',
      approachT: 0.60,
      junctionStartT: 0.66,
      junctionEndT: 0.82,
      bannerText: 'DEBRIS BELT FORK',
      defaultRouteId: 'asteroid_belt_center',
      routes: [
        {
          id: 'asteroid_belt_left',
          name: 'MAGNETIC TRACTOR CONDUIT',
          direction: 'LEFT',
          subtitle: 'Automated Magnetic Slipstream',
          detail: 'Tractor beam field stabilizes ship drift and accelerates speed by +25%.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.2, 0.5, 0.8],
          hasObstacles: false,
          lengthMultiplier: 1.02,
          width: 14,
          lateralDivergence: -24,
          elevationOffset: 8,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'asteroid_belt_center',
          name: 'DEBRIS VECTOR ARTERY',
          direction: 'CENTER',
          subtitle: 'Stabilized Center Flight Corridor',
          detail: 'Central magnetic lane through the asteroid ring with balanced boost pads and zero divergence.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'asteroid_belt_right',
          name: 'CAVERN CREVICE SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'Crystalline Chasm (-14% Distance)',
          detail: 'Narrow cavern cleft filled with valuable ion credits and tight banking turns.',
          themeColor: '#d000ff',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.4],
          hasObstacles: true,
          obstacleFractions: [0.3, 0.6],
          lengthMultiplier: 0.86,
          width: 10.5,
          lateralDivergence: 22,
          elevationOffset: -12,
          requiredCheckpointIndices: [8, 9],
        },
      ],
    },
  ],
  void_rift: [
    {
      id: 'void_junction_singularity',
      name: 'Singularity Separation',
      trackId: 'void_rift',
      approachT: 0.22,
      junctionStartT: 0.28,
      junctionEndT: 0.46,
      bannerText: 'SINGULARITY SPLIT MATRIX',
      defaultRouteId: 'void_singularity_center',
      routes: [
        {
          id: 'void_singularity_left',
          name: 'DARK MATTER RUNWAY',
          direction: 'LEFT',
          subtitle: 'Inverted Grav-Loop Corridor',
          detail: 'Anti-gravity inversion rail providing superior centrifugal traction and boost pads.',
          themeColor: '#9d4edd',
          isShortcut: false,
          riskLevel: 'MEDIUM',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.6, 0.85],
          hasObstacles: false,
          lengthMultiplier: 1.05,
          width: 14,
          lateralDivergence: -28,
          elevationOffset: 20,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'void_singularity_center',
          name: 'GRAVITON BEAM MERIDIAN',
          direction: 'CENTER',
          subtitle: 'High-Velocity Central Axis',
          detail: 'Central anti-grav beam through singularity rift offering straight-line speed stability.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'void_singularity_right',
          name: 'WORMHOLE GRAV-SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'Event Horizon Dive (-17% Time)',
          detail: 'Flirts with the dimensional singularity horizon. Highest risk, supersonic warp speeds.',
          themeColor: '#ff0055',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.5],
          hasObstacles: true,
          obstacleFractions: [0.35, 0.65],
          lengthMultiplier: 0.83,
          width: 11,
          lateralDivergence: 25,
          elevationOffset: -22,
          requiredCheckpointIndices: [3, 4],
        },
      ],
    },
    {
      id: 'void_junction_abyss',
      name: 'Abyss Elevation Junction',
      trackId: 'void_rift',
      approachT: 0.64,
      junctionStartT: 0.70,
      junctionEndT: 0.86,
      bannerText: 'ABYSS ELEVATION FORK',
      defaultRouteId: 'void_abyss_center',
      routes: [
        {
          id: 'void_abyss_left',
          name: 'CRYSTAL SPIRE CLIMB',
          direction: 'LEFT',
          subtitle: 'Technical S-Curve Spire',
          detail: 'Spiral corkscrew climbing around glowing dark energy spires.',
          themeColor: '#00e5ff',
          isShortcut: false,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.4, 0.8],
          hasObstacles: true,
          obstacleFractions: [0.3, 0.6],
          lengthMultiplier: 0.95,
          width: 12,
          lateralDivergence: -24,
          elevationOffset: 24,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'void_abyss_center',
          name: 'VOID RUNNER ARTERY',
          direction: 'CENTER',
          subtitle: 'Direct Chasm Skyway',
          detail: 'Direct highway straight over the abyss with balanced boost recharge stations.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 6,
          requiredCheckpointIndices: [8, 9],
        },
        {
          id: 'void_abyss_right',
          name: 'SUB-VOID GLIDEWAY',
          direction: 'RIGHT',
          subtitle: 'Wide Safe Glide Path',
          detail: 'Smooth stable highway bypassing the turbulence with continuous magnetic guidance.',
          themeColor: '#39ff14',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.04,
          width: 16,
          lateralDivergence: 26,
          elevationOffset: 6,
          requiredCheckpointIndices: [8, 9],
        },
      ],
    },
  ],
  nebula_rift: [
    {
      id: 'nebula_junction_warp',
      name: 'Nebula Stream Split',
      trackId: 'nebula_rift',
      approachT: 0.24,
      junctionStartT: 0.30,
      junctionEndT: 0.48,
      bannerText: 'NEBULA STREAM FORK',
      defaultRouteId: 'nebula_warp_center',
      routes: [
        {
          id: 'nebula_warp_left',
          name: 'ION NEBULA RUNWAY',
          direction: 'LEFT',
          subtitle: 'High-Density Plasma Slipstream',
          detail: 'Electric violet ion cloud providing hyper-boost energy replenishment.',
          themeColor: '#d000ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.55, 0.8],
          hasObstacles: false,
          lengthMultiplier: 1.06,
          width: 15,
          lateralDivergence: -26,
          elevationOffset: 12,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'nebula_warp_center',
          name: 'PLASMA HIGHWAY SPINE',
          direction: 'CENTER',
          subtitle: 'Direct Ion Center Expressway',
          detail: 'Center ionization corridor through glowing nebula with twin plasma boost rings.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'nebula_warp_right',
          name: 'MEGABRIDGE SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'Broken Megastructure Chord (-15% Distance)',
          detail: 'Shattered orbital bridge requiring precision thruster alignment across gaps.',
          themeColor: '#ff0055',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.45],
          hasObstacles: true,
          obstacleFractions: [0.3, 0.7],
          lengthMultiplier: 0.85,
          width: 11,
          lateralDivergence: 24,
          elevationOffset: -14,
          requiredCheckpointIndices: [3, 4],
        },
      ],
    },
  ],
  cosmic_ring: [
    {
      id: 'ring_junction_solar',
      name: 'Solar Accelerator Split',
      trackId: 'cosmic_ring',
      approachT: 0.28,
      junctionStartT: 0.34,
      junctionEndT: 0.52,
      bannerText: 'SOLAR ACCELERATOR FORK',
      defaultRouteId: 'ring_solar_center',
      routes: [
        {
          id: 'ring_solar_left',
          name: 'INNER CORONA ACCELERATOR',
          direction: 'LEFT',
          subtitle: 'Supercharged Boost Corridor',
          detail: 'Short radius orbital cut with 4 successive hypersonic boost rings.',
          themeColor: '#ffaa00',
          isShortcut: false,
          riskLevel: 'MEDIUM',
          hasBoostPads: true,
          boostPadFractions: [0.15, 0.38, 0.62, 0.85],
          hasObstacles: false,
          lengthMultiplier: 0.88,
          width: 13,
          lateralDivergence: -28,
          elevationOffset: 8,
          requiredCheckpointIndices: [4, 5],
        },
        {
          id: 'ring_solar_center',
          name: 'SOLAR EQUATOR LINE',
          direction: 'CENTER',
          subtitle: 'Direct Central Orbital Path',
          detail: 'Equatorial orbital track offering maximum speed retention and balanced clearance.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.60],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [4, 5],
        },
        {
          id: 'ring_solar_right',
          name: 'OUTER MEGARING ARCS',
          direction: 'RIGHT',
          subtitle: 'High-G Banked Megastructure',
          detail: 'Enormous outer ring curve offering maximum drift points and wide clearance.',
          themeColor: '#00ffcc',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.7],
          hasObstacles: false,
          lengthMultiplier: 1.10,
          width: 17,
          lateralDivergence: 28,
          elevationOffset: 12,
          requiredCheckpointIndices: [4, 5],
        },
      ],
    },
    {
      id: 'ring_junction_corona',
      name: 'Corona Chasm Fork',
      trackId: 'cosmic_ring',
      approachT: 0.65,
      junctionStartT: 0.70,
      junctionEndT: 0.84,
      bannerText: 'CORONA CHASM DIVERGENCE',
      defaultRouteId: 'ring_corona_center',
      routes: [
        {
          id: 'ring_corona_left',
          name: 'HEAT SHIELD SKYWAY',
          direction: 'LEFT',
          subtitle: 'Protected Orbital Overpass',
          detail: 'Shielded titanium gantry protected from solar radiation surges.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.7],
          hasObstacles: false,
          lengthMultiplier: 1.05,
          width: 15,
          lateralDivergence: -26,
          elevationOffset: 16,
          requiredCheckpointIndices: [9, 10],
        },
        {
          id: 'ring_corona_center',
          name: 'PULSAR RUNWAY ARTERY',
          direction: 'CENTER',
          subtitle: 'Central Magnetic Highway',
          detail: 'Direct central magnetic highway with double boost acceleration pads.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.35, 0.75],
          hasObstacles: false,
          lengthMultiplier: 1.0,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [9, 10],
        },
        {
          id: 'ring_corona_right',
          name: 'FLARE CONDUIT SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'Dangerous Flare Crevice (-16% Distance)',
          detail: 'Cuts straight through the solar flare exhaust chute. High risk, extreme acceleration.',
          themeColor: '#ff5500',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.45],
          hasObstacles: true,
          obstacleFractions: [0.3, 0.65],
          lengthMultiplier: 0.84,
          width: 11,
          lateralDivergence: 25,
          elevationOffset: -16,
          requiredCheckpointIndices: [9, 10],
        },
      ],
    },
  ],
  quantum_highway: [
    {
      id: 'quantum_junction_matrix',
      name: 'Quantum Split Matrix',
      trackId: 'quantum_highway',
      approachT: 0.24,
      junctionStartT: 0.30,
      junctionEndT: 0.46,
      bannerText: 'QUANTUM MATRIX DIVERGENCE',
      defaultRouteId: 'quantum_matrix_center',
      routes: [
        {
          id: 'quantum_matrix_left',
          name: 'SUB-ETHER BYPASS',
          direction: 'LEFT',
          subtitle: 'Shielded Laser Gate Bypass',
          detail: 'Stable sub-ether highway that avoids heavy energy laser surges.',
          themeColor: '#00f0ff',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.25, 0.55, 0.85],
          hasObstacles: false,
          lengthMultiplier: 1.05,
          width: 15,
          lateralDivergence: -26,
          elevationOffset: 10,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'quantum_matrix_center',
          name: 'QUANTUM SPINE EXPRESS',
          direction: 'CENTER',
          subtitle: 'Zero-Dispersion Central Highway',
          detail: 'High-speed straightaway down the center of the quantum grid with dual warp pads.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.30, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.00,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [3, 4],
        },
        {
          id: 'quantum_matrix_right',
          name: 'TACHYON OVERDRIVE SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'Instantaneous Warp Chord (-18% Time)',
          detail: 'Pulsing quantum tunnel. Cuts directly through the hyper-grid with supreme velocity.',
          themeColor: '#ff007f',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.7],
          hasObstacles: true,
          obstacleFractions: [0.2, 0.5, 0.8],
          lengthMultiplier: 0.82,
          width: 11,
          lateralDivergence: 24,
          elevationOffset: -16,
          requiredCheckpointIndices: [3, 4],
        },
      ],
    },
    {
      id: 'quantum_junction_hyperspace',
      name: 'Hyperspace Conduit Fork',
      trackId: 'quantum_highway',
      approachT: 0.66,
      junctionStartT: 0.72,
      junctionEndT: 0.88,
      bannerText: 'HYPERSPACE CONDUIT FORK',
      defaultRouteId: 'quantum_hyperspace_center',
      routes: [
        {
          id: 'quantum_hyperspace_left',
          name: 'LIGHTSPEED ARTERY',
          direction: 'LEFT',
          subtitle: 'Multi-lane Supersonic Skyway',
          detail: 'Smooth acceleration tube with wide turning clearances and zero obstacle interference.',
          themeColor: '#00ffcc',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.65],
          hasObstacles: false,
          lengthMultiplier: 1.04,
          width: 16,
          lateralDivergence: -28,
          elevationOffset: 12,
          requiredCheckpointIndices: [10, 11],
        },
        {
          id: 'quantum_hyperspace_center',
          name: 'HYPER-TUNNEL SPINE',
          direction: 'CENTER',
          subtitle: 'Direct Tunnel Axis',
          detail: 'Direct supersonic tube with balanced acceleration strips.',
          themeColor: '#38bdf8',
          isShortcut: false,
          riskLevel: 'LOW',
          hasBoostPads: true,
          boostPadFractions: [0.3, 0.7],
          hasObstacles: false,
          lengthMultiplier: 1.0,
          width: 14,
          lateralDivergence: 0,
          elevationOffset: 4,
          requiredCheckpointIndices: [10, 11],
        },
        {
          id: 'quantum_hyperspace_right',
          name: 'WARP FISSURE SHORTCUT',
          direction: 'SHORTCUT',
          subtitle: 'Dimensional Crack (-15% Distance)',
          detail: 'Tight fracture in hyperspace fabric. Demands high precision steering.',
          themeColor: '#ff0055',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.4],
          hasObstacles: true,
          obstacleFractions: [0.3, 0.7],
          lengthMultiplier: 0.85,
          width: 10.5,
          lateralDivergence: 25,
          elevationOffset: -18,
          requiredCheckpointIndices: [10, 11],
        },
      ],
    },
  ],
};

// Junction Manager Architecture & Reusable Functions
export class JunctionManager {
  public junctions: Map<string, JunctionZoneInstance> = new Map();
  public junctionMeshGroup: THREE.Group = new THREE.Group();
  public currentTrackId: TrackId = 'circuit_alpha';

  // Mode 21 / Submode 10 — THE FINAL COLLAPSE.
  // Disabled by default so Modes 01–20 and other Mode 21 submodes keep the
  // existing junction configuration untouched.
  public finalCollapseMode = false;
  public readonly finalCollapseJunctionId = 'final_collapse_tower_access';
  /** Separate last-lap spur that branches away from the main track directly to HAVEN-04. */
  public readonly finalCollapseHaven04JunctionId = 'final_collapse_haven04_access';
  public finalCollapseHaven04Unlocked = false;
  public finalCollapseShelter: THREE.Group | null = null;
  /** Visible Submode-10 landmark shown before the terminal routes unlock. */
  public finalCollapseLauncherPreview: THREE.Group | null = null;
  /** Separate physical terminal for Route 02; never reconnects to Route 01. */
  public finalCollapseEscapeTerminal: THREE.Group | null = null;
  /** Separate physical terminal for Route 03; never reconnects to Routes 01/02. */
  public finalCollapseWormholeTerminal: THREE.Group | null = null;
  public finalCollapseHaven04Terminal: THREE.Group | null = null;
  public finalCollapseDoorLeft: THREE.Mesh | null = null;
  public finalCollapseDoorRight: THREE.Mesh | null = null;
  public finalCollapseDoorOpenFraction = 0; // 0 = closed, 1 = open
  /** Submode 10: terminal routes unlock only after the player completes one normal lap. */
  public finalCollapseRoutesUnlocked = false;
  /** Lap 3+: allow the player to continue straight through the terminal fork without entering Routes 01–03. */
  public finalCollapseMainRouteBypassUnlocked = false;

  // Secondary Pressure Doors & Hangar Shield
  public finalCollapsePressureDoorLeft: THREE.Mesh | null = null;
  public finalCollapsePressureDoorRight: THREE.Mesh | null = null;
  public finalCollapsePressureDoorOpenFraction = 1;
  public finalCollapseHangarShield: THREE.Mesh | null = null;

  // Physical Parking Clamps for Bay 07
  public clampArmLeft: THREE.Group | null = null;
  public clampArmRight: THREE.Group | null = null;
  public clampArmFront: THREE.Group | null = null;
  public clampArmRear: THREE.Group | null = null;
  public bay07Hologram: THREE.Group | null = null;
  public energyCables: THREE.Group | null = null;

  // World coordinates of Bay 07 and Entrance
  public bay07WorldPosition: THREE.Vector3 = new THREE.Vector3();
  public bay07WorldQuaternion: THREE.Quaternion = new THREE.Quaternion();
  public towerEntranceWorldPosition: THREE.Vector3 = new THREE.Vector3();

  public setFinalCollapseDoorOpen(fraction: number) {
    this.finalCollapseDoorOpenFraction = THREE.MathUtils.clamp(fraction, 0, 1);
    if (this.finalCollapseDoorLeft && this.finalCollapseDoorRight) {
      const x = THREE.MathUtils.lerp(5.5, 17.5, this.finalCollapseDoorOpenFraction);
      this.finalCollapseDoorLeft.position.x = -x;
      this.finalCollapseDoorRight.position.x = x;
    }
  }

  public setFinalCollapsePressureDoorOpen(fraction: number) {
    this.finalCollapsePressureDoorOpenFraction = THREE.MathUtils.clamp(fraction, 0, 1);
    if (this.finalCollapsePressureDoorLeft && this.finalCollapsePressureDoorRight) {
      const x = THREE.MathUtils.lerp(3.5, 15.0, this.finalCollapsePressureDoorOpenFraction);
      this.finalCollapsePressureDoorLeft.position.x = -x;
      this.finalCollapsePressureDoorRight.position.x = x;
    }
  }

  public setClampsProgress(left: number, right: number, front: number, rear: number) {
    if (this.clampArmLeft) {
      this.clampArmLeft.position.x = THREE.MathUtils.lerp(-5.8, -4.0, left);
      this.clampArmLeft.rotation.z = THREE.MathUtils.lerp(0.35, -0.1, left);
    }
    if (this.clampArmRight) {
      this.clampArmRight.position.x = THREE.MathUtils.lerp(5.8, 4.0, right);
      this.clampArmRight.rotation.z = THREE.MathUtils.lerp(-0.35, 0.1, right);
    }
    if (this.clampArmFront) {
      this.clampArmFront.position.z = THREE.MathUtils.lerp(-192.5, -190.0, front);
      this.clampArmFront.rotation.x = THREE.MathUtils.lerp(-0.35, 0.15, front);
    }
    if (this.clampArmRear) {
      this.clampArmRear.position.z = THREE.MathUtils.lerp(-177.5, -180.0, rear);
      this.clampArmRear.rotation.x = THREE.MathUtils.lerp(0.35, -0.15, rear);
    }
  }

  public setHangarShieldActive(active: boolean) {
    if (this.finalCollapseHangarShield) {
      const mat = this.finalCollapseHangarShield.material as THREE.MeshBasicMaterial;
      if (mat) {
        mat.opacity = active ? 0.75 : 0.0;
      }
    }
  }

  public mainTrack: CosmicTrack;

  // Active state for local player
  public activeJunctionTelemetry: ActiveJunctionTelemetry | null = null;
  public playerRouteProgress: PlayerRouteProgress = {
    isInBranch: false,
    activeJunctionId: null,
    activeRouteId: null,
    progress: 0,
    transitionBlend: 0,
    branchRouteInstance: null,
    entrySpeed: 0,
    validatedCheckpointIndices: new Set<number>(),
  };

  // Feedback notification timer
  public feedbackMessage: string | null = null;
  public feedbackTimer: number = 0;

  // Route commitment and locking state
  public isSelectionLocked: boolean = false;
  public commitmentDistanceMeters: number = 110;

  // Loop prevention: tracks junctions completed on this lap and active cooldowns
  public completedJunctionsThisLap: Set<string> = new Set<string>();
  public junctionCooldowns: Map<string, number> = new Map<string, number>();

  public clearLapJunctions(): void {
    this.completedJunctionsThisLap.clear();
    this.junctionCooldowns.clear();
  }

  constructor(trackId: TrackId, mainTrack: CosmicTrack) {
    this.currentTrackId = trackId;
    this.mainTrack = mainTrack;
    this.initJunctions(trackId);
  }

  public initJunctions(trackId: TrackId) {
    this.junctions.clear();
    this.finalCollapseRoutesUnlocked = false;
    this.finalCollapseMainRouteBypassUnlocked = false;
    this.finalCollapseHaven04Unlocked = false;
    while (this.junctionMeshGroup.children.length > 0) {
      this.junctionMeshGroup.remove(this.junctionMeshGroup.children[0]);
    }

    if (this.finalCollapseShelter) {
      this.junctionMeshGroup.remove(this.finalCollapseShelter);
      this.finalCollapseShelter = null;
    }

    if (this.finalCollapseLauncherPreview) {
      this.junctionMeshGroup.remove(this.finalCollapseLauncherPreview);
      this.finalCollapseLauncherPreview = null;
    }
    if (this.finalCollapseEscapeTerminal) {
      this.junctionMeshGroup.remove(this.finalCollapseEscapeTerminal);
      this.finalCollapseEscapeTerminal = null;
    }
    if (this.finalCollapseWormholeTerminal) {
      this.junctionMeshGroup.remove(this.finalCollapseWormholeTerminal);
      this.finalCollapseWormholeTerminal = null;
    }
    if (this.finalCollapseHaven04Terminal) {
      this.junctionMeshGroup.remove(this.finalCollapseHaven04Terminal);
      this.finalCollapseHaven04Terminal = null;
    }

    const configs = [...(TRACK_JUNCTIONS_CONFIG[trackId] || TRACK_JUNCTIONS_CONFIG.circuit_alpha)];

    // Mode 21 / Submode 10 is an additive evacuation junction. It is injected
    // only when explicitly enabled by GameEngine, so no existing mode changes.
    if (this.finalCollapseMode) {
      configs.push(this.createFinalCollapseJunctionConfig(trackId));
      configs.push(this.createFinalCollapseHaven04JunctionConfig(trackId));
    }

    configs.forEach(cfg => {
      const jInst = new JunctionZoneInstance(cfg, this.mainTrack);
      this.junctions.set(cfg.id, jInst);

      // Add 3D models to scene
      this.junctionMeshGroup.add(jInst.gantryGroup);
      jInst.routeInstances.forEach(routeInst => {
        this.junctionMeshGroup.add(routeInst.meshGroup);
      });

      if (cfg.id === this.finalCollapseJunctionId) {
        // Submode 10's main fork keeps three independent terminal ends. HAVEN-04
        // is a separate last-lap division before the finish line, not part
        // of this shared fork.
        const launcherEnd = jInst.routeInstances.get('bh10_launcher_route')?.getSampleAt(1);
        if (launcherEnd) jInst.exitSample = launcherEnd;
        this.finalCollapseShelter = this.buildFinalCollapseShelter(jInst);
        this.junctionMeshGroup.add(this.finalCollapseShelter);
        const escapeRoute = jInst.routeInstances.get('bh10_escape_route');
        if (escapeRoute) {
          this.finalCollapseEscapeTerminal = this.buildFinalCollapseEscapeTerminal(escapeRoute);
          this.junctionMeshGroup.add(this.finalCollapseEscapeTerminal);
        }
        const wormholeRoute = jInst.routeInstances.get('bh10_wormhole_route');
        if (wormholeRoute) {
          this.finalCollapseWormholeTerminal = this.buildFinalCollapseWormholeTerminal(wormholeRoute);
          this.junctionMeshGroup.add(this.finalCollapseWormholeTerminal);
        }
        const haven04Route = jInst.routeInstances.get('bh10_haven04_route');
        if (haven04Route && !this.finalCollapseHaven04Terminal) {
          this.finalCollapseHaven04Terminal = this.buildFinalCollapseEscapeTerminal(haven04Route);
          this.finalCollapseHaven04Terminal.name = 'Submode10_Route04_Haven04_Terminal';
          this.junctionMeshGroup.add(this.finalCollapseHaven04Terminal);
        }
        this.setFinalCollapseRoutesUnlocked(false);
      }
      if (cfg.id === this.finalCollapseHaven04JunctionId) {
        // The Haven-04 spur is an independent one-route division, positioned
        // before the start/finish line and hidden until the third-lap approach.
        const haven04Route = jInst.routeInstances.get('bh10_haven04_route');
        if (haven04Route) {
          this.finalCollapseHaven04Terminal = this.buildFinalCollapseEscapeTerminal(haven04Route);
          this.finalCollapseHaven04Terminal.name = 'Submode10_Route04_Haven04_Terminal';
          this.junctionMeshGroup.add(this.finalCollapseHaven04Terminal);
        }
        jInst.gantryGroup.visible = false;
        jInst.routeInstances.forEach(routeInst => { routeInst.meshGroup.visible = false; });
        if (this.finalCollapseHaven04Terminal) this.finalCollapseHaven04Terminal.visible = false;
      }
    });
  }

  /**
   * Enable/disable the real Final Collapse evacuation route.
   *
   * This method intentionally rebuilds only the junction layer. The main
   * CosmicTrack, player movement, AI systems, and other modes remain intact.
   */
  /**
   * Show the Orbital Launcher as a real distant 3D landmark during Submode 10.
   * This does not unlock either terminal route and does not affect other modes.
   */
  public setFinalCollapseLauncherPreview(active: boolean): void {
    if (!active) {
      if (this.finalCollapseLauncherPreview) {
        this.junctionMeshGroup.remove(this.finalCollapseLauncherPreview);
        this.finalCollapseLauncherPreview.traverse(object => {
          const mesh = object as THREE.Mesh;
          if (mesh.geometry) mesh.geometry.dispose();
          const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
          if (Array.isArray(material)) material.forEach(m => m.dispose());
          else material?.dispose();
        });
        this.finalCollapseLauncherPreview = null;
      }
      return;
    }

    if (this.finalCollapseLauncherPreview || !this.mainTrack) return;

    // Match the exact terminal endpoint used by Route 01.
    // Place a highly visible approach landmark before the actual terminal.
    // The physical launcher itself remains at Route 01's true terminal endpoint.
    const approachT = 0.86;
    const terminalLateralOffset = -92;
    const terminalElevationOffset = 10;
    const terminalForwardExtension = 105;
    const s = this.mainTrack.getSampleAt(approachT);
    const anchor = s.point.clone()
      .add(s.binormal.clone().multiplyScalar(terminalLateralOffset))
      .add(s.normal.clone().multiplyScalar(terminalElevationOffset))
      .add(s.tangent.clone().multiplyScalar(terminalForwardExtension));

    const group = new THREE.Group();
    group.name = 'Submode10_OrbitalLauncher_ApproachLandmark';
    const rot = new THREE.Matrix4();
    rot.makeBasis(s.binormal, s.normal, s.tangent.clone().negate());
    group.position.copy(anchor);
    group.quaternion.setFromRotationMatrix(rot);

    const structureMat = new THREE.MeshStandardMaterial({
      color: 0x081522,
      metalness: 0.94,
      roughness: 0.2,
      emissive: 0x063b4a,
      emissiveIntensity: 1.2,
    });
    const cyan = new THREE.MeshBasicMaterial({ color: 0x22d3ee });
    const magenta = new THREE.MeshBasicMaterial({ color: 0xff2bd6 });

    // Large launch tower / gantry.
    const tower = new THREE.Mesh(new THREE.BoxGeometry(88, 108, 54), structureMat);
    tower.position.set(0, 54, -30);
    group.add(tower);

    const leftTower = new THREE.Mesh(new THREE.BoxGeometry(11, 136, 14), structureMat);
    leftTower.position.set(-50, 68, -20);
    const rightTower = leftTower.clone();
    rightTower.position.x = 50;
    group.add(leftTower, rightTower);

    const overhead = new THREE.Mesh(new THREE.BoxGeometry(112, 12, 16), structureMat);
    overhead.position.set(0, 126, -20);
    group.add(overhead);

    // Highly visible launch aperture.
    const portal = new THREE.Mesh(
      new THREE.TorusGeometry(25, 2.0, 16, 64),
      cyan
    );
    portal.rotation.x = Math.PI / 2;
    portal.position.set(0, 30, 2);
    group.add(portal);

    const innerPortal = new THREE.Mesh(
      new THREE.TorusGeometry(18, 0.9, 12, 48),
      magenta
    );
    innerPortal.rotation.x = Math.PI / 2;
    innerPortal.position.set(0, 30, 1.5);
    group.add(innerPortal);

    const beacon = new THREE.Mesh(
      new THREE.CylinderGeometry(2.6, 2.6, 26, 16),
      cyan
    );
    beacon.position.set(0, 148, -20);
    group.add(beacon);

    // Large floating sign visible on approach.
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#03101a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 12;
      ctx.strokeRect(8, 8, canvas.width - 16, canvas.height - 16);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = 'bold 64px Arial';
      ctx.fillStyle = '#67e8f9';
      ctx.fillText('ORBITAL LAUNCHER', 512, 90);
      ctx.font = 'bold 38px Arial';
      ctx.fillStyle = '#ff2bd6';
      ctx.fillText('ROUTE 01 // MAGNETIC LOCK', 512, 170);
    }
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(56, 14),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, side: THREE.DoubleSide })
    );
    sign.position.set(0, 88, 3);
    group.add(sign);

    // Long-range route guide: three luminous rings point directly toward the
    // physical launcher so it is readable even before Route 02 unlocks.
    for (let i = 0; i < 3; i++) {
      const guide = new THREE.Mesh(
        new THREE.TorusGeometry(32 + i * 7, 0.9, 10, 48),
        new THREE.MeshBasicMaterial({ color: i === 1 ? 0xff2bd6 : 0x22d3ee, transparent: true, opacity: 0.72 })
      );
      guide.rotation.x = Math.PI / 2;
      guide.position.set(0, 24 + i * 10, 35 + i * 18);
      group.add(guide);
    }

    // Approach lights make the landmark readable against the black-hole sky.
    for (let i = -3; i <= 3; i++) {
      const light = new THREE.Mesh(
        new THREE.SphereGeometry(1.4, 10, 10),
        cyan
      );
      light.position.set(i * 10, 2, 8);
      group.add(light);
    }

    this.finalCollapseLauncherPreview = group;
    this.junctionMeshGroup.add(group);
  }

  /**
   * Submode 10 route gate: Route 01/Route 02 become visible, selectable and
   * physically accessible only after the first normal lap is completed.
   */
  public setFinalCollapseRoutesUnlocked(unlocked: boolean): void {
    this.finalCollapseRoutesUnlocked = unlocked;
    const junction = this.junctions.get(this.finalCollapseJunctionId);
    if (!junction) return;

    const visible = unlocked;
    junction.gantryGroup.visible = visible;
    junction.routeInstances.forEach(routeInst => {
      routeInst.meshGroup.visible = visible;
    });
    if (this.finalCollapseShelter) this.finalCollapseShelter.visible = visible;
    if (this.finalCollapseEscapeTerminal) this.finalCollapseEscapeTerminal.visible = visible;
    if (this.finalCollapseWormholeTerminal) this.finalCollapseWormholeTerminal.visible = visible;
    if (unlocked) {
      this.setFinalCollapseDoorOpen(1.0);
      this.setFinalCollapsePressureDoorOpen(1.0);
      this.setFinalCollapseLauncherPreview(true);
    } else {
      this.setFinalCollapseLauncherPreview(false);
    }

    if (!unlocked) {
      this.finalCollapseMainRouteBypassUnlocked = false;
      junction.selectedRouteId = null;
      this.playerRouteProgress.activeRouteId = null;
      this.playerRouteProgress.activeJunctionId = null;
      this.isSelectionLocked = true;
      this.activeJunctionTelemetry = null;
    } else {
      this.isSelectionLocked = false;
    }
  }

  /**
   * After two full laps, let Submode 10 players bypass the three terminal escape
   * branches and remain on the continuous main circuit. This does not disable
   * any route: a branch is entered only when the player explicitly selects it.
   */
  public setFinalCollapseMainRouteBypassUnlocked(unlocked: boolean): void {
    this.finalCollapseMainRouteBypassUnlocked = unlocked;
    if (unlocked) {
      this.feedbackMessage = 'MAIN ROUTE BYPASS AVAILABLE — KEEP STRAIGHT TO SKIP ROUTES 01–03';
      this.feedbackTimer = 4.0;
    }
  }

  /** Show only the dedicated Haven-04 branch when the third-lap approach is reached. */
  public setFinalCollapseHaven04Unlocked(unlocked: boolean): void {
    // Once revealed on lap 3, keep the spur visible through the branch approach
    // and transit; reset it only when the Submode-10 junction system is rebuilt.
    if (!unlocked && this.finalCollapseHaven04Unlocked) return;
    this.finalCollapseHaven04Unlocked = unlocked;
    const junction = this.junctions.get(this.finalCollapseHaven04JunctionId);
    if (!junction) return;
    junction.gantryGroup.visible = unlocked;
    junction.routeInstances.forEach(routeInst => { routeInst.meshGroup.visible = unlocked; });
    if (this.finalCollapseHaven04Terminal) this.finalCollapseHaven04Terminal.visible = unlocked;
    if (!unlocked && this.activeJunctionTelemetry?.junctionId === this.finalCollapseHaven04JunctionId) {
      this.activeJunctionTelemetry = null;
      this.isSelectionLocked = false;
      junction.selectedRouteId = null;
      if (this.playerRouteProgress.activeJunctionId === this.finalCollapseHaven04JunctionId) {
        this.playerRouteProgress.activeJunctionId = null;
        this.playerRouteProgress.activeRouteId = null;
      }
    }
  }

  public setFinalCollapseMode(active: boolean): void {
    if (this.finalCollapseMode === active) return;

    this.finalCollapseMode = active;
    this.isSelectionLocked = false;
    this.activeJunctionTelemetry = null;
    this.playerRouteProgress = {
      isInBranch: false,
      activeJunctionId: null,
      activeRouteId: null,
      progress: 0,
      transitionBlend: 0,
      branchRouteInstance: null,
      entrySpeed: 0,
      validatedCheckpointIndices: new Set<number>(),
    };

    this.initJunctions(this.currentTrackId);
    if (active) {
      this.setFinalCollapseRoutesUnlocked(false);
    }
  }

  /**
   * Dedicated Mode 21 / Submode 10 junction.
   *
   * Submode 10 uses three expanded terminal branches. They do not reconnect to
   * the main track or to each other. Route 01 terminates at the launcher/shelter;
   * Route 02 terminates at its emergency escape gate; Route 03 terminates at
   * its own unstable wormhole gate. Hazard density is
   * driven continuously by the 40-event collapse timeline, not by difficulty tiers.
   */
  private createFinalCollapseJunctionConfig(trackId: TrackId): JunctionZoneConfig {
    return {
      id: this.finalCollapseJunctionId,
      name: 'QUANTUM LAUNCH SPLIT // FOUR TERMINAL ESCAPE SEQUENCES',
      trackId,
      approachT: 0.10,
      junctionStartT: 0.18,
      junctionEndT: 0.23,
      defaultRouteId: 'bh10_launcher_route',
      bannerText: 'FINAL COLLAPSE // SELECT TERMINAL ROUTE (1-4)',
      routes: [
        {
          id: 'bh10_launcher_route',
          name: 'ROUTE 01 // ORBITAL LAUNCHER',
          direction: 'LEFT',
          subtitle: 'Extended launcher corridor',
          detail: 'Long, wide terminal route through the launcher complex. Ends at the dedicated magnetic-lock platform; it never reconnects to the main track.',
          themeColor: '#22d3ee',
          isShortcut: false,
          riskLevel: 'MEDIUM',
          hasBoostPads: true,
          boostPadFractions: [0.10, 0.24, 0.39, 0.54, 0.69, 0.83, 0.94],
          hasObstacles: true,
          obstacleFractions: [0.18, 0.31, 0.43, 0.56, 0.68, 0.79, 0.89, 0.96],
          lengthMultiplier: 2.35,
          width: 38,
          lateralDivergence: -245,
          elevationOffset: 18,
          terminalLateralOffset: -150,
          terminalElevationOffset: 18,
          terminalForwardExtension: 680,
          requiredCheckpointIndices: [1, 2],
          entryJunctionId: this.finalCollapseJunctionId,
          hasShortcut: false,
          description: 'Multi-stage orbital launch facility route with power restoration nodes, acceleration ramp, and orbital sanctuary docking bay.',
          boostPadCount: 7,
          obstacleCount: 8,
        },
        {
          id: 'bh10_escape_route',
          name: 'ROUTE 02 // EMERGENCY ESCAPE CORRIDOR',
          direction: 'RIGHT',
          subtitle: 'Collapsing city evacuation route // multi-stage mission',
          detail: 'Separate extended emergency route through collapsing city bridges and blast gates. Requires navigating all 8 mission stages to reach the subterranean bunker safe zone.',
          themeColor: '#ff2bd6',
          isShortcut: false,
          riskLevel: 'EXTREME',
          hasBoostPads: true,
          boostPadFractions: [0.08, 0.21, 0.35, 0.49, 0.63, 0.77, 0.89, 0.96],
          hasObstacles: true,
          obstacleFractions: [0.14, 0.26, 0.38, 0.50, 0.62, 0.73, 0.83, 0.91, 0.97],
          lengthMultiplier: 2.65,
          width: 32,
          lateralDivergence: 255,
          elevationOffset: -22,
          terminalLateralOffset: 180,
          terminalElevationOffset: -24,
          terminalForwardExtension: 820,
          terminalRoute: true,
          requiredCheckpointIndices: [1, 2],
          entryJunctionId: this.finalCollapseJunctionId,
          hasShortcut: false,
          description: 'Multi-stage city evacuation corridor with active laser security, collapsing structures, and fortified subterranean blast bunker.',
          boostPadCount: 8,
          obstacleCount: 9,
        },
        {
          id: 'bh10_wormhole_route',
          name: 'ROUTE 03 // GRAVITY SLINGSHOT ESCAPE',
          direction: 'CENTER',
          subtitle: 'High-speed gravity-assist slingshot trajectory',
          detail: 'Dangerous gravity-assisted slingshot maneuver using the black hole ergosphere to slingshot into the Einstein-Rosen gateway safe zone.',
          themeColor: '#a855f7',
          isShortcut: false,
          riskLevel: 'EXTREME',
          hasBoostPads: true,
          boostPadFractions: [0.07, 0.19, 0.32, 0.46, 0.60, 0.74, 0.86, 0.95],
          hasObstacles: true,
          obstacleFractions: [0.12, 0.24, 0.37, 0.51, 0.65, 0.78, 0.88, 0.96],
          lengthMultiplier: 2.85,
          width: 30,
          lateralDivergence: 0,
          elevationOffset: 34,
          terminalLateralOffset: 0,
          terminalElevationOffset: 44,
          terminalForwardExtension: 980,
          terminalRoute: true,
          terminalCaptureFraction: 1.0,
          requiredCheckpointIndices: [1, 2],
          entryJunctionId: this.finalCollapseJunctionId,
          hasShortcut: false,
          description: 'Multi-stage gravity slingshot escape with ergosphere alignment, relativistic hazard dodging, slingshot boost, and Einstein-Rosen gateway validation.',
          boostPadCount: 8,
          obstacleCount: 8,
        },
        {
          id: 'bh10_haven04_route',
          name: 'ROUTE 04 // HAVEN-04 SHIELDED PARKING',
          direction: 'SHORTCUT',
          subtitle: 'Open-dome shielded sanctuary // Bay 01 parking validation',
          detail: 'Direct sanctuary corridor to Haven-04. Pass automatic chamber blast doors, settle speed in Bay 01, and secure ship before 00:00.',
          themeColor: '#34d399',
          isShortcut: true,
          riskLevel: 'HIGH',
          hasBoostPads: true,
          boostPadFractions: [0.10, 0.28, 0.46, 0.64, 0.82, 0.94],
          hasObstacles: true,
          obstacleFractions: [0.22, 0.43, 0.66, 0.86],
          lengthMultiplier: 2.75,
          width: 42,
          lateralDivergence: 340,
          elevationOffset: 16,
          terminalLateralOffset: 260,
          terminalElevationOffset: 16,
          terminalForwardExtension: 900,
          terminalRoute: true,
          terminalCaptureFraction: 1.0,
          requiredCheckpointIndices: [1, 2],
          entryJunctionId: this.finalCollapseJunctionId,
          hasShortcut: true,
          description: 'Open-dome sanctuary with automatic sliding chamber doors, Bay 01 hydraulic clamps, nanite hull repair, and panoramic observation deck.',
          boostPadCount: 6,
          obstacleCount: 4,
        },
      ],
    };
  }

  /**
   * HAVEN-04 is a completely separate terminal spur. It diverges from the
   * main route just before the finish line and never reconnects to the circuit.
   */
  private createFinalCollapseHaven04JunctionConfig(trackId: TrackId): JunctionZoneConfig {
    return {
      id: this.finalCollapseHaven04JunctionId,
      name: 'FINAL COLLAPSE // HAVEN-04 LAST-LAP DIVISION',
      trackId,
      approachT: 0.765,
      junctionStartT: 0.825,
      junctionEndT: 0.905,
      defaultRouteId: 'bh10_haven04_route',
      bannerText: 'LAP 3 // HAVEN-04 SANCTUARY DIVISION',
      routes: [{
        id: 'bh10_haven04_route',
        name: 'ROUTE 04 // HAVEN-04 OPEN DOME',
        direction: 'SHORTCUT',
        subtitle: 'Dedicated open-dome sanctuary spur',
        detail: 'A physically separate last-lap division that leaves the main circuit before the finish line and terminates only at Haven-04.',
        themeColor: '#34d399',
        isShortcut: true,
        riskLevel: 'MEDIUM',
        hasBoostPads: true,
        boostPadFractions: [0.10, 0.28, 0.46, 0.64, 0.82, 0.94],
        hasObstacles: true,
        obstacleFractions: [0.22, 0.43, 0.66, 0.86],
        lengthMultiplier: 2.75,
        width: 42,
        lateralDivergence: 360,
        elevationOffset: 12,
        terminalLateralOffset: 300,
        terminalElevationOffset: 12,
        terminalForwardExtension: 900,
        terminalRoute: true,
        terminalCaptureFraction: 1.0,
        requiredCheckpointIndices: [1, 2],
        entryJunctionId: this.finalCollapseHaven04JunctionId,
        hasShortcut: true,
        description: 'Open dome, free-roaming sanctuary, sensing chamber gates, and a physical shielded parking bay.',
        boostPadCount: 6,
        obstacleCount: 4,
      }],
    };
  }

  /**
   * Build Route 02's independent terminal end. It is deliberately separate from
   * the Orbital Launcher shelter: entering Route 02 arms the escape sequence,
   * and reaching this gate provides the physical terminal for the escape vector.
   */
  private buildFinalCollapseEscapeTerminal(route: BranchRouteInstance): THREE.Group {
    const group = new THREE.Group();
    const gateFraction = route.config.terminalCaptureFraction ?? 1.0;
    const s = route.getSampleAt(gateFraction);
    const rot = new THREE.Matrix4();
    rot.makeBasis(s.binormal, s.normal, s.tangent.clone().negate());
    group.position.copy(s.point);
    group.quaternion.setFromRotationMatrix(rot);
    group.name = 'Submode10_Route02_EmergencyEscape_Terminal';

    const isHaven04Terminal = route.config.id === 'bh10_haven04_route';
    const frameMat = new THREE.MeshStandardMaterial({
      color: isHaven04Terminal ? 0x06281d : 0x170a22,
      metalness: 0.92,
      roughness: 0.2,
      emissive: isHaven04Terminal ? 0x10b981 : 0x5b0b72,
      emissiveIntensity: 1.1,
    });
    const cyan = new THREE.MeshBasicMaterial({ color: isHaven04Terminal ? 0x34d399 : 0x22d3ee });
    const magenta = new THREE.MeshBasicMaterial({ color: isHaven04Terminal ? 0x86efac : 0xff2bd6 });
    const warning = new THREE.MeshBasicMaterial({ color: 0xff5b35 });

    const left = new THREE.Mesh(new THREE.BoxGeometry(12, 150, 18), frameMat);
    left.position.set(-58, 75, 0);
    const right = left.clone();
    right.position.x = 58;
    const top = new THREE.Mesh(new THREE.BoxGeometry(128, 14, 20), frameMat);
    top.position.set(0, 145, 0);
    group.add(left, right, top);

    for (let i = 0; i < 3; i++) {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(31 + i * 9, 1.8, 14, 72),
        i === 1 ? magenta : cyan
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.set(0, 58 + i * 24, -8 - i * 10);
      group.add(ring);
    }

    const gate = new THREE.Mesh(
      new THREE.CircleGeometry(43, 64),
      new THREE.MeshBasicMaterial({ color: 0x0b1020, transparent: true, opacity: 0.9, side: THREE.DoubleSide })
    );
    gate.rotation.x = Math.PI / 2;
    gate.position.set(0, 58, 2);
    group.add(gate);

    const beacon = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 30, 16), warning);
    beacon.position.set(0, 166, 0);
    group.add(beacon);

    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 220;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#080612';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#ff2bd6';
      ctx.lineWidth = 10;
      ctx.strokeRect(6, 6, canvas.width - 12, canvas.height - 12);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = 'bold 60px Arial';
      ctx.fillStyle = '#ff6be8';
      ctx.fillText('ROUTE 02 // EMERGENCY ESCAPE', 512, 82);
      ctx.font = 'bold 34px Arial';
      ctx.fillStyle = '#67e8f9';
      ctx.fillText('ESCAPE VECTOR // WORMHOLE GATE', 512, 152);
    }
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(62, 13),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, side: THREE.DoubleSide })
    );
    sign.position.set(0, 112, 4);
    group.add(sign);

    // Long-range approach arrows make the second terminal unmistakable.
    for (let i = 0; i < 5; i++) {
      const arrow = new THREE.Mesh(new THREE.ConeGeometry(4.5, 12, 6), magenta);
      arrow.rotation.x = Math.PI / 2;
      arrow.position.set(0, 4, 30 + i * 26);
      group.add(arrow);
    }

    return group;
  }

  /** Build Route 03's independent wormhole terminal. */
  private buildFinalCollapseWormholeTerminal(route: BranchRouteInstance): THREE.Group {
    const group = new THREE.Group();
    const s = route.getSampleAt(1);
    const rot = new THREE.Matrix4();
    rot.makeBasis(s.binormal, s.normal, s.tangent.clone().negate());
    group.position.copy(s.point);
    group.quaternion.setFromRotationMatrix(rot);
    group.name = 'Submode10_Route03_WormholeEscape_Terminal';

    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x10061f, metalness: 0.94, roughness: 0.16,
      emissive: 0x6d28d9, emissiveIntensity: 1.5,
    });
    const violet = new THREE.MeshBasicMaterial({ color: 0xa855f7 });
    const cyan = new THREE.MeshBasicMaterial({ color: 0x22d3ee });

    const left = new THREE.Mesh(new THREE.BoxGeometry(10, 170, 16), frameMat);
    left.position.set(-52, 85, 0);
    const right = left.clone(); right.position.x = 52;
    const top = new THREE.Mesh(new THREE.BoxGeometry(116, 12, 18), frameMat);
    top.position.set(0, 165, 0);
    group.add(left, right, top);

    for (let i = 0; i < 5; i++) {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(22 + i * 7, 1.5, 14, 72),
        i % 2 ? cyan : violet
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.set(0, 70 + i * 20, -i * 12);
      group.add(ring);
    }

    const portal = new THREE.Mesh(
      new THREE.CircleGeometry(48, 72),
      new THREE.MeshBasicMaterial({ color: 0x14052a, transparent: true, opacity: 0.92, side: THREE.DoubleSide })
    );
    portal.rotation.x = Math.PI / 2;
    portal.position.set(0, 70, 4);
    group.add(portal);

    const canvas = document.createElement('canvas');
    canvas.width = 1024; canvas.height = 220;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#080612'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#a855f7'; ctx.lineWidth = 10;
      ctx.strokeRect(6, 6, canvas.width - 12, canvas.height - 12);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = 'bold 56px Arial'; ctx.fillStyle = '#d8b4fe';
      ctx.fillText('ROUTE 03 // WORMHOLE ESCAPE', 512, 82);
      ctx.font = 'bold 32px Arial'; ctx.fillStyle = '#67e8f9';
      ctx.fillText('UNSTABLE WORMHOLE // ESCAPE GATE', 512, 152);
    }
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(62, 13),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, side: THREE.DoubleSide })
    );
    sign.position.set(0, 126, 5); group.add(sign);

    for (let i = 0; i < 6; i++) {
      const arrow = new THREE.Mesh(new THREE.ConeGeometry(4.2, 11, 6), violet);
      arrow.rotation.x = Math.PI / 2;
      arrow.position.set(0, 5, 28 + i * 24);
      group.add(arrow);
    }
    return group;
  }

  /**
   * Build the visible physical evacuation tower + subterranean basement complex,
   * descending ramp, B3 hangar, and Bay 07 parking bay around the branch endpoint.
   * This is REAL playable world geometry: the player physically steers their ship
   * down the ramp into Bay 07, aligns, stops, and gets clamped.
   */
  private buildFinalCollapseShelter(junction: JunctionZoneInstance): THREE.Group {
    const group = new THREE.Group();
    const s = junction.exitSample;

    const rot = new THREE.Matrix4();
    rot.makeBasis(s.binormal, s.normal, s.tangent.clone().negate());
    group.position.copy(s.point);
    group.quaternion.setFromRotationMatrix(rot);

    const towerMat = new THREE.MeshStandardMaterial({
      color: 0x07121c,
      metalness: 0.92,
      roughness: 0.22,
      emissive: 0x062b38,
      emissiveIntensity: 0.85,
    });

    const armorMat = new THREE.MeshStandardMaterial({
      color: 0x152532,
      metalness: 0.95,
      roughness: 0.18,
      emissive: 0x0a4352,
      emissiveIntensity: 1.1,
    });

    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x111923,
      metalness: 0.4,
      roughness: 0.8,
    });

    const hazardMat = new THREE.MeshStandardMaterial({
      color: 0xeab308,
      metalness: 0.8,
      roughness: 0.3,
      emissive: 0x713f12,
      emissiveIntensity: 0.5,
    });

    const cyanMat = new THREE.MeshBasicMaterial({ color: 0x22d3ee });
    const greenMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
    const warningMat = new THREE.MeshBasicMaterial({ color: 0xff5b35 });
    const shieldMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      transparent: true,
      opacity: 0.18,
      wireframe: true,
    });

    // 1. Tower Exterior & Giant Energy Shield Dome
    const body = new THREE.Mesh(new THREE.BoxGeometry(68, 110, 84), towerMat);
    body.position.set(0, 52, -42);
    group.add(body);

    const shoulderGeo = new THREE.BoxGeometry(22, 65, 100);
    const leftShoulder = new THREE.Mesh(shoulderGeo, armorMat);
    leftShoulder.position.set(-42, 32, -40);
    const rightShoulder = leftShoulder.clone();
    rightShoulder.position.x = 42;
    group.add(leftShoulder, rightShoulder);

    // Tower Energy Shield Dome
    const shieldDome = new THREE.Mesh(new THREE.SphereGeometry(72, 32, 24, 0, Math.PI * 2, 0, Math.PI * 0.65), shieldMat);
    shieldDome.position.set(0, 30, -50);
    group.add(shieldDome);

    // Mast and Beacon
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2.2, 42, 12), armorMat);
    mast.position.set(0, 115, -45);
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(4.8, 20, 20), warningMat);
    beacon.position.set(0, 138, -45);
    group.add(mast, beacon);

    // Outer Blast Door frame around entrance threshold (z = 0)
    const doorPillarGeo = new THREE.BoxGeometry(5.0, 24, 10);
    const leftPillar = new THREE.Mesh(doorPillarGeo, armorMat);
    leftPillar.position.set(-18, 12, -2);
    const rightPillar = leftPillar.clone();
    rightPillar.position.x = 18;
    const doorHeader = new THREE.Mesh(new THREE.BoxGeometry(42, 5.0, 10), armorMat);
    doorHeader.position.set(0, 23.5, -2);
    group.add(leftPillar, rightPillar, doorHeader);

    // Sliding Outer Blast Door Slabs
    const slabGeo = new THREE.BoxGeometry(13, 17, 1.8);
    const leftSlab = new THREE.Mesh(slabGeo, new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.95,
      roughness: 0.2,
      emissive: 0x0f172a,
    }));
    leftSlab.position.set(-6, 11.5, -0.1);
    const rightSlab = leftSlab.clone();
    rightSlab.position.x = 6;
    group.add(leftSlab, rightSlab);
    this.finalCollapseDoorLeft = leftSlab;
    this.finalCollapseDoorRight = rightSlab;
    this.setFinalCollapseDoorOpen(0);

    // Tower Exterior Holographic Sign
    const signCanvas = document.createElement('canvas');
    signCanvas.width = 1024;
    signCanvas.height = 256;
    const ctx = signCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#05101a';
      ctx.fillRect(0, 0, signCanvas.width, signCanvas.height);
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 12;
      ctx.strokeRect(8, 8, signCanvas.width - 16, signCanvas.height - 16);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = 'bold 68px Arial';
      ctx.fillStyle = '#67e8f9';
      ctx.fillText('ORBITAL LAUNCHER // ESCAPE GATE', signCanvas.width / 2, 85);
      ctx.font = 'bold 44px Arial';
      ctx.fillStyle = '#22c55e';
      ctx.fillText('MAGNETIC LOCK // LAUNCH SYSTEM ACTIVE', signCanvas.width / 2, 168);
    }
    const signTexture = new THREE.CanvasTexture(signCanvas);
    signTexture.needsUpdate = true;
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(44, 11),
      new THREE.MeshBasicMaterial({ map: signTexture, transparent: true, side: THREE.DoubleSide })
    );
    sign.position.set(0, 36, 1.2);
    group.add(sign);

    // 2. Security Scanner Gate (z = -24)
    const scannerArch = new THREE.Mesh(new THREE.BoxGeometry(34, 18, 3), armorMat);
    scannerArch.position.set(0, 9, -24);
    const scannerLaser = new THREE.Mesh(
      new THREE.BoxGeometry(28, 0.3, 0.3),
      new THREE.MeshBasicMaterial({ color: 0x22c55e, transparent: true, opacity: 0.9 })
    );
    scannerLaser.position.set(0, 14, -24);
    group.add(scannerArch, scannerLaser);

    // 3. Descending Access Ramp (z = -32 to z = -128)
    // Slopes smoothly from y = 0 to y = -14
    const rampLength = 96;
    const rampGeo = new THREE.BoxGeometry(32, 1.2, rampLength);
    const ramp = new THREE.Mesh(rampGeo, concreteMat);
    ramp.position.set(0, -7, -80);
    ramp.rotation.x = Math.atan2(14, rampLength);
    group.add(ramp);

    // Ramp Tunnel Walls & Ceiling Enclosure
    const tunnelWallMat = new THREE.MeshStandardMaterial({
      color: 0x0c1520,
      metalness: 0.85,
      roughness: 0.4,
    });
    const leftWall = new THREE.Mesh(new THREE.BoxGeometry(2, 22, rampLength), tunnelWallMat);
    leftWall.position.set(-16.5, -3, -80);
    const rightWall = leftWall.clone();
    rightWall.position.x = 16.5;
    const tunnelCeiling = new THREE.Mesh(new THREE.BoxGeometry(35, 2, rampLength), tunnelWallMat);
    tunnelCeiling.position.set(0, 8, -80);
    tunnelCeiling.rotation.x = ramp.rotation.x;
    group.add(leftWall, rightWall, tunnelCeiling);

    // Observation Windows looking out at the Cosmic Catastrophe
    const windowMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.1,
      roughness: 0.05,
      transparent: true,
      opacity: 0.28,
    });
    [-62, -98].forEach(wz => {
      const windowMesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, 10, 16), windowMat);
      windowMesh.position.set(-16.4, -3, wz);
      group.add(windowMesh);

      // Warning Frame around observation window
      const frame = new THREE.Mesh(new THREE.BoxGeometry(1.4, 11, 18), armorMat);
      frame.position.set(-16.6, -3, wz);
      group.add(frame);
    });

    // Descent Level B3 Sign
    const b3Canvas = document.createElement('canvas');
    b3Canvas.width = 512;
    b3Canvas.height = 128;
    const b3ctx = b3Canvas.getContext('2d');
    if (b3ctx) {
      b3ctx.fillStyle = '#081420';
      b3ctx.fillRect(0, 0, 512, 128);
      b3ctx.font = 'bold 38px Arial';
      b3ctx.fillStyle = '#38bdf8';
      b3ctx.textAlign = 'center';
      b3ctx.textBaseline = 'middle';
      b3ctx.fillText('ORBITAL LAUNCH SYSTEM', 256, 45);
      b3ctx.font = 'bold 26px Arial';
      b3ctx.fillStyle = '#22c55e';
      b3ctx.fillText('ACCELERATION RINGS // DOCKING BAY', 256, 88);
    }
    const b3Sign = new THREE.Mesh(
      new THREE.PlaneGeometry(24, 6),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(b3Canvas), transparent: true })
    );
    b3Sign.position.set(0, 4, -112);
    group.add(b3Sign);

    // 4. Underground Tunnel & Secondary Pressure Gate (z = -135)
    const pressureGateFrame = new THREE.Mesh(new THREE.BoxGeometry(36, 22, 6), armorMat);
    pressureGateFrame.position.set(0, -3, -135);
    group.add(pressureGateFrame);

    const pressSlabGeo = new THREE.BoxGeometry(14, 18, 2);
    const pLeft = new THREE.Mesh(pressSlabGeo, armorMat);
    pLeft.position.set(-14, -4, -135);
    const pRight = pLeft.clone();
    pRight.position.x = 14;
    group.add(pLeft, pRight);
    this.finalCollapsePressureDoorLeft = pLeft;
    this.finalCollapsePressureDoorRight = pRight;

    // 4.5 Quantum Launch Pro physical escape hardware. These are real scene
    // objects placed along the same continuous corridor; they do not teleport
    // the player and do not replace the existing black hole.
    const launchRingMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      transparent: true,
      opacity: 0.72,
      side: THREE.DoubleSide,
    });
    const launchCoreMat = new THREE.MeshBasicMaterial({ color: 0xa855f7 });
    const launchRingZ = [-40, -80, -115];
    launchRingZ.forEach((z, i) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(13.5 + i * 1.5, 0.75, 12, 64), launchRingMat.clone());
      ring.rotation.x = Math.PI / 2;
      ring.position.set(0, -5.5 - i * 2.5, z);
      group.add(ring);

      const core = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 24, 12), launchCoreMat.clone());
      core.rotation.z = Math.PI / 2;
      core.position.set(0, -10 - i * 1.2, z);
      group.add(core);
    });

    // Orbital gate / escape-vector frame before the station bay.
    const gateMat = new THREE.MeshStandardMaterial({
      color: 0x172554, metalness: 0.9, roughness: 0.2,
      emissive: 0x4c1d95, emissiveIntensity: 1.1,
    });
    const gateLeft = new THREE.Mesh(new THREE.BoxGeometry(3, 24, 3), gateMat);
    const gateRight = gateLeft.clone();
    gateLeft.position.set(-16, -2, -164);
    gateRight.position.set(16, -2, -164);
    const gateTop = new THREE.Mesh(new THREE.BoxGeometry(35, 3, 3), gateMat);
    gateTop.position.set(0, 10, -164);
    const gateField = new THREE.Mesh(
      new THREE.PlaneGeometry(30, 20),
      new THREE.MeshBasicMaterial({ color: 0x8b5cf6, transparent: true, opacity: 0.12, side: THREE.DoubleSide })
    );
    gateField.position.set(0, -1, -164);
    gateField.rotation.y = Math.PI;
    group.add(gateLeft, gateRight, gateTop, gateField);

    // 5. Evacuation Hangar B3 (z = -145 to z = -225, floor at y = -14)
    const hangarFloor = new THREE.Mesh(new THREE.BoxGeometry(64, 1.5, 80), concreteMat);
    hangarFloor.position.set(0, -14.75, -185);
    const hangarCeiling = new THREE.Mesh(new THREE.BoxGeometry(64, 1.5, 80), tunnelWallMat);
    hangarCeiling.position.set(0, 9, -185);
    const hangarLeftWall = new THREE.Mesh(new THREE.BoxGeometry(2, 24, 80), tunnelWallMat);
    hangarLeftWall.position.set(-32, -3, -185);
    const hangarRightWall = hangarLeftWall.clone();
    hangarRightWall.position.x = 32;
    const hangarRearWall = new THREE.Mesh(new THREE.BoxGeometry(64, 24, 2), tunnelWallMat);
    hangarRearWall.position.set(0, -3, -225);
    group.add(hangarFloor, hangarCeiling, hangarLeftWall, hangarRightWall, hangarRearWall);

    // Structural Pillars with Hazard Stripes
    [-24, 24].forEach(px => {
      [-160, -185, -210].forEach(pz => {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(3.5, 24, 3.5), armorMat);
        pillar.position.set(px, -3, pz);
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(3.6, 2.5, 3.6), hazardMat);
        stripe.position.set(px, -11, pz);
        group.add(pillar, stripe);
      });
    });

    // Side Parking Bays 01 - 06 (decorative support craft/docking stations)
    [-20, 20].forEach((bx, bIdx) => {
      [-165, -185, -205].forEach((bz, zIdx) => {
        const bayNum = bIdx * 3 + zIdx + 1;
        const sidePad = new THREE.Mesh(new THREE.BoxGeometry(10, 0.4, 14), armorMat);
        sidePad.position.set(bx, -14.4, bz);
        group.add(sidePad);

        // Simple parked drone craft
        const drone = new THREE.Mesh(new THREE.ConeGeometry(2.5, 8, 4), towerMat);
        drone.position.set(bx, -12, bz);
        drone.rotation.x = Math.PI / 2;
        group.add(drone);
      });
    });

    // 6. DEDICATED PLAYER PARKING BAY 07 (x = 0, y = -14, z = -185)
    const bay07Pad = new THREE.Mesh(
      new THREE.BoxGeometry(18, 0.6, 26),
      new THREE.MeshStandardMaterial({
        color: 0x14202c,
        metalness: 0.9,
        roughness: 0.25,
        emissive: 0x082b3d,
        emissiveIntensity: 0.6,
      })
    );
    bay07Pad.position.set(0, -14.4, -185);
    group.add(bay07Pad);

    // Glowing Neon Docking Reticle & Perimeter
    const borderGeo = new THREE.BoxGeometry(17.6, 0.2, 0.8);
    const borderNorth = new THREE.Mesh(borderGeo, cyanMat);
    borderNorth.position.set(0, -14.05, -197.6);
    const borderSouth = borderNorth.clone();
    borderSouth.position.z = -172.4;
    group.add(borderNorth, borderSouth);

    const borderSideGeo = new THREE.BoxGeometry(0.8, 0.2, 26);
    const borderWest = new THREE.Mesh(borderSideGeo, cyanMat);
    borderWest.position.set(-8.6, -14.05, -185);
    const borderEast = borderWest.clone();
    borderEast.position.x = 8.6;
    group.add(borderWest, borderEast);

    // Floor Target Crosshairs
    const cross1 = new THREE.Mesh(new THREE.BoxGeometry(10, 0.1, 0.6), greenMat);
    cross1.position.set(0, -14.02, -185);
    const cross2 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 14), greenMat);
    cross2.position.set(0, -14.02, -185);
    group.add(cross1, cross2);

    // Holographic BAY 07 Beacon Projector
    const bay07Group = new THREE.Group();
    bay07Group.position.set(0, -7.5, -185);
    const holoCanvas = document.createElement('canvas');
    holoCanvas.width = 512;
    holoCanvas.height = 256;
    const hctx = holoCanvas.getContext('2d');
    if (hctx) {
      hctx.fillStyle = 'rgba(6, 25, 40, 0.85)';
      hctx.fillRect(0, 0, 512, 256);
      hctx.strokeStyle = '#00f0ff';
      hctx.lineWidth = 10;
      hctx.strokeRect(6, 6, 500, 244);
      hctx.textAlign = 'center';
      hctx.textBaseline = 'middle';
      hctx.font = 'bold 64px Arial';
      hctx.fillStyle = '#67e8f9';
      hctx.fillText('[ STATION BAY 07 ]', 256, 80);
      hctx.font = 'bold 32px Arial';
      hctx.fillStyle = '#22c55e';
      hctx.fillText('SHIP SECURED // ESCAPE COMPLETE', 256, 160);
    }
    const holoMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(12, 6),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(holoCanvas), transparent: true, side: THREE.DoubleSide })
    );
    bay07Group.add(holoMesh);
    group.add(bay07Group);
    this.bay07Hologram = bay07Group;

    // 7. Physical Mechanical Clamps (Left, Right, Front, Rear)
    const clampMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.95,
      roughness: 0.2,
      emissive: 0x0f172a,
    });
    const clampTipMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

    // Left Clamp Assembly
    const clampLeft = new THREE.Group();
    clampLeft.position.set(-5.8, -14.0, -185);
    const baseL = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.5, 4.0), clampMat);
    const armL = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.2, 3.2), clampMat);
    armL.position.set(1.2, 1.2, 0);
    const tipL = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.4, 3.4), clampTipMat);
    tipL.position.set(2.4, 1.2, 0);
    clampLeft.add(baseL, armL, tipL);
    group.add(clampLeft);
    this.clampArmLeft = clampLeft;

    // Right Clamp Assembly
    const clampRight = new THREE.Group();
    clampRight.position.set(5.8, -14.0, -185);
    const baseR = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.5, 4.0), clampMat);
    const armR = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.2, 3.2), clampMat);
    armR.position.set(-1.2, 1.2, 0);
    const tipR = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.4, 3.4), clampTipMat);
    tipR.position.set(-2.4, 1.2, 0);
    clampRight.add(baseR, armR, tipR);
    group.add(clampRight);
    this.clampArmRight = clampRight;

    // Front Clamp Assembly
    const clampFront = new THREE.Group();
    clampFront.position.set(0, -14.0, -192.5);
    const baseF = new THREE.Mesh(new THREE.BoxGeometry(4.0, 2.5, 1.6), clampMat);
    const armF = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.2, 2.4), clampMat);
    armF.position.set(0, 1.2, 1.2);
    const tipF = new THREE.Mesh(new THREE.BoxGeometry(3.4, 1.4, 0.4), clampTipMat);
    tipF.position.set(0, 1.2, 2.4);
    clampFront.add(baseF, armF, tipF);
    group.add(clampFront);
    this.clampArmFront = clampFront;

    // Rear Clamp Assembly
    const clampRear = new THREE.Group();
    clampRear.position.set(0, -14.0, -177.5);
    const baseB = new THREE.Mesh(new THREE.BoxGeometry(4.0, 2.5, 1.6), clampMat);
    const armB = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.2, 2.4), clampMat);
    armB.position.set(0, 1.2, -1.2);
    const tipB = new THREE.Mesh(new THREE.BoxGeometry(3.4, 1.4, 0.4), clampTipMat);
    tipB.position.set(0, 1.2, -2.4);
    clampRear.add(baseB, armB, tipB);
    group.add(clampRear);
    this.clampArmRear = clampRear;

    // Charging Cables & Power Conduit Lines
    const cableMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, wireframe: true });
    const cableGroup = new THREE.Group();
    [-4, 4].forEach(cx => {
      const cable = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 8, 8), cableMat);
      cable.position.set(cx, -13.6, -185);
      cable.rotation.z = Math.PI / 2;
      cableGroup.add(cable);
    });
    group.add(cableGroup);
    this.energyCables = cableGroup;

    // Hangar Secondary Energy Shield (activates upon shelter sealed)
    const hShield = new THREE.Mesh(
      new THREE.BoxGeometry(32, 18, 1),
      new THREE.MeshBasicMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.0, side: THREE.DoubleSide })
    );
    hShield.position.set(0, -4, -144);
    group.add(hShield);
    this.finalCollapseHangarShield = hShield;

    // Precalculate target world positions
    group.updateMatrixWorld(true);
    this.towerEntranceWorldPosition.set(0, 0, 0).applyMatrix4(group.matrixWorld);
    this.bay07WorldPosition.set(0, -14, -185).applyMatrix4(group.matrixWorld);
    this.bay07WorldQuaternion.copy(group.quaternion);

    return group;
  }

  /**
   * 1. Junction Detection: detects if player is approaching or inside any junction
   */
  public detectNearbyJunction(splineT: number): {
    junction: JunctionZoneInstance;
    distanceM: number;
    isApproaching: boolean;
    isInJunction: boolean;
  } | null {
    const wrappedT = ((splineT % 1.0) + 1.0) % 1.0;
    const trackLen = this.mainTrack.totalLength || 4800;

    for (const [id, junction] of this.junctions.entries()) {
      // Loop Prevention: Skip this junction if already cleared on the current lap or on cooldown
      if (this.completedJunctionsThisLap.has(id)) {
        continue;
      }
      const cd = this.junctionCooldowns.get(id) || 0;
      if (cd > 0) {
        continue;
      }

      const cfg = junction.config;
      // In Submode 10, the terminal fork to Route 01 / Route 02 is locked until lap 1 is completed
      if (cfg.id === this.finalCollapseJunctionId && !this.finalCollapseRoutesUnlocked) continue;
      if (cfg.id === this.finalCollapseHaven04JunctionId && !this.finalCollapseHaven04Unlocked) continue;
      const startT = cfg.junctionStartT;
      const endT = cfg.junctionEndT;
      const approachT = cfg.approachT;

      // In-Junction Check: strict inequality < endT so reaching junctionEndT doesn't re-trigger
      let isInJunction = false;
      if (startT <= endT) {
        isInJunction = wrappedT >= startT && wrappedT < endT;
      } else {
        isInJunction = wrappedT >= startT || wrappedT < endT;
      }

      // Approach Check
      let isApproaching = false;
      let deltaTToStart = 0;

      if (approachT <= startT) {
        isApproaching = wrappedT >= approachT && wrappedT < startT;
        deltaTToStart = startT - wrappedT;
      } else {
        // Wraps over start line
        isApproaching = wrappedT >= approachT || wrappedT < startT;
        deltaTToStart = (startT - wrappedT + 1.0) % 1.0;
      }

      if (isApproaching || isInJunction) {
        const distanceM = Math.max(0, Math.round(deltaTToStart * trackLen));
        return {
          junction,
          distanceM,
          isApproaching,
          isInJunction,
        };
      }
    }

    return null;
  }

  /**
   * 2. Available Routes query
   */
  public getAvailableRoutes(junctionId: string): BranchRouteConfig[] {
    const junction = this.junctions.get(junctionId);
    return junction ? junction.config.routes : [];
  }

  /**
   * 3. Route Selection (supports either (routeId) or (junctionId, routeId))
   */
  public selectRoute(routeIdOrJunctionId: string, maybeRouteId?: string): boolean {
    // Only lock selection if already actively navigating a physical branch curve
    if (this.playerRouteProgress.isInBranch) {
      console.warn(`[JunctionManager] Route selection rejected: player already navigating branch.`);
      this.feedbackMessage = `ROUTE LOCKED: CURRENTLY NAVIGATING BRANCH`;
      this.feedbackTimer = 2.0;
      return false;
    }

    let jId = this.activeJunctionTelemetry?.junctionId;
    let rId = routeIdOrJunctionId;
    if (maybeRouteId) {
      jId = routeIdOrJunctionId;
      rId = maybeRouteId;
    }

    if (!jId) {
      // Find which junction has this routeId
      for (const [id, j] of this.junctions.entries()) {
        if (j.config.routes.some(r => r.id === rId)) {
          jId = id;
          break;
        }
      }
    }

    if (!jId) return false;
    if (jId === this.finalCollapseJunctionId && !this.finalCollapseRoutesUnlocked) return false;
    if (jId === this.finalCollapseHaven04JunctionId && !this.finalCollapseHaven04Unlocked) return false;
    const junction = this.junctions.get(jId);
    if (!junction) return false;

    const route = junction.config.routes.find(r => r.id === rId);
    if (!route) return false;

    junction.selectedRouteId = rId;
    this.playerRouteProgress.activeRouteId = rId;
    this.playerRouteProgress.activeJunctionId = jId;

    const dirLabel = route.direction === 'SHORTCUT' ? 'SHORTCUT (RIGHT)' : route.direction;
    this.feedbackMessage = `ROUTE SELECTED: ${dirLabel} — ${route.name}`;
    this.feedbackTimer = 2.5;

    if (this.activeJunctionTelemetry) {
      this.activeJunctionTelemetry.selectedRouteId = rId;
      this.activeJunctionTelemetry.selectedRouteDirection = route.direction;
    }

    return true;
  }

  /**
   * Commits the selected route when entering the commitment zone
   */
  public commitRoute(routeId?: string): boolean {
    const junction = this.junctions.get(this.playerRouteProgress.activeJunctionId || this.activeJunctionTelemetry?.junctionId || '');
    let targetRouteId = routeId;
    if (!targetRouteId) {
      targetRouteId = junction?.selectedRouteId || this.playerRouteProgress.activeRouteId || this.getDefaultRoute(junction).id;
    }

    this.isSelectionLocked = true;
    this.playerRouteProgress.activeRouteId = targetRouteId;
    if (junction) {
      junction.selectedRouteId = targetRouteId;
    }
    if (this.activeJunctionTelemetry) {
      this.activeJunctionTelemetry.isLocked = true;
      this.activeJunctionTelemetry.selectedRouteId = targetRouteId;
      this.activeJunctionTelemetry.status = 'COMMITMENT_ZONE';
    }
    return true;
  }

  public lockRouteSelection(): void {
    this.isSelectionLocked = true;
    if (this.activeJunctionTelemetry) {
      this.activeJunctionTelemetry.isLocked = true;
    }
  }

  public unlockRouteSelection(): void {
    this.isSelectionLocked = false;
    if (this.activeJunctionTelemetry) {
      this.activeJunctionTelemetry.isLocked = false;
    }
  }

  /**
   * Select route by direction: 'LEFT', 'RIGHT', 'CENTER', 'SHORTCUT'
   */
  public selectRouteByDirection(direction: BranchRouteDirection): boolean {
    let jId = this.activeJunctionTelemetry?.junctionId;
    let junction = jId ? this.junctions.get(jId) : null;

    // Submode 10 has one common start and four independent terminal branches.
    // LEFT = Route 01, RIGHT = Route 02, CENTER = Route 03, SHORTCUT = Route 04 (Haven-04).
    if (jId === this.finalCollapseJunctionId && !['LEFT', 'CENTER', 'RIGHT', 'SHORTCUT'].includes(direction)) {
      return false;
    }
    
    // If not detected via telemetry, find first approaching or active junction
    if (!junction) {
      for (const [id, j] of this.junctions.entries()) {
        if (!this.completedJunctionsThisLap.has(id)) {
          jId = id;
          junction = j;
          break;
        }
      }
    }
    if (!junction || !jId) return false;

    // Find route matching direction or fallback
    let target = junction.config.routes.find(r => r.direction === direction);
    if (!target && direction === 'RIGHT') {
      target = junction.config.routes.find(r => r.direction === 'SHORTCUT');
    }
    if (!target && direction === 'SHORTCUT') {
      target = junction.config.routes.find(r => r.direction === 'RIGHT');
    }
    if (!target && direction === 'CENTER') {
      target = junction.config.routes.find(r => r.id.includes('center')) || junction.config.routes[1] || junction.config.routes[0];
    }
    if (!target && direction === 'LEFT') {
      target = junction.config.routes.find(r => r.id.includes('left')) || junction.config.routes[0];
    }

    if (target) {
      return this.selectRoute(jId, target.id);
    }
    return false;
  }

  /**
   * 4. Route Validation
   */
  public validateRoute(routeId: string, junctionId?: string): boolean {
    if (junctionId) {
      const junction = this.junctions.get(junctionId);
      return !!junction?.config.routes.some(r => r.id === routeId);
    }
    for (const j of this.junctions.values()) {
      if (j.config.routes.some(r => r.id === routeId)) return true;
    }
    return false;
  }

  /**
   * 5. Default Route retrieval
   */
  public getDefaultRoute(junctionOrId?: JunctionZoneInstance | string): BranchRouteConfig {
    let junction: JunctionZoneInstance | undefined;
    if (typeof junctionOrId === 'string') {
      junction = this.junctions.get(junctionOrId);
    } else if (junctionOrId) {
      junction = junctionOrId;
    } else if (this.activeJunctionTelemetry) {
      junction = this.junctions.get(this.activeJunctionTelemetry.junctionId);
    }

    if (!junction) {
      const firstJunction = Array.from(this.junctions.values())[0];
      if (firstJunction) return firstJunction.config.routes[0];
      return {
        id: 'default_route',
        name: 'MAIN HYPER-HIGHWAY',
        direction: 'CENTER',
        subtitle: 'Primary Cosmic Vector',
        detail: 'Standard regulation vector corridor.',
        themeColor: '#00f0ff',
        isShortcut: false,
        riskLevel: 'LOW',
        hasBoostPads: false,
        hasObstacles: false,
        lengthMultiplier: 1.0,
        width: 24,
        lateralDivergence: 0,
        requiredCheckpointIndices: [],
      };
    }

    const def = junction.config.routes.find(r => r.id === junction!.config.defaultRouteId);
    return def || junction.config.routes[0];
  }

  /**
   * 6. Smooth Transition to Route (supports (routeId, speed) or (junction, routeId, speed))
   */
  public transitionToRoute(
    junctionOrRouteId: JunctionZoneInstance | string,
    maybeRouteId?: string | number,
    maybeSpeed?: number
  ) {
    let junction: JunctionZoneInstance | undefined;
    let routeId: string = '';
    let currentSpeed: number = 30;

    if (typeof junctionOrRouteId === 'string') {
      routeId = junctionOrRouteId;
      if (typeof maybeRouteId === 'number') {
        currentSpeed = maybeRouteId;
      }
      for (const j of this.junctions.values()) {
        if (j.config.routes.some(r => r.id === routeId)) {
          junction = j;
          break;
        }
      }
    } else {
      junction = junctionOrRouteId;
      routeId = typeof maybeRouteId === 'string' ? maybeRouteId : '';
      currentSpeed = typeof maybeSpeed === 'number' ? maybeSpeed : 30;
    }

    if (!junction) return;
    const routeInst = junction.routeInstances.get(routeId);
    if (!routeInst) return;

    this.playerRouteProgress.isInBranch = true;
    this.playerRouteProgress.activeJunctionId = junction.config.id;
    this.playerRouteProgress.activeRouteId = routeId;
    this.playerRouteProgress.branchRouteInstance = routeInst;
    this.playerRouteProgress.progress = 0;
    this.playerRouteProgress.transitionBlend = 0;
    this.playerRouteProgress.entrySpeed = currentSpeed;
    this.playerRouteProgress.validatedCheckpointIndices = new Set<number>();
  }

  /**
   * 7. Update Route Progress & Checkpoint validation
   */
  public updateRouteProgress(
    dt: number,
    currentSpeed: number,
    onCheckpointValidated?: (cpIndices: number[]) => void
  ): {
    finishedBranch: boolean;
    sample: SamplePoint | null;
    lateralOffset: number;
    rejoinSplineT: number;
    completedRouteId?: string;
    terminalRoute?: boolean;
    terminalPoint?: THREE.Vector3;
    terminalTangent?: THREE.Vector3;
  } {
    const prp = this.playerRouteProgress;
    if (!prp.isInBranch || !prp.branchRouteInstance) {
      return { finishedBranch: false, sample: null, lateralOffset: 0, rejoinSplineT: 0 };
    }

    const routeInst = prp.branchRouteInstance;
    const junction = this.junctions.get(prp.activeJunctionId || '');

    // Advance progress along branch curve preserving real velocity
    const advance = (currentSpeed * dt) / routeInst.totalLength;
    prp.progress = Math.max(0, prp.progress + advance);
    prp.transitionBlend = Math.min(1.0, prp.transitionBlend + dt * 2.5);

    // Incremental real-time checkpoint validation during branch travel
    if (routeInst.config.requiredCheckpointIndices && onCheckpointValidated) {
      const cps = routeInst.config.requiredCheckpointIndices;
      const count = cps.length;
      cps.forEach((cpIdx, idx) => {
        const threshold = (idx + 1) / (count + 1);
        if (prp.progress >= threshold && !prp.validatedCheckpointIndices.has(cpIdx)) {
          prp.validatedCheckpointIndices.add(cpIdx);
          onCheckpointValidated([cpIdx]);
        }
      });
    }

    // Terminal routes may define a physical gate capture point slightly
    // before the decorative spline tail. This keeps the trigger aligned with
    // the visible gate and avoids requiring an unnecessarily long final tail.
    const terminalCaptureFraction = routeInst.config.terminalRoute
      ? THREE.MathUtils.clamp(routeInst.config.terminalCaptureFraction ?? 1.0, 0.5, 1.0)
      : 1.0;

    // If reached the terminal gate/end of branch
    if (prp.progress >= terminalCaptureFraction) {
      prp.isInBranch = false;
      const jId = prp.activeJunctionId;
      const routeName = routeInst.config.name;

      // Safe advance past the junction exit to prevent looping
      const exitAdvance = 0.015;
      const rejoinT = junction ? ((junction.config.junctionEndT + exitAdvance) % 1.0) : 0.5;

      // Mark this junction as completed for the current lap to prevent infinite loops
      if (jId) {
        this.completedJunctionsThisLap.add(jId);
        this.junctionCooldowns.set(jId, 15.0);
      }

      // Validate any remaining checkpoints for this branch route
      if (routeInst.config.requiredCheckpointIndices && onCheckpointValidated) {
        const remaining = routeInst.config.requiredCheckpointIndices.filter(
          idx => !prp.validatedCheckpointIndices.has(idx)
        );
        if (remaining.length > 0) {
          remaining.forEach(idx => prp.validatedCheckpointIndices.add(idx));
          onCheckpointValidated(remaining);
        }
      }

      const completedRouteId = routeInst.config.id;
      const terminalRoute = routeInst.config.terminalRoute === true;
      const terminalSample = routeInst.getSampleAt(terminalCaptureFraction);
      const terminalPoint = terminalSample.point.clone();
      const terminalTangent = terminalSample.tangent.clone();
      this.feedbackMessage = terminalRoute
        ? `ROUTE COMPLETED: ${routeName} // TERMINAL END REACHED`
        : `ROUTE COMPLETED: ${routeName} // MERGED TO MAIN LANE`;
      this.feedbackTimer = 3.0;

      prp.activeJunctionId = null;
      prp.activeRouteId = null;
      prp.branchRouteInstance = null;
      prp.progress = 0;
      prp.validatedCheckpointIndices.clear();
      this.isSelectionLocked = false;
      this.activeJunctionTelemetry = null;

      return {
        finishedBranch: true,
        sample: null,
        lateralOffset: 0,
        rejoinSplineT: rejoinT,
        completedRouteId,
        terminalRoute,
        terminalPoint,
        terminalTangent,
      };
    }

    const branchSample = routeInst.getSampleAt(prp.progress);
    return {
      finishedBranch: false,
      sample: branchSample,
      lateralOffset: 0,
      rejoinSplineT: 0,
    };
  }

  /**
   * Main per-frame update loop
   */
  public update(dt: number, totalTimeSec: number, splineT: number, currentSpeed: number): ActiveJunctionTelemetry | null {
    if (this.feedbackTimer > 0) {
      this.feedbackTimer = Math.max(0, this.feedbackTimer - dt);
      if (this.feedbackTimer === 0) this.feedbackMessage = null;
    }

    // Decrement junction cooldowns
    for (const [jId, cd] of this.junctionCooldowns.entries()) {
      if (cd > 0) {
        const nextCd = Math.max(0, cd - dt);
        if (nextCd === 0) {
          this.junctionCooldowns.delete(jId);
        } else {
          this.junctionCooldowns.set(jId, nextCd);
        }
      }
    }

    // Detect nearby junction
    const detected = this.detectNearbyJunction(splineT);

    if (detected) {
      const { junction, distanceM, isApproaching, isInJunction } = detected;
      const isCommitmentZone = isApproaching && distanceM <= this.commitmentDistanceMeters;

      // Submode 10 is explicitly arrow-controlled: do not auto-commit a route.
      // The player must choose LEFT (Route 01) or RIGHT (Route 02).
      const isFinalCollapseFork = junction.config.id === this.finalCollapseJunctionId ||
        junction.config.id === this.finalCollapseHaven04JunctionId;
      if (!isFinalCollapseFork && (isCommitmentZone || isInJunction)) {
        if (!this.isSelectionLocked) {
          const autoRouteId = junction.selectedRouteId || this.playerRouteProgress.activeRouteId || this.getDefaultRoute(junction).id;
          this.commitRoute(autoRouteId);
        }
      } else if (isApproaching && distanceM > this.commitmentDistanceMeters) {
        // Still approaching before commitment zone: player can freely switch routes
        this.isSelectionLocked = false;
      }

      const selectedId = junction.selectedRouteId || this.playerRouteProgress.activeRouteId;
      const selectedRoute = junction.config.routes.find(r => r.id === selectedId);

      // Lap-3 main-route bypass: no explicit route choice means continue on
      // the original circuit. Do not silently auto-select the default branch.
      const bypassMainRoute =
        junction.config.id === this.finalCollapseJunctionId &&
        this.finalCollapseMainRouteBypassUnlocked &&
        !selectedId;

      // If entered junction boundary and hasn't started branch transition yet.
      // Routes 01–03 remain selectable; only an unselected fork is bypassed.
      if (isInJunction && !this.playerRouteProgress.isInBranch && !bypassMainRoute) {
        const finalRouteId = selectedId || this.getDefaultRoute(junction).id;
        this.transitionToRoute(junction, finalRouteId, currentSpeed);
      }

      junction.updateAnimation(totalTimeSec, selectedId);

      const decisionSpeed = Math.max(20, currentSpeed);
      const timeRemainingSec = Math.max(0.1, distanceM / decisionSpeed);

      const status: 'APPROACHING' | 'COMMITMENT_ZONE' | 'ACTIVE' | 'PASSED' = 
        this.playerRouteProgress.isInBranch ? 'ACTIVE' :
        (isInJunction ? 'ACTIVE' :
        (isCommitmentZone ? 'COMMITMENT_ZONE' :
        (isApproaching ? 'APPROACHING' : 'PASSED')));

      this.activeJunctionTelemetry = {
        junctionId: junction.config.id,
        junctionName: junction.config.name,
        name: junction.config.name,
        distanceToJunctionMeters: distanceM,
        distanceToJunction: distanceM,
        availableRoutes: junction.config.routes,
        selectedRouteId: selectedId,
        selectedRouteDirection: selectedRoute ? selectedRoute.direction : null,
        statusMessage: bypassMainRoute
          ? 'MAIN ROUTE BYPASS — CONTINUE STRAIGHT TO SKIP ESCAPE ROUTES 01–03'
          : this.feedbackMessage,
        isInJunction: isInJunction || this.playerRouteProgress.isInBranch,
        progressInRoute: this.playerRouteProgress.progress,
        bannerText: junction.config.bannerText,
        isApproaching,
        timeRemainingSec,
        playerInBranch: this.playerRouteProgress.isInBranch,
        branchProgress: this.playerRouteProgress.progress,
        status,
        isLocked: this.isSelectionLocked || this.playerRouteProgress.isInBranch,
      };
    } else {
      this.activeJunctionTelemetry = null;
      this.isSelectionLocked = false;
    }

    return this.activeJunctionTelemetry;
  }

  /**
   * AI Route Selection Strategy based on Personality and Condition
   */
  public getAIRouteChoice(
    junction: JunctionZoneInstance,
    personality: AIPersonality,
    difficulty: AIDifficulty,
    speedKmH: number,
    shieldPercent: number
  ): string {
    const routes = junction.config.routes;
    const shortcut = routes.find(r => r.isShortcut || r.direction === 'SHORTCUT');
    const safeRoute = routes.find(r => r.riskLevel === 'LOW') || routes[0];
    const techRoute = routes.find(r => r.riskLevel === 'MEDIUM') || routes[1] || routes[0];

    // Aggressive & Risk Takers love shortcuts (85% probability)
    if (personality === 'AGGRESSIVE' || personality === 'RISK_TAKER') {
      if (shortcut && (shieldPercent > 35 || difficulty === 'ELITE' || difficulty === 'ACE')) {
        return Math.random() < 0.85 ? shortcut.id : safeRoute.id;
      }
    }

    // Defensive racers strictly prefer safer, wider routes
    if (personality === 'DEFENSIVE') {
      return Math.random() < 0.90 ? safeRoute.id : (shortcut ? shortcut.id : safeRoute.id);
    }

    // Technical racers choose high-speed boost or technical curves
    if (personality === 'TECHNICAL') {
      return Math.random() < 0.75 ? techRoute.id : safeRoute.id;
    }

    // Balanced racers evaluate based on current speed & health
    if (shieldPercent < 50) {
      return safeRoute.id;
    }
    return Math.random() < 0.55 ? (shortcut ? shortcut.id : techRoute.id) : safeRoute.id;
  }

  /**
   * Track Graph & Segment Helper Queries
   */
  public getCurrentSegment(): TrackSegment | null {
    if (this.mainTrack?.trackManager) {
      return this.mainTrack.trackManager.getCurrentSegment();
    }
    return null;
  }

  public getCurrentRoute(): string {
    if (this.mainTrack?.trackManager) {
      return this.mainTrack.trackManager.getCurrentRoute();
    }
    return this.playerRouteProgress.activeRouteId || 'main_route';
  }

  public getNextSegment(): TrackSegment | null {
    if (this.mainTrack?.trackManager) {
      return this.mainTrack.trackManager.getNextSegment();
    }
    return null;
  }

  public getTrackProgress(): number {
    if (this.mainTrack?.trackManager) {
      return this.mainTrack.trackManager.getTrackProgress();
    }
    return this.mainTrack ? (this.playerRouteProgress.progress || 0) : 0;
  }

  public validateTrackGraph(): TrackGraphValidationResult {
    if (this.mainTrack?.trackGraph) {
      return validateGraphUtil(this.mainTrack.trackGraph);
    }
    return { isValid: true, errors: [], warnings: [] };
  }

  public validateCheckpointOrder(checkpoints: RouteAwareCheckpoint[]): boolean {
    for (let i = 0; i < checkpoints.length - 1; i++) {
      if (checkpoints[i].sequenceIndex >= checkpoints[i + 1].sequenceIndex) {
        return false;
      }
    }
    return true;
  }

  public isValidFinishCrossing(hasPassedRequiredCheckpoints: boolean, isForward: boolean, isCooldowned: boolean): boolean {
    return hasPassedRequiredCheckpoints && isForward && !isCooldowned;
  }
}

// Reusable Architecture Utilities for RouteManager, CheckpointManager, and LapManager
export const RouteManager = {
  detectNearbyJunction: (manager: JunctionManager, splineT: number) => manager.detectNearbyJunction(splineT),
  getAvailableRoutes: (manager: JunctionManager, junctionId: string) => manager.getAvailableRoutes(junctionId),
  selectRoute: (manager: JunctionManager, routeId: string, junctionId?: string) => manager.selectRoute(routeId, junctionId),
  validateRoute: (manager: JunctionManager, routeId: string, junctionId?: string) => manager.validateRoute(routeId, junctionId),
  getDefaultRoute: (manager: JunctionManager, junction?: JunctionZoneInstance | string) => manager.getDefaultRoute(junction),
  transitionToRoute: (manager: JunctionManager, routeId: string, speed?: number) => manager.transitionToRoute(routeId, speed),
  updateRouteProgress: (manager: JunctionManager, dt: number, speed: number, onCp?: (cp: number[]) => void) =>
    manager.updateRouteProgress(dt, speed, onCp),
};

export class CheckpointManager {
  public static validateBranchCheckpoints(
    requiredIndices: number[],
    currentPassedSet: Set<number>,
    nextCheckpointIdx: number,
    totalCheckpoints: number
  ): { validated: number[]; nextIdx: number } {
    const validated: number[] = [];
    let updatedNext = nextCheckpointIdx;
    for (const cpIdx of requiredIndices) {
      currentPassedSet.add(cpIdx);
      validated.push(cpIdx);
      if (updatedNext === cpIdx) {
        updatedNext = (updatedNext + 1) % totalCheckpoints;
      }
    }
    return { validated, nextIdx: updatedNext };
  }
}

export class LapManager {
  public static validateLapCompletion(
    passedCheckpoints: Set<number>,
    totalCheckpoints: number,
    minCoverageFraction: number = 0.75
  ): boolean {
    if (totalCheckpoints <= 0) return true;
    return (passedCheckpoints.size / totalCheckpoints) >= minCoverageFraction;
  }
}
