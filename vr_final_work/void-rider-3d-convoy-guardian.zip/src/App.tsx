import React, { useEffect, useRef, useState } from 'react';
import { GameEngine } from './game/gameEngine';
import { networkClient } from './network/client';
import { sound } from './game/audio';
import {
  progressionStorage,
  generateDailyMissions,
  INITIAL_ACHIEVEMENTS,
} from './game/progression';
import {
  ActivePowerUp,
  AIRaceConfig,
  CameraMode,
  DynamicTrackEvent,
  GameMode,
  GraphicsQuality,
  PlayerInput,
  PlayerRaceState,
  PowerUpType,
  RaceResult,
  RoomState,
  RunStats,
  ShipDecalType,
  ShipUpgrades,
  ThrusterFlameColor,
  CockpitSkin,
  TrackId,
  UpgradeType,
  ShipDamageZones,
  CustomRoomSettings,
  MultiplayerMode,
  AIDifficulty,
  BeamTelemetry,
  BeamCustomization,
  BeamUpgrades,
  MissileTelemetry,
  ActiveShieldTelemetry,
  MinimapTelemetry,
  AIDebugTelemetry,
  CosmicPairLiveTelemetry,
  QuantumCountdownTelemetry,
  CosmicBiomeDefinition,
  COSMIC_BIOMES,
} from './types';
import { DEFAULT_BEAM_CUSTOMIZATION, DEFAULT_BEAM_UPGRADES } from './game/beamSystem';
import { ActiveJunctionTelemetry, BranchRouteDirection } from './game/junctionSystem';
import { MainMenu } from './components/MainMenu';
import { LobbyView } from './components/LobbyView';
import { GarageView } from './components/GarageView';
import { RaceHUD } from './components/RaceHUD';
import { AIDebugOverlay } from './components/AIDebugOverlay';
import { ResultsModal } from './components/ResultsModal';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { SettingsModal } from './components/SettingsModal';
import { MissionsModal } from './components/MissionsModal';
import { LeaderboardsModal } from './components/LeaderboardsModal';
import { ProfileModal } from './components/ProfileModal';
import { GameModeSelectModal } from './components/GameModeSelectModal';
import { IntoUnknownModal } from './components/IntoUnknownModal';
import { AIRaceModal } from './components/AIRaceModal';
import { SpaceHubModal } from './components/SpaceHubModal';
import { StoryUniverseModal } from './components/StoryUniverseModal';
import { MultiplayerModal } from './components/MultiplayerModal';
import { CollisionHUD } from './components/CollisionHUD';
import { CollisionEventFeedback, PlayerCollisionConfig } from './types';
import { ModeHUDTelemetry } from './game/modeManager';
import { SingularityTelemetry } from './game/blackHoleSystem';
import { championshipManager } from './game/championshipManager';
import { CinematicIntroOverlay } from './components/CinematicIntroOverlay';
import { IntroHUDTelemetry } from './game/cinematicIntro/cinematicTypes';
import { CinematicEventHUD } from './components/CinematicEventHUD';
import { ActiveCinematicState, ExtendedPathTelemetry } from './game/extendedPath/extendedPathTypes';
import { FinishCinematicOverlay } from './components/FinishCinematicOverlay';
import { FinishCinematicTelemetry } from './game/fullRouteCinematic/finishCinematicManager';
import { BlackHoleCinematicTelemetry } from './game/blackHoleCinematicManager';
import { FinalCollapseResultsModal } from './components/FinalCollapseResultsModal';
import { FinalCollapseFailureOverlay } from './components/FinalCollapseFailureOverlay';
import { FinalCollapseStats } from './game/FinalCollapseManager';
import { PhotoModeOverlay } from './components/PhotoModeOverlay';
import { ChampionshipModal } from './components/ChampionshipModal';
import { TrackBuilderModal } from './components/TrackBuilderModal';
import { ReplayTheaterModal } from './components/ReplayTheaterModal';
import { PilotSkillTreeModal } from './components/PilotSkillTreeModal';
import { LiveryPainterModal } from './components/LiveryPainterModal';
import { SynthStudioModal } from './components/SynthStudioModal';
import { cosmicRadio } from './game/cosmicRadio';
import { getShipConfig } from './game/ships';
import { championshipCups } from './game/championshipCups';
import { hyperspaceGauntlet } from './game/hyperspaceGauntlet';
import { DEFAULT_PHOTO_SETTINGS } from './game/photoModeManager';
import {
  PhotoModeSettings,
  RadioTelemetry,
  TacticalModuleTelemetry,
  GhostTelemetry,
  CustomTrackNode,
  CosmicWeatherTelemetry,
  RivalRadioChatter,
  CustomLiveryConfig,
  BossDreadnoughtTelemetry,
  JuggernautModeTelemetry,
} from './types';
import { JuggernautModal } from './components/juggernaut/JuggernautModal';
import { JuggernautHUD } from './components/juggernaut/JuggernautHUD';
import { JuggernautVictoryModal } from './components/juggernaut/JuggernautVictoryModal';
import { JuggernautCombatTelemetry, JuggernautMatchConfig } from './game/juggernaut/juggernautTypes';
import { ConvoyModal } from './components/convoy/ConvoyModal';
import { ConvoyHUD } from './components/convoy/ConvoyHUD';
import { ConvoyVictoryModal } from './components/convoy/ConvoyVictoryModal';
import { ConvoyTelemetry, ConvoyVariant } from './game/convoy/convoyTypes';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // App & Navigation State
  const [appState, setAppState] = useState<'MAIN_MENU' | 'GARAGE' | 'LOBBY' | 'RACING'>('MAIN_MENU');
  const [currentRoom, setCurrentRoom] = useState<RoomState | null>(null);
  const [gameMode, setGameMode] = useState<GameMode>('GRAND_PRIX');
  const [isAIRaceActive, setIsAIRaceActive] = useState<boolean>(false);

  // Player Customization & Progression State
  const [progression, setProgression] = useState(() => progressionStorage.load());
  const [currentShipId, setCurrentShipId] = useState(progression.selectedShipId);
  const [currentColor, setCurrentColor] = useState(progression.primaryColor);
  const [currentSecondaryColor, setCurrentSecondaryColor] = useState(progression.secondaryColor);
  const [currentDecal, setCurrentDecal] = useState<ShipDecalType>(progression.decal);
  const [currentThrusterColor, setCurrentThrusterColor] = useState<ThrusterFlameColor>(progression.thrusterColor);
  const [currentCockpitSkin, setCurrentCockpitSkin] = useState<CockpitSkin>(progression.cockpitSkin);
  const [currentUpgrades, setCurrentUpgrades] = useState<ShipUpgrades>(progression.upgrades);

  // Race Telemetry State
  const [speed, setSpeed] = useState<number>(0);
  const [boost, setBoost] = useState<number>(100);
  const [currentLap, setCurrentLap] = useState<number>(1);
  const [totalLaps, setTotalLaps] = useState<number>(2);
  const [rank, setRank] = useState<number>(1);
  const [totalPlayers, setTotalPlayers] = useState<number>(1);
  const [checkpoint, setCheckpoint] = useState<number>(0);
  const [totalCheckpoints, setTotalCheckpoints] = useState<number>(16);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [activeEvent, setActiveEvent] = useState<DynamicTrackEvent | null>(null);
  const [hazardHitMessage, setHazardHitMessage] = useState<string | null>(null);
  const [shortcutMessage, setShortcutMessage] = useState<string | null>(null);
  const [powerUps, setPowerUps] = useState<ActivePowerUp[]>([]);
  const [hullHealth, setHullHealth] = useState<number>(100);
  const [sessionCredits, setSessionCredits] = useState<number>(0);
  const [distanceMeters, setDistanceMeters] = useState<number>(0);
  const [milestoneMessage, setMilestoneMessage] = useState<string | null>(null);
  const [isWrongWay, setIsWrongWay] = useState<boolean>(false);
  const [destroyedMessage, setDestroyedMessage] = useState<string | null>(null);
  const [respawnTimeRemaining, setRespawnTimeRemaining] = useState<number>(0);
  const [currentLapMs, setCurrentLapMs] = useState<number>(0);
  const [bestLapMs, setBestLapMs] = useState<number>(0);
  const [earnedCredits, setEarnedCredits] = useState<number>(0);
  const [introTelemetry, setIntroTelemetry] = useState<IntroHUDTelemetry | null>(null);
  const [finishTelemetry, setFinishTelemetry] = useState<FinishCinematicTelemetry | null>(null);
  const [blackHoleCinematicTelemetry, setBlackHoleCinematicTelemetry] = useState<BlackHoleCinematicTelemetry | null>(null);

  // Camera & Video Settings
  const [cameraMode, setCameraMode] = useState<CameraMode>('CHASE_NEAR');
  const [cameraShakeEnabled, setCameraShakeEnabled] = useState<boolean>(true);
  const [graphicsQuality, setGraphicsQuality] = useState<GraphicsQuality>('HIGH');

  // Modals visibility
  const [isResultsOpen, setIsResultsOpen] = useState<boolean>(false);
  const [resultsData, setResultsData] = useState<RaceResult[]>([]);
  const [finalCollapseStats, setFinalCollapseStats] = useState<FinalCollapseStats | null>(null);
  const [isFinalCollapseResultsOpen, setIsFinalCollapseResultsOpen] = useState<boolean>(false);
  const [isGameOverOpen, setIsGameOverOpen] = useState<boolean>(false);
  const [gameOverStats, setGameOverStats] = useState<RunStats | null>(null);
  const [isPauseOpen, setIsPauseOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [settingsTab, setSettingsTab] = useState<'COSMIC_TELEMETRY' | 'AV_HUD'>('COSMIC_TELEMETRY');
  const [isMissionsOpen, setIsMissionsOpen] = useState<boolean>(false);
  const [isLeaderboardsOpen, setIsLeaderboardsOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isGameModesOpen, setIsGameModesOpen] = useState<boolean>(false);
  const [isIntoUnknownOpen, setIsIntoUnknownOpen] = useState<boolean>(false);
  const [isAIRaceModalOpen, setIsAIRaceModalOpen] = useState<boolean>(false);
  const [isSpaceHubOpen, setIsSpaceHubOpen] = useState<boolean>(false);
  const [isStoryOpen, setIsStoryOpen] = useState<boolean>(false);
  const [isMultiplayerModalOpen, setIsMultiplayerModalOpen] = useState<boolean>(false);
  const [isChampionshipOpen, setIsChampionshipOpen] = useState<boolean>(false);
  const [isTrackBuilderOpen, setIsTrackBuilderOpen] = useState<boolean>(false);
  const [isPhotoModeOpen, setIsPhotoModeOpen] = useState<boolean>(false);
  const [photoModeSettings, setPhotoModeSettings] = useState<PhotoModeSettings>({ ...DEFAULT_PHOTO_SETTINGS });
  const [isReplayOpen, setIsReplayOpen] = useState<boolean>(false);
  const [isSkillTreeOpen, setIsSkillTreeOpen] = useState<boolean>(false);
  const [isLiveryOpen, setIsLiveryOpen] = useState<boolean>(false);
  const [isSynthStudioOpen, setIsSynthStudioOpen] = useState<boolean>(false);
  const [tacticalTelemetry, setTacticalTelemetry] = useState<TacticalModuleTelemetry | null>(null);
  const [radioTelemetry, setRadioTelemetry] = useState<RadioTelemetry | null>(null);
  const [ghostTelemetry, setGhostTelemetry] = useState<GhostTelemetry | null>(null);
  const [cosmicWeatherTelemetry, setCosmicWeatherTelemetry] = useState<CosmicWeatherTelemetry | null>(null);
  const [rivalChatter, setRivalChatter] = useState<RivalRadioChatter | null>(null);
  const [bossTelemetry, setBossTelemetry] = useState<BossDreadnoughtTelemetry | null>(null);
  const [juggernautTelemetry, setJuggernautTelemetry] = useState<JuggernautModeTelemetry | null>(null);
  const [isJuggernautModalOpen, setIsJuggernautModalOpen] = useState<boolean>(false);
  const [juggernautCombatTelemetry, setJuggernautCombatTelemetry] = useState<JuggernautCombatTelemetry | null>(null);
  const [isJuggernautCombatActive, setIsJuggernautCombatActive] = useState<boolean>(false);
  const [isJuggernautVictoryOpen, setIsJuggernautVictoryOpen] = useState<boolean>(false);
  const [isConvoyModalOpen, setIsConvoyModalOpen] = useState<boolean>(false);
  const [convoyTelemetry, setConvoyTelemetry] = useState<ConvoyTelemetry | null>(null);
  const [isConvoyActive, setIsConvoyActive] = useState<boolean>(false);
  const [convoyVariant, setConvoyVariant] = useState<ConvoyVariant>('SAVIOUR');
  const [isConvoyVictoryOpen, setIsConvoyVictoryOpen] = useState<boolean>(false);
  const [spectatorTargetName, setSpectatorTargetName] = useState<string>('');
  const [damageZones, setDamageZones] = useState<ShipDamageZones>({
    frontHull: 0,
    rearEngine: 0,
    leftWing: 0,
    rightWing: 0,
    shieldCore: 100,
  });

  // Network status
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [ping, setPing] = useState<number>(18);

  // Asteroid Beam Telemetry
  const [beamTelemetry, setBeamTelemetry] = useState<BeamTelemetry | null>(null);

  // Branching Path & Junction Switching Telemetry
  const [junctionTelemetry, setJunctionTelemetry] = useState<ActiveJunctionTelemetry | null>(null);

  // Dedicated Player-to-Player Collision Feedback & Config
  const [collisionFeedback, setCollisionFeedback] = useState<CollisionEventFeedback | null>(null);
  const [collisionConfig, setCollisionConfig] = useState<PlayerCollisionConfig | undefined>(undefined);
  const respawnIntervalRef = useRef<any>(null);

  // 20 Modes & Singularity Telemetry State
  const [modeTelemetry, setModeTelemetry] = useState<ModeHUDTelemetry | null>(null);
  const [singularityTelemetry, setSingularityTelemetry] = useState<SingularityTelemetry | null>(null);

  // Functional Missile, Active Shield & Minimap Telemetry States
  const [missileTelemetry, setMissileTelemetry] = useState<MissileTelemetry | null>(null);
  const [activeShieldTelemetry, setActiveShieldTelemetry] = useState<ActiveShieldTelemetry | null>(null);
  const [minimapTelemetry, setMinimapTelemetry] = useState<MinimapTelemetry | null>(null);
  const [aiDebugTelemetry, setAiDebugTelemetry] = useState<AIDebugTelemetry | null>(null);
  const [isAIDebugOpen, setIsAIDebugOpen] = useState<boolean>(false);

  // Extended Path & In-Race Cinematic Telemetry
  const [cinematicState, setCinematicState] = useState<ActiveCinematicState | null>(null);
  const [pathTelemetry, setPathTelemetry] = useState<ExtendedPathTelemetry | null>(null);
  const [cosmicPairTelemetry, setCosmicPairTelemetry] = useState<CosmicPairLiveTelemetry | null>(null);
  const [quantumCountdownTelemetry, setQuantumCountdownTelemetry] = useState<QuantumCountdownTelemetry | null>(null);
  const [activeCosmicBiome, setActiveCosmicBiome] = useState<CosmicBiomeDefinition>(COSMIC_BIOMES.CRYO_NEBULA);
  const [activeRouteBranchName, setActiveRouteBranchName] = useState<string>('MAIN ACCRETION CORRIDOR');
  const [isCountdownMuted, setIsCountdownMuted] = useState<boolean>(false);
  const [coreTemperature, setCoreTemperature] = useState<number>(320);

  // Keyboard & Mouse input tracking
  const keysPressed = useRef<{ [key: string]: boolean }>({});
  const isRightMouseDown = useRef<boolean>(false);

  // 1. Initialize GameEngine
  useEffect(() => {
    if (!containerRef.current) return;

    const engine = new GameEngine(containerRef.current, {
      onSpeedUpdate: s => setSpeed(s),
      onBoostUpdate: b => setBoost(b),
      onLapUpdate: (lap, total) => {
        setCurrentLap(lap);
        setTotalLaps(total);
      },
      onCheckpointUpdate: (curr, total) => {
        setCheckpoint(curr);
        setTotalCheckpoints(total);
      },
      onRankUpdate: (r, tot) => {
        setRank(r);
        setTotalPlayers(tot);
      },
      onRaceFinish: finalTime => {
        handleRaceFinishedLocally(finalTime);
      },
      onTrackEventUpdate: ev => setActiveEvent(ev),
      onHazardHit: msg => {
        setHazardHitMessage(msg);
        setTimeout(() => setHazardHitMessage(null), 2500);
      },
      onShortcutUsed: msg => {
        setShortcutMessage(msg);
        setTimeout(() => setShortcutMessage(null), 3000);
      },
      onPowerUpCollected: type => {
        sound.playShieldActivate();
      },
      onPowerUpsUpdate: list => setPowerUps(list),
      onCreditCollected: (tot, added) => {
        setSessionCredits(tot);
        setProgression(prev => {
          const updated = { ...prev, credits: prev.credits + added };
          progressionStorage.save(updated);
          return updated;
        });
      },
      onHullUpdate: hp => setHullHealth(hp),
      onDistanceUpdate: dist => setDistanceMeters(dist),
      onMilestoneReached: m => {
        setMilestoneMessage(m);
        setTimeout(() => setMilestoneMessage(null), 3500);
      },
      onGameOver: stats => {
        setGameOverStats(stats);
        setIsGameOverOpen(true);
        setAppState('MAIN_MENU');
      },
      onWrongWayUpdate: wrong => setIsWrongWay(wrong),
      onShipDestroyed: (reason, sec) => {
        setDestroyedMessage(reason);
        setRespawnTimeRemaining(sec);
        if (respawnIntervalRef.current) {
          clearInterval(respawnIntervalRef.current);
        }
        respawnIntervalRef.current = setInterval(() => {
          setRespawnTimeRemaining(prev => {
            if (prev <= 0.1) {
              if (respawnIntervalRef.current) {
                clearInterval(respawnIntervalRef.current);
                respawnIntervalRef.current = null;
              }
              return 0;
            }
            return prev - 0.1;
          });
        }, 100);
      },
      onShipRespawned: () => {
        if (respawnIntervalRef.current) {
          clearInterval(respawnIntervalRef.current);
          respawnIntervalRef.current = null;
        }
        setDestroyedMessage(null);
        setRespawnTimeRemaining(0);
      },
      onLapTimesUpdate: (currentMs, bestMs) => {
        setCurrentLapMs(currentMs);
        setBestLapMs(bestMs);
      },
      onCameraModeChange: mode => setCameraMode(mode),
      onDamageZonesUpdate: zones => setDamageZones(zones),
      onSpectatorTargetChange: name => setSpectatorTargetName(name),
      onBeamTelemetry: telemetry => setBeamTelemetry(telemetry),
      onJunctionTelemetry: telemetry => setJunctionTelemetry(telemetry),
      onCollisionFeedback: feedback => setCollisionFeedback(feedback),
      onModeTelemetry: telemetry => setModeTelemetry(telemetry),
      onSingularityTelemetry: telemetry => setSingularityTelemetry(telemetry),
      onMissileTelemetry: telemetry => setMissileTelemetry(telemetry),
      onActiveShieldTelemetry: telemetry => setActiveShieldTelemetry(telemetry),
      onMinimapTelemetry: telemetry => setMinimapTelemetry(telemetry),
      onAIDebugTelemetry: telemetry => setAiDebugTelemetry(telemetry),
      onIntroTelemetry: telemetry => setIntroTelemetry(telemetry),
      onCinematicStateUpdate: state => setCinematicState(state),
      onPathTelemetryUpdate: tel => setPathTelemetry(tel),
      onFinishCinematicTelemetry: telemetry => setFinishTelemetry(telemetry),
      onBlackHoleCinematicTelemetry: telemetry => setBlackHoleCinematicTelemetry(telemetry),
      onCosmicPairTelemetry: telemetry => setCosmicPairTelemetry(telemetry),
      onQuantumCountdownUpdate: telemetry => setQuantumCountdownTelemetry(telemetry),
      onCosmicBiomeUpdate: biome => setActiveCosmicBiome(biome),
      onActiveRouteBranchUpdate: routeName => setActiveRouteBranchName(routeName),
      onCoreTemperatureUpdate: temp => setCoreTemperature(temp),
      onCountdownTick: count => {
        setCountdown(count);
        sound.playCountdownTick();
        if (count === 0) {
          sound.playCountdownGo();
          setTimeout(() => setCountdown(null), 1200);
        }
      },
    });

    setCollisionConfig(engine.getCollisionConfig());

    engine.setPlayerShip(
      currentShipId,
      currentColor,
      currentSecondaryColor,
      currentDecal,
      currentUpgrades,
      currentThrusterColor,
      currentCockpitSkin
    );

    if (progression.beamCustomization) {
      engine.setBeamCustomization(progression.beamCustomization);
    }
    if (progression.beamUpgrades) {
      engine.setBeamUpgrades(progression.beamUpgrades);
    }

    engineRef.current = engine;

    return () => {
      if (respawnIntervalRef.current) {
        clearInterval(respawnIntervalRef.current);
        respawnIntervalRef.current = null;
      }
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // 2. Setup WebSocket Network Client Listeners
  useEffect(() => {
    networkClient.onConnectStatusChange = conn => {
      setIsConnected(conn);
    };

    const resolveMultiplayerGameMode = (room: any): GameMode => {
      if (room.settings?.gameMode) return room.settings.gameMode;
      if (room.mode === 'DUEL_1V1') return 'RIVAL_DUEL';
      if (room.trackId === 'asteroid_run') return 'ASTEROID_RUN';
      if (room.trackId === 'void_rift') return 'WORMHOLE_EXPRESS';
      if (room.trackId === 'cosmic_ring') return 'RING_RUNNER';
      if (room.trackId === 'quantum_highway') return 'QUANTUM_TIME_TRIAL';
      if (room.trackId === 'neon_orbit') return 'SKYLINE_RUSH';
      return 'NEON_CIRCUIT';
    };

    networkClient.onRoomUpdate = room => {
      setCurrentRoom(room);
      if (engineRef.current) {
        const targetMode = resolveMultiplayerGameMode(room);
        setGameMode(targetMode);
        engineRef.current.setGameMode(targetMode, room.settings?.difficulty || 'NORMAL');
        if (room.trackId && room.trackId !== engineRef.current.trackId) {
          engineRef.current.setTrack(room.trackId);
        }
        if (room.settings) {
          engineRef.current.collisionsEnabled = room.settings.collisionsEnabled ?? true;
          engineRef.current.powerUpsEnabled = room.settings.powerUpsEnabled ?? true;
          engineRef.current.damageMode = room.settings.damageMode ?? 'CASUAL';
        }
        const me = networkClient.playerId ? room.players[networkClient.playerId] : null;
        engineRef.current.isSpectator = me?.isSpectator ?? false;
      }
    };

    networkClient.onCountdownTick = count => {
      setCountdown(count);
      sound.playCountdownTick();
      if (count === 0) {
        sound.playCountdownGo();
        setTimeout(() => setCountdown(null), 1200);
      }
    };

    networkClient.onRaceStarted = room => {
      setCurrentRoom(room);
      setAppState('RACING');
      setIsAIRaceActive(false);
      setIsResultsOpen(false);
      setIsGameOverOpen(false);
      setIsPauseOpen(false);

      if (engineRef.current) {
        const targetMode = resolveMultiplayerGameMode(room);
        setGameMode(targetMode);
        engineRef.current.setGameMode(targetMode, room.settings?.difficulty || 'NORMAL');
        if (room.trackId && room.trackId !== engineRef.current.trackId) {
          engineRef.current.setTrack(room.trackId);
        }
        if (room.settings) {
          engineRef.current.collisionsEnabled = room.settings.collisionsEnabled ?? true;
          engineRef.current.powerUpsEnabled = room.settings.powerUpsEnabled ?? true;
          engineRef.current.damageMode = room.settings.damageMode ?? 'CASUAL';
        }
        const me = networkClient.playerId ? room.players[networkClient.playerId] : null;
        engineRef.current.isSpectator = me?.isSpectator ?? false;
        engineRef.current.startRace();
      }
    };

    networkClient.onRaceStateSync = players => {
      if (engineRef.current && networkClient.playerId) {
        engineRef.current.syncRemotePlayers(players, networkClient.playerId);
      }
    };

    networkClient.onPlayerFinished = results => {
      // Player finished notification
    };

    networkClient.onRaceFinished = results => {
      setResultsData(results);
      setIsResultsOpen(true);
      setAppState('MAIN_MENU');
      if (engineRef.current) {
        engineRef.current.stopRace();
      }
      const myResult = results.find(r => r.playerId === networkClient.playerId);
      const isWinner = results[0]?.playerId === networkClient.playerId;
      const prizeCredits = isWinner ? 450 : 200;
      setEarnedCredits(prizeCredits);

      setProgression(prev => {
        const updated = {
          ...prev,
          credits: prev.credits + prizeCredits,
          xp: prev.xp + (isWinner ? 350 : 150),
          stats: {
            ...prev.stats,
            racesCompleted: prev.stats.racesCompleted + 1,
            racesWon: prev.stats.racesWon + (isWinner ? 1 : 0),
          },
        };
        progressionStorage.save(updated);
        return updated;
      });
    };

    const pingTimer = setInterval(() => {
      setPing(networkClient.ping || 16);
    }, 1500);

    const telemTimer = setInterval(() => {
      setRadioTelemetry(cosmicRadio.getTelemetry());
      if (engineRef.current) {
        setTacticalTelemetry(engineRef.current.getTacticalTelemetry());
        setGhostTelemetry(engineRef.current.getGhostTelemetry());
        setCosmicWeatherTelemetry(engineRef.current.getCosmicWeatherTelemetry());
        setRivalChatter(engineRef.current.getRivalChatter());
        setBossTelemetry(engineRef.current.getBossTelemetry());
        setJuggernautTelemetry(engineRef.current.getJuggernautTelemetry());
        const combatTelem = engineRef.current.getJuggernautCombatTelemetry();
        if (combatTelem && combatTelem.isActive) {
          setJuggernautCombatTelemetry(combatTelem);
          if (combatTelem.isMatchOver && combatTelem.finalStats && !isJuggernautVictoryOpen) {
            setIsJuggernautVictoryOpen(true);
            const earnedCredits = combatTelem.finalStats.creditsEarned;
            const earnedXp = combatTelem.finalStats.xpEarned;
            setProgression(prev => {
              const updated = {
                ...prev,
                credits: prev.credits + earnedCredits,
                experience: (prev.experience || 0) + earnedXp,
              };
              progressionStorage.save(updated);
              return updated;
            });
          }
        }

        const cTelem = engineRef.current.getConvoyTelemetry();
        if (cTelem && cTelem.isActive) {
          setConvoyTelemetry(cTelem);
          if (
            (cTelem.missionState === 'VICTORY' || cTelem.missionState === 'DEFEAT') &&
            cTelem.finalStats &&
            !isConvoyVictoryOpen
          ) {
            setIsConvoyVictoryOpen(true);
            const earnedCredits = cTelem.finalStats.creditsEarned;
            const earnedXp = cTelem.finalStats.xpEarned;
            setProgression((prev) => {
              const updated = {
                ...prev,
                credits: prev.credits + earnedCredits,
                experience: (prev.experience || 0) + earnedXp,
              };
              progressionStorage.save(updated);
              return updated;
            });
          }
        }
      }
    }, 100);

    return () => {
      clearInterval(pingTimer);
      clearInterval(telemTimer);
    };
  }, []);

  // 3. Desktop Keyboard Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      keysPressed.current[e.code] = true;

      if (e.code === 'KeyM' || e.code === 'KeyQ') {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.firePlayerMissile();
        }
      }

      if (e.code === 'KeyC' || e.code === 'KeyX' || e.code === 'KeyF') {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.activatePlayerShield();
        }
      }

      if (e.code === 'KeyV' || (e.code === 'KeyC' && appState !== 'RACING')) {
        if (engineRef.current) {
          const nextMode = engineRef.current.toggleCameraMode();
          setCameraMode(nextMode);
        }
      }

      // Whole-black-hole panoramic view is a pre-game presentation only.
      // Do not expose a gameplay toggle.

      if (e.code === 'KeyE') {
        if (engineRef.current && appState === 'RACING') {
          const nextBiomeId = engineRef.current.cycleCosmicBiome();
          setActiveCosmicBiome(COSMIC_BIOMES[nextBiomeId]);
        }
      }

      if (e.code === 'KeyN') {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.toggleMinimapMode();
        }
      }

      if (e.code === 'KeyP') {
        if (appState === 'RACING') {
          if (engineRef.current?.isPhotoModeActive()) {
            engineRef.current.exitPhotoMode();
            setIsPhotoModeOpen(false);
          } else {
            engineRef.current?.enterPhotoMode();
            setIsPhotoModeOpen(true);
          }
        }
      }

      if (e.code === 'KeyT' && !engineRef.current?.getBossTelemetry().isActive) {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.activateTacticalModule();
        }
      }

      if (e.code === 'BracketRight') {
        cosmicRadio.nextChannel();
      }

      if (e.code === 'BracketLeft') {
        cosmicRadio.prevChannel();
      }

      if (e.code === 'KeyO') {
        if (engineRef.current) {
          const nextDebug = engineRef.current.toggleAIDebug();
          setIsAIDebugOpen(nextDebug);
        }
      }

      if (e.code === 'Equal' || e.code === 'NumpadAdd') {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.zoomInMinimap();
        }
      }

      if (e.code === 'Minus' || e.code === 'NumpadSubtract') {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.zoomOutMinimap();
        }
      }

      if (e.code === 'Digit0' || e.code === 'Numpad0') {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.resetMinimapZoom();
        }
      }

      if (e.code === 'KeyR' && !engineRef.current?.getBossTelemetry().isActive) {
        if (engineRef.current && appState === 'RACING') {
          engineRef.current.resetToStart();
          engineRef.current.startRace();
        }
      }

      if (e.code === 'Escape') {
        if (appState === 'RACING') {
          handleTogglePause();
        }
      }

      // Branch Route Switching Input (A / D / W / S or Arrow keys, E to confirm)
      if (engineRef.current?.junctionManager?.activeJunctionTelemetry) {
        let dir: BranchRouteDirection | null = null;
        if (e.code === 'KeyA' || e.code === 'ArrowLeft') {
          dir = 'LEFT';
        } else if (e.code === 'KeyD' || e.code === 'ArrowRight') {
          dir = 'RIGHT';
        } else if (e.code === 'KeyW' || e.code === 'ArrowUp') {
          dir = 'CENTER';
        } else if (e.code === 'KeyS' || e.code === 'ArrowDown') {
          dir = 'SHORTCUT';
        } else if (e.code === 'KeyE') {
          engineRef.current.junctionManager.commitRoute();
          if (engineRef.current.junctionManager.activeJunctionTelemetry) {
            setJunctionTelemetry({ ...engineRef.current.junctionManager.activeJunctionTelemetry });
          }
        }

        if (dir) {
          engineRef.current.input.selectRouteDirection = dir;
          const ok = engineRef.current.junctionManager.selectRouteByDirection(dir);
          if (ok) {
            sound.playRouteSelected();
            if (engineRef.current.junctionManager.activeJunctionTelemetry) {
              setJunctionTelemetry({ ...engineRef.current.junctionManager.activeJunctionTelemetry });
            }
          }
        }
      }

      // Camera Toggle / Whole Black Hole Panorama Shortcut (Key V)
      if (e.code === 'KeyV' && appState === 'RACING') {
        if (engineRef.current) {
          const m = engineRef.current.toggleWholeBlackHoleCamera();
          setCameraMode(m);
        }
      }

      // Forward to Juggernaut Space Combat if active
      if (engineRef.current && isJuggernautCombatActive) {
        engineRef.current.handleJuggernautKeyDown(e.code);
      }

      // Forward to Convoy Guardian if active
      if (engineRef.current && isConvoyActive) {
        engineRef.current.handleConvoyKeyDown(e.code);
      }

      updateInputState();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.code] = false;
      if (engineRef.current && isJuggernautCombatActive) {
        engineRef.current.handleJuggernautKeyUp(e.code);
      }
      if (engineRef.current && isConvoyActive) {
        engineRef.current.handleConvoyKeyUp(e.code);
      }
      updateInputState();
    };

    const updateInputState = () => {
      if (!engineRef.current) return;
      const keys = keysPressed.current;

      let steer = 0;
      if (keys['KeyA'] || keys['ArrowLeft']) steer += 1;
      if (keys['KeyD'] || keys['ArrowRight']) steer -= 1;

      let throttle = 0;
      if (keys['KeyW'] || keys['ArrowUp']) throttle += 1;
      if (keys['KeyS'] || keys['ArrowDown']) throttle -= 1;

      const boostActive = !!keys['Space'];
      const driftActive = !!keys['ShiftLeft'] || !!keys['ShiftRight'];
      const beamActive = !!keys['KeyE'] || isRightMouseDown.current;

      engineRef.current.input = {
        ...engineRef.current.input,
        throttle,
        steer,
        boost: boostActive,
        drift: driftActive,
        fireBeam: beamActive,
        recover: false,
      };
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 2) {
        isRightMouseDown.current = true;
        updateInputState();
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 2) {
        isRightMouseDown.current = false;
        updateInputState();
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      if (appState === 'RACING') {
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('contextmenu', handleContextMenu);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [appState]);

  // 4. Local AI Race Completion Handler
  const handleRaceFinishedLocally = (finalTime: number) => {
    // Mode 21 — The Final Collapse Authoritative Results
    if (gameMode === 'BLACK_HOLE' && engineRef.current?.finalCollapseManager) {
      const stats = engineRef.current.finalCollapseManager.generateStats(
        engineRef.current.raceStartTime,
        engineRef.current.totalDistanceTraveled,
        engineRef.current.checkpointsPassed,
        engineRef.current.boostCount || 0,
        engineRef.current.shieldHits || 0,
        0,
        engineRef.current.finalCollapseEscapedRouteId
      );
      setFinalCollapseStats(stats);
      setIsFinalCollapseResultsOpen(true);
      setAppState('MAIN_MENU');
      if (engineRef.current) {
        engineRef.current.stopRace();
      }
      return;
    }

    const myResult: RaceResult = {
      playerId: 'player',
      playerName: progression.playerName,
      shipId: currentShipId,
      totalTime: finalTime,
      bestLapTime: bestLapMs || finalTime / 2,
      rank: rank || 1,
      completed: true,
    };

    const aiResults: RaceResult[] =
      engineRef.current?.localAIRacers.map(ai => ({
        playerId: ai.id,
        playerName: ai.name,
        shipId: ai.shipId,
        totalTime: finalTime + (ai.rank - 1) * 2400 + Math.random() * 800,
        bestLapTime: (finalTime / 2) * (1 + (ai.rank - 1) * 0.05),
        rank: ai.rank,
        completed: true,
      })) || [];

    const all = [myResult, ...aiResults].sort((a, b) => a.rank - b.rank);
    setResultsData(all);
    setIsResultsOpen(true);
    setAppState('MAIN_MENU');
    const isWinner = rank === 1;
    let prize = isWinner ? 500 : 250;

    if (championshipCups.getState()) {
      const champOutcome = championshipCups.recordStageFinish(rank || 1);
      if (champOutcome.creditsEarned > 0) {
        prize += champOutcome.creditsEarned;
      }
    }

    setEarnedCredits(prize);

    setProgression(prev => {
      const updated = {
        ...prev,
        credits: prev.credits + prize,
        xp: prev.xp + (isWinner ? 400 : 200),
        stats: {
          ...prev.stats,
          racesCompleted: prev.stats.racesCompleted + 1,
          racesWon: prev.stats.racesWon + (isWinner ? 1 : 0),
        },
      };
      progressionStorage.save(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.stopRace();
    }
  };

  // 5. User Interaction Actions
  const handleQuickMatch = (mode?: MultiplayerMode) => {
    sound.playMenuClick();
    networkClient.quickMatch(
      progression.playerName,
      currentShipId,
      currentColor,
      currentSecondaryColor,
      currentDecal,
      currentUpgrades,
      undefined,
      mode
    );
    setAppState('LOBBY');
  };

  const handleCreateRoom = (
    settings?: CustomRoomSettings,
    isSpectator: boolean = false,
    team: 'ALPHA' | 'OMEGA' = 'ALPHA'
  ) => {
    sound.playMenuClick();
    networkClient.createRoom(
      progression.playerName,
      currentShipId,
      currentColor,
      currentSecondaryColor,
      currentDecal,
      currentUpgrades,
      settings?.trackId,
      settings,
      isSpectator,
      team
    );
    setAppState('LOBBY');
  };

  const handleJoinRoom = (
    code?: string,
    isSpectator: boolean = false,
    team: 'ALPHA' | 'OMEGA' = 'ALPHA'
  ) => {
    const targetCode = code || prompt('ENTER 6-CHARACTER WARP SECTOR CODE:');
    if (targetCode && targetCode.trim()) {
      sound.playMenuClick();
      networkClient.joinRoom(
        targetCode.trim().toUpperCase(),
        progression.playerName,
        currentShipId,
        currentColor,
        currentSecondaryColor,
        currentDecal,
        currentUpgrades,
        isSpectator,
        team
      );
      setAppState('LOBBY');
    }
  };

  const handleStartAIRace = (config: AIRaceConfig & { blackHoleSubmode?: string }) => {
    sound.playMenuClick();
    setIsAIRaceModalOpen(false);
    setIsAIRaceActive(true);
    setAppState('RACING');
    setIsResultsOpen(false);
    setIsGameOverOpen(false);
    setIsPauseOpen(false);
    setCountdown(null);
    setSpeed(0);
    setBoost(100);
    setCurrentLap(1);
    setRank(1);
    const expectedTotal = 1 + (config.botCount !== undefined ? config.botCount : 4);
    setTotalPlayers(expectedTotal);
    if (config.mode) {
      setGameMode(config.mode);
      const isSub10 =
        config.mode === 'BLACK_HOLE' &&
        config.blackHoleSubmode === 'FINAL_COLLAPSE';
      if (!isSub10) {
        setQuantumCountdownTelemetry(null);
      }
      if (config.mode !== 'BLACK_HOLE') {
        setBlackHoleCinematicTelemetry(null);
      }
    }
    keysPressed.current = {};

    if (config.initialCameraMode) {
      setCameraMode(config.initialCameraMode);
    }

    if (engineRef.current) {
      if (config.initialCameraMode) {
        engineRef.current.setCameraMode(config.initialCameraMode);
      }
      engineRef.current.resumeGame();
      engineRef.current.startAIRace(config);
    }
  };

  const handleProceedToNextChampionshipStage = () => {
    sound.playMenuClick();
    setIsResultsOpen(false);
    const stage = championshipManager.getCurrentStage();
    const aiDiff: AIDifficulty = stage.difficulty === 'EXPERT' ? 'ELITE' : stage.difficulty === 'HARD' ? 'VETERAN' : 'STANDARD';
    handleStartAIRace({
      trackId: stage.trackId,
      difficulty: aiDiff,
      botCount: 4,
      laps: stage.laps,
      mode: 'VOID_CHAMPIONSHIP',
    });
  };

  const handleTogglePause = () => {
    if (!engineRef.current) return;
    engineRef.current.togglePause();
    setIsPauseOpen(engineRef.current.isPaused);
  };

  const handleRestartRace = () => {
    setIsPauseOpen(false);
    setIsGameOverOpen(false);
    setIsResultsOpen(false);
    setIsFinalCollapseResultsOpen(false);
    setFinalCollapseStats(null);
    setAppState('RACING');

    if (engineRef.current) {
      engineRef.current.resumeGame();
      engineRef.current.restartGame();
    }
  };

  const handleStartJuggernautCombat = (config: JuggernautMatchConfig) => {
    sound.playMenuClick();
    setIsJuggernautModalOpen(false);
    setIsJuggernautVictoryOpen(false);
    setIsJuggernautCombatActive(true);
    setAppState('RACING');
    setIsResultsOpen(false);
    setIsGameOverOpen(false);
    setIsPauseOpen(false);

    if (engineRef.current) {
      engineRef.current.resumeGame();
      engineRef.current.startJuggernautCombat(config);
    }
  };

  const handleReplayJuggernaut = () => {
    sound.playMenuClick();
    setIsJuggernautVictoryOpen(false);
    if (engineRef.current) {
      engineRef.current.resumeGame();
      const currentTelem = engineRef.current.getJuggernautCombatTelemetry();
      engineRef.current.startJuggernautCombat({
        mode: currentTelem.mode,
        playerRole: currentTelem.playerRole,
        playerShipId: currentShipId || 'VR-0777',
        difficulty: 'STANDARD',
        matchDurationSeconds: 180,
        shrinkingBoundary: currentTelem.mode === 'SWARM_HUNT',
      });
    }
  };

  const handleReturnFromJuggernaut = () => {
    sound.playMenuClick();
    setIsJuggernautVictoryOpen(false);
    setIsJuggernautCombatActive(false);
    if (engineRef.current) {
      engineRef.current.stopJuggernautCombat();
      engineRef.current.stopRace();
    }
    setAppState('MAIN_MENU');
  };

  const handleStartConvoyGuardian = (variant: ConvoyVariant = 'SAVIOUR') => {
    sound.playMenuClick();
    setIsConvoyModalOpen(false);
    setIsConvoyVictoryOpen(false);
    setIsConvoyActive(true);
    setConvoyVariant(variant);
    setAppState('RACING');
    setIsResultsOpen(false);
    setIsGameOverOpen(false);
    setIsPauseOpen(false);

    if (engineRef.current) {
      engineRef.current.resumeGame();
      engineRef.current.startConvoyGuardian(currentShipId || 'VR-0001', variant);
    }
  };

  const handleReplayConvoy = () => {
    sound.playMenuClick();
    setIsConvoyVictoryOpen(false);
    if (engineRef.current) {
      engineRef.current.resumeGame();
      engineRef.current.startConvoyGuardian(currentShipId || 'VR-0001', convoyVariant);
    }
  };

  const handleReturnFromConvoy = () => {
    sound.playMenuClick();
    setIsConvoyVictoryOpen(false);
    setIsConvoyActive(false);
    if (engineRef.current) {
      engineRef.current.stopConvoyGuardian();
      engineRef.current.stopRace();
    }
    setAppState('MAIN_MENU');
  };

  const handleReturnToLobby = () => {
    setIsPauseOpen(false);
    setIsGameOverOpen(false);
    setIsResultsOpen(false);
    setIsFinalCollapseResultsOpen(false);
    setFinalCollapseStats(null);
    if (isJuggernautCombatActive) {
      setIsJuggernautCombatActive(false);
      setIsJuggernautVictoryOpen(false);
      engineRef.current?.stopJuggernautCombat();
    }
    if (isConvoyActive) {
      setIsConvoyActive(false);
      setIsConvoyVictoryOpen(false);
      engineRef.current?.stopConvoyGuardian();
    }
    setAppState('MAIN_MENU');
    setIntroTelemetry(null);
    setCountdown(null);

    if (engineRef.current) {
      engineRef.current.resumeGame();
      engineRef.current.stopRace();
    }
  };

  const handleSelectShip = (shipId: string) => {
    setCurrentShipId(shipId);
    setProgression(prev => {
      const updated = { ...prev, selectedShipId: shipId };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setPlayerShip(
        shipId,
        currentColor,
        currentSecondaryColor,
        currentDecal,
        currentUpgrades,
        currentThrusterColor,
        currentCockpitSkin
      );
    }
  };

  const handleSelectColor = (color: string) => {
    setCurrentColor(color);
    setProgression(prev => {
      const updated = { ...prev, primaryColor: color };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setPlayerShip(
        currentShipId,
        color,
        currentSecondaryColor,
        currentDecal,
        currentUpgrades,
        currentThrusterColor,
        currentCockpitSkin
      );
    }
  };

  const handleSelectSecondaryColor = (color: string) => {
    setCurrentSecondaryColor(color);
    setProgression(prev => {
      const updated = { ...prev, secondaryColor: color };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setPlayerShip(
        currentShipId,
        currentColor,
        color,
        currentDecal,
        currentUpgrades,
        currentThrusterColor,
        currentCockpitSkin
      );
    }
  };

  const handleSelectDecal = (decal: ShipDecalType) => {
    setCurrentDecal(decal);
    setProgression(prev => {
      const updated = { ...prev, decal };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setPlayerShip(
        currentShipId,
        currentColor,
        currentSecondaryColor,
        decal,
        currentUpgrades,
        currentThrusterColor,
        currentCockpitSkin
      );
    }
  };

  const handleSelectThrusterColor = (flame: ThrusterFlameColor) => {
    setCurrentThrusterColor(flame);
    setProgression(prev => {
      const updated = { ...prev, thrusterColor: flame };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setPlayerShip(
        currentShipId,
        currentColor,
        currentSecondaryColor,
        currentDecal,
        currentUpgrades,
        flame,
        currentCockpitSkin
      );
    }
  };

  const handleSelectCockpitSkin = (skin: CockpitSkin) => {
    setCurrentCockpitSkin(skin);
    setProgression(prev => {
      const updated = { ...prev, cockpitSkin: skin };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setPlayerShip(
        currentShipId,
        currentColor,
        currentSecondaryColor,
        currentDecal,
        currentUpgrades,
        currentThrusterColor,
        skin
      );
    }
  };

  const handlePurchaseUpgrade = (type: UpgradeType, cost: number) => {
    const currentLvl = (currentUpgrades as any)[type] || 0;
    const nextLvl = currentLvl + 1;
    const updatedUpgrades = { ...currentUpgrades, [type]: nextLvl };

    setCurrentUpgrades(updatedUpgrades);
    setProgression(prev => {
      const updated = {
        ...prev,
        credits: prev.credits - cost,
        upgrades: updatedUpgrades,
      };
      progressionStorage.save(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.localUpgrades = updatedUpgrades;
    }
  };

  const handleUpdateBeamCustomization = (customization: BeamCustomization) => {
    setProgression(prev => {
      const updated = { ...prev, beamCustomization: customization };
      progressionStorage.save(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setBeamCustomization(customization);
    }
  };

  const handlePurchaseBeamUpgrade = (upgradeKey: keyof BeamUpgrades, cost: number) => {
    const currentBeamUpgrades = progression.beamUpgrades || DEFAULT_BEAM_UPGRADES;
    const currentLvl = currentBeamUpgrades[upgradeKey] || 0;
    const nextLvl = currentLvl + 1;
    const updatedBeamUpgrades = { ...currentBeamUpgrades, [upgradeKey]: nextLvl };

    setProgression(prev => {
      const updated = {
        ...prev,
        credits: prev.credits - cost,
        beamUpgrades: updatedBeamUpgrades,
      };
      progressionStorage.save(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.setBeamUpgrades(updatedBeamUpgrades);
    }
  };

  const handleUnlockShip = (shipId: string, cost: number) => {
    setProgression(prev => {
      const updated = {
        ...prev,
        credits: prev.credits - cost,
        unlockedShipIds: [...prev.unlockedShipIds, shipId],
        selectedShipId: shipId,
      };
      progressionStorage.save(updated);
      return updated;
    });
    handleSelectShip(shipId);
  };

  const handleUpdateName = (newName: string) => {
    setProgression(prev => {
      const updated = { ...prev, playerName: newName };
      progressionStorage.save(updated);
      return updated;
    });
  };

  return (
    <div className="relative w-screen h-screen bg-[#030712] overflow-hidden select-none">
      {/* 3D Three.js WebGL Canvas Stage */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />

      {/* Main Menu View */}
      {appState === 'MAIN_MENU' && (
        <MainMenu
          playerName={progression.playerName}
          onUpdatePlayerName={handleUpdateName}
          onQuickMatch={handleQuickMatch}
          onOpenCreateRoom={handleCreateRoom}
          onOpenJoinRoom={handleJoinRoom}
          onOpenMultiplayer={() => setIsMultiplayerModalOpen(true)}
          onOpenAIRace={() => setIsAIRaceModalOpen(true)}
          onOpenGameModes={() => setIsGameModesOpen(true)}
          onOpenGarage={() => setAppState('GARAGE')}
          onOpenMissions={() => setIsMissionsOpen(true)}
          onOpenLeaderboards={() => setIsLeaderboardsOpen(true)}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenSettings={() => {
            setSettingsTab('COSMIC_TELEMETRY');
            setIsSettingsOpen(true);
          }}
          onOpenSpaceHub={() => setIsSpaceHubOpen(true)}
          onOpenStory={() => setIsStoryOpen(true)}
          onOpenIntoUnknown={() => setIsIntoUnknownOpen(true)}
          onOpenChampionship={() => setIsChampionshipOpen(true)}
          onOpenTrackBuilder={() => setIsTrackBuilderOpen(true)}
          onOpenSkillTree={() => setIsSkillTreeOpen(true)}
          onOpenReplay={() => setIsReplayOpen(true)}
          onOpenLivery={() => setIsLiveryOpen(true)}
          onStartHyperspaceGauntlet={() => {
            hyperspaceGauntlet.start();
            handleStartAIRace({
              mode: 'DEBRIS_SURVIVAL',
              difficulty: 'ACE',
              trackId: 'quantum_highway',
              botCount: 3,
              laps: 99,
            });
          }}
          onOpenSynthStudio={() => setIsSynthStudioOpen(true)}
          onOpenJuggernautCombat={() => setIsJuggernautModalOpen(true)}
          onStartJuggernaut={() => setIsJuggernautModalOpen(true)}
          onOpenConvoyGuardian={() => setIsConvoyModalOpen(true)}
          credits={progression.credits}
          playerLevel={progression.level}
          ping={ping}
          isConnected={isConnected}
          currentShipId={currentShipId}
          onPlayNormalRace={() => {
            const activeMode = gameMode || 'NEON_CIRCUIT';
            handleStartAIRace({
              mode: activeMode,
              difficulty: 'ACE',
              trackId: 'circuit_alpha',
              botCount: 4,
              laps: 2,
            });
          }}
          onStartGameMode={mode => {
            const targetMode: GameMode = mode === 'TIME_TRIAL' ? 'QUANTUM_TIME_TRIAL' : 'DEBRIS_SURVIVAL';
            setGameMode(targetMode);
            handleStartAIRace({
              mode: targetMode,
              difficulty: 'ACE',
              trackId: mode === 'TIME_TRIAL' ? 'quantum_highway' : 'circuit_alpha',
              botCount: mode === 'TIME_TRIAL' ? 0 : 4,
              laps: mode === 'TIME_TRIAL' ? 3 : 5,
            });
          }}
        />
      )}

      {/* Garage / Workshop View */}
      {appState === 'GARAGE' && (
        <GarageView
          currentShipId={currentShipId}
          currentColor={currentColor}
          currentSecondaryColor={currentSecondaryColor}
          currentDecal={currentDecal}
          currentThrusterColor={currentThrusterColor}
          currentCockpitSkin={currentCockpitSkin}
          currentUpgrades={currentUpgrades}
          currentBeamCustomization={progression.beamCustomization || DEFAULT_BEAM_CUSTOMIZATION}
          currentBeamUpgrades={progression.beamUpgrades || DEFAULT_BEAM_UPGRADES}
          unlockedShips={progression.unlockedShipIds}
          credits={progression.credits}
          playerLevel={progression.level}
          pilotName={progression.playerName}
          onUpdatePilotName={handleUpdateName}
          onSelectShip={handleSelectShip}
          onSelectColor={handleSelectColor}
          onSelectSecondaryColor={handleSelectSecondaryColor}
          onSelectDecal={handleSelectDecal}
          onSelectThrusterColor={handleSelectThrusterColor}
          onSelectCockpitSkin={handleSelectCockpitSkin}
          onPurchaseUpgrade={handlePurchaseUpgrade}
          onUpdateBeamCustomization={handleUpdateBeamCustomization}
          onPurchaseBeamUpgrade={handlePurchaseBeamUpgrade}
          onUnlockShip={handleUnlockShip}
          onBack={() => setAppState('MAIN_MENU')}
        />
      )}

      {/* Multiplayer Lobby Room View */}
      {appState === 'LOBBY' && currentRoom && (
        <LobbyView
          room={currentRoom}
          playerId={networkClient.playerId}
          onSetReady={ready => networkClient.setReady(ready)}
          onStartRace={() => networkClient.startRace()}
          onAddBot={() => networkClient.addBot()}
          onSelectTrack={t => networkClient.setTrack(t)}
          onLeaveRoom={() => {
            networkClient.leaveRoom();
            setAppState('MAIN_MENU');
          }}
          onOpenGarage={() => setAppState('GARAGE')}
          onToggleTeam={() => {
            const me = currentRoom.players?.[networkClient.playerId];
            const nextTeam = me?.team === 'ALPHA' ? 'OMEGA' : 'ALPHA';
            networkClient.setTeam(nextTeam);
          }}
          onToggleRole={() => {
            const me = currentRoom.players?.[networkClient.playerId];
            networkClient.setRole(!me?.isSpectator);
          }}
          onUpdateSettings={settings => {
            networkClient.updateSettings(settings);
          }}
        />
      )}

      {/* Dedicated Juggernaut Space Combat HUD */}
      {appState === 'RACING' && isJuggernautCombatActive && juggernautCombatTelemetry && (
        <JuggernautHUD
          telemetry={juggernautCombatTelemetry}
          onTriggerAbility={(id) => engineRef.current?.triggerJuggernautAbility(id)}
          onTogglePause={handleTogglePause}
          onJoystickInput={(input) => engineRef.current?.handleJuggernautJoystick(input)}
          onFirePress={(isFiring) => engineRef.current?.handleJuggernautFire(isFiring)}
          onBoostPress={(isBoosting) => engineRef.current?.handleJuggernautBoost(isBoosting)}
          onDirectionalInput={(input) => engineRef.current?.handleJuggernautDirectionalInput(input)}
        />
      )}

      {/* Dedicated Convoy Guardian Escort HUD */}
      {appState === 'RACING' && isConvoyActive && convoyTelemetry && (
        <ConvoyHUD
          telemetry={convoyTelemetry}
          onTogglePause={handleTogglePause}
          onJoystickInput={(inp) => engineRef.current?.handleConvoyJoystick(inp)}
          onFirePress={(firing) => engineRef.current?.handleConvoyFire(firing)}
          onBoostPress={(boosting) => engineRef.current?.handleConvoyBoost(boosting)}
          onShieldPress={(shielding) => engineRef.current?.handleConvoyShield(shielding)}
          onEMPPress={() => engineRef.current?.handleConvoyEMP()}
          onVariantAbility={() => engineRef.current?.handleConvoyVariantAbility()}
        />
      )}

      {/* In-Game Heads Up Display (HUD) */}
      {appState === 'RACING' && !isJuggernautCombatActive && !isConvoyActive && !bossTelemetry?.isActive && (
        <RaceHUD
          speed={speed}
          boost={boost}
          currentLap={currentLap}
          totalLaps={totalLaps}
          rank={rank}
          totalPlayers={totalPlayers}
          checkpoint={checkpoint}
          totalCheckpoints={totalCheckpoints}
          countdown={countdown}
          activeEvent={activeEvent}
          hazardHitMessage={hazardHitMessage}
          shortcutMessage={shortcutMessage}
          powerUps={powerUps}
          hullHealth={hullHealth}
          sessionCredits={sessionCredits}
          distanceMeters={distanceMeters}
          milestoneMessage={milestoneMessage}
          isWrongWay={isWrongWay}
          destroyedMessage={destroyedMessage}
          respawnTimeRemaining={respawnTimeRemaining}
          currentLapMs={currentLapMs}
          bestLapMs={bestLapMs}
          cameraMode={cameraMode}
          gameMode={gameMode}
          trackId={engineRef.current?.trackId || 'circuit_alpha'}
          damageZones={damageZones}
          isSpectator={engineRef.current?.isSpectator}
          spectatorTargetName={spectatorTargetName}
          coreTemperature={coreTemperature}
          beamTelemetry={beamTelemetry}
          junctionTelemetry={junctionTelemetry}
          modeTelemetry={modeTelemetry}
          singularityTelemetry={singularityTelemetry}
          missileTelemetry={missileTelemetry}
          activeShieldTelemetry={activeShieldTelemetry}
          minimapTelemetry={minimapTelemetry}
          onFireMissile={() => {
            engineRef.current?.firePlayerMissile();
          }}
          onActivateShield={() => {
            engineRef.current?.activatePlayerShield();
          }}
          onToggleMinimapMode={() => {
            engineRef.current?.toggleMinimapMode();
          }}
          onZoomInMinimap={() => {
            engineRef.current?.zoomInMinimap();
          }}
          onZoomOutMinimap={() => {
            engineRef.current?.zoomOutMinimap();
          }}
          onResetMinimapZoom={() => {
            engineRef.current?.resetMinimapZoom();
          }}
          onToggleMinimapExpand={() => {
            engineRef.current?.toggleMinimapExpand();
          }}
          onSelectRoute={direction => {
            if (engineRef.current) {
              engineRef.current.input.selectRouteDirection = direction;
              const ok = engineRef.current.junctionManager.selectRouteByDirection(direction);
              if (ok) {
                sound.playRouteSelected();
                if (engineRef.current.junctionManager.activeJunctionTelemetry) {
                  setJunctionTelemetry({ ...engineRef.current.junctionManager.activeJunctionTelemetry });
                }
              }
            }
          }}
          onCommitRoute={() => {
            if (engineRef.current) {
              engineRef.current.junctionManager.commitRoute();
              sound.playMenuClick();
              if (engineRef.current.junctionManager.activeJunctionTelemetry) {
                setJunctionTelemetry({ ...engineRef.current.junctionManager.activeJunctionTelemetry });
              }
            }
          }}
          onNextSpectatorTarget={() => engineRef.current?.cycleSpectatorTarget()}
          onTogglePause={handleTogglePause}
          onToggleCamera={() => {
            if (engineRef.current) {
              const m = engineRef.current.toggleCameraMode();
              setCameraMode(m);
            }
          }}
          onToggleWholeBlackHoleCamera={() => {
            if (engineRef.current) {
              const m = engineRef.current.toggleWholeBlackHoleCamera();
              setCameraMode(m);
            }
          }}
          cosmicPairTelemetry={cosmicPairTelemetry}
          quantumCountdownTelemetry={quantumCountdownTelemetry}
          activeCosmicBiome={activeCosmicBiome}
          activeRouteBranchName={activeRouteBranchName}
          onSetCountdownDuration={sec => {
            engineRef.current?.setQuantumCountdownDuration(sec);
          }}
          onCycleCosmicBiome={() => {
            if (engineRef.current) {
              const b = engineRef.current.cycleCosmicBiome();
              setActiveCosmicBiome(COSMIC_BIOMES[b]);
            }
          }}
          onToggleCountdownMute={() => {
            if (engineRef.current) {
              const muted = engineRef.current.toggleQuantumCountdownMute();
              setIsCountdownMuted(muted);
            }
          }}
          isCountdownMuted={isCountdownMuted}
          blackHoleCinematicTelemetry={blackHoleCinematicTelemetry}
          onTriggerCollapse={() => engineRef.current?.triggerFinalCollapseImmediately()}
          onJumpToEvent={(idx) => engineRef.current?.jumpToFinalCollapseEvent(idx)}
          onInputChange={inp => {
            if (engineRef.current) {
              if (inp.fireMissile) {
                engineRef.current.firePlayerMissile();
              }
              if (inp.activateShield) {
                engineRef.current.activatePlayerShield();
              }
              engineRef.current.input = { ...engineRef.current.input, ...inp };
            }
          }}
          onRecover={() => {
            if (engineRef.current) {
              engineRef.current.input.recover = true;
            }
          }}
          isAIRaceActive={isAIRaceActive}
          isAIDebugOpen={isAIDebugOpen}
          isIntroActive={introTelemetry?.isActive ?? false}
          onToggleAIDebug={() => {
            if (engineRef.current) {
              const next = engineRef.current.toggleAIDebug();
              setIsAIDebugOpen(next);
            }
          }}
          photoModeActive={isPhotoModeOpen}
          onOpenPhotoMode={() => {
            engineRef.current?.enterPhotoMode();
            setIsPhotoModeOpen(true);
          }}
          tacticalTelemetry={tacticalTelemetry}
          onActivateTacticalModule={() => {
            engineRef.current?.activateTacticalModule();
          }}
          onCycleTacticalModule={() => {
            engineRef.current?.cycleTacticalModule();
          }}
          radioTelemetry={radioTelemetry}
          onNextRadioStation={() => {
            cosmicRadio.nextChannel();
          }}
          onToggleRadioPlay={() => {
            cosmicRadio.togglePlay();
          }}
          ghostTelemetry={ghostTelemetry}
          cosmicWeatherTelemetry={cosmicWeatherTelemetry}
          rivalChatter={rivalChatter}
          bossTelemetry={bossTelemetry}
          juggernautTelemetry={juggernautTelemetry}
        />
      )}

      {/* Mode-Specific 9-Phase Cinematic Introduction Overlay for All 20 Game Modes */}
      {appState === 'RACING' && introTelemetry && introTelemetry.isActive && (
        <CinematicIntroOverlay
          telemetry={introTelemetry}
          onSkip={() => engineRef.current?.skipIntro()}
        />
      )}

      {/* 20-Mode Unique Real-Time Finish Cinematic Overlay */}
      {finishTelemetry && finishTelemetry.isActive && (
        <FinishCinematicOverlay
          telemetry={finishTelemetry}
          onContinue={() => engineRef.current?.skipFinishCinematic()}
        />
      )}

      {/* Mode 21 — Black Hole / The Final Collapse cinematic HUD & Catastrophe FX */}
      {gameMode === 'BLACK_HOLE' && blackHoleCinematicTelemetry && (
        <>
          {/* Planetary collision flash effect */}
          {blackHoleCinematicTelemetry.event === 'PLANETARY_COLLISION' && blackHoleCinematicTelemetry.eventElapsed < 1.8 && (
            <div
              className="pointer-events-none fixed inset-0 z-[70] bg-white transition-opacity duration-700"
              style={{
                opacity: Math.max(0, 0.7 - (blackHoleCinematicTelemetry.eventElapsed / 1.8)),
              }}
            />
          )}

          {/* Final Singularity Implosion Flash */}
          {(blackHoleCinematicTelemetry.event === 'FINAL_FLASH' || (blackHoleCinematicTelemetry.event === 'FINAL_COLLAPSE' && blackHoleCinematicTelemetry.eventElapsed > 4 && blackHoleCinematicTelemetry.eventElapsed < 5.5)) && (
            <div
              className="pointer-events-none fixed inset-0 z-[75] bg-white transition-opacity duration-1000"
              style={{
                opacity: 0.85,
              }}
            />
          )}

          {/* Colored Plasma Shockwave & Singularity Implosion — No white flashbang, pure sci-fi colored energy */}
          {(blackHoleCinematicTelemetry.event === 'FLASHBANG' ||
            blackHoleCinematicTelemetry.event === 'COSMIC_LIGHT_EVENT') && (
            <div
              className="fixed inset-0 z-[98] pointer-events-none flex flex-col items-center justify-center transition-opacity duration-700 bg-gradient-to-t from-black via-purple-950/40 to-black"
              style={{
                boxShadow: 'inset 0 0 120px rgba(217, 70, 239, 0.6), inset 0 0 80px rgba(6, 182, 212, 0.6)',
              }}
            >
              <div className="flex flex-col items-center text-center p-6 rounded-3xl bg-black/80 border border-purple-500/70 backdrop-blur-xl shadow-[0_0_60px_rgba(168,85,247,0.7)] animate-pulse">
                <span className="text-[11px] font-mono font-black text-rose-400 tracking-[0.3em] uppercase mb-1">
                  CRITICAL TIDAL DISRUPTION
                </span>
                <div className="text-2xl sm:text-4xl font-ui font-black uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-amber-400">
                  FINAL GRAVITATIONAL COLLAPSE
                </div>
                <div className="mt-2 text-xs font-mono font-bold text-cyan-300 tracking-wider">
                  PLASMA DETONATIONS ACTIVE // EMERGENCY ESCAPE VECTOR ARMED
                </div>
              </div>
            </div>
          )}

          {/* Phase 14: Survival Confirmed Cinematic Overlay */}
          {blackHoleCinematicTelemetry.event === 'SURVIVAL_RESULTS' && (
            <div className="fixed inset-0 z-[90] pointer-events-none flex flex-col items-center justify-center p-6 text-center select-none animate-fadeIn">
              <div className="rounded-2xl border-2 border-emerald-400 bg-black/85 p-8 max-w-lg w-full shadow-[0_0_80px_rgba(16,185,129,0.6)] backdrop-blur-md">
                <div className="inline-block px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/60 text-emerald-400 font-mono text-xs font-black tracking-[0.25em] uppercase mb-3">
                  ✓ EVACUATION PROTOCOL COMPLETE
                </div>
                <h1 className="text-3xl sm:text-5xl font-ui font-black uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-white to-cyan-300 drop-shadow-[0_0_20px_rgba(16,185,129,0.8)]">
                  SURVIVAL CONFIRMED
                </h1>
                <div className="mt-3 font-mono text-lg font-black text-emerald-300 tracking-widest uppercase">
                  EVACUATION SUCCESSFUL
                </div>
                <div className="mt-1 font-mono text-xs font-bold text-slate-300 tracking-wider">
                  PILOT STATUS: ALIVE // SHELTER: SECURE
                </div>
                <div className="mt-5 border-t border-emerald-500/30 pt-4 grid grid-cols-2 gap-3 text-left font-mono text-xs text-slate-300">
                  <div>DOCKING BAY: <span className="text-white font-black">BAY 07</span></div>
                  <div>HULL INTEGRITY: <span className="text-emerald-400 font-black">100% INTACT</span></div>
                  <div>SINGULARITY: <span className="text-cyan-400 font-black">DISSIPATED</span></div>
                  <div>STATUS: <span className="text-emerald-300 font-black">INVULNERABLE</span></div>
                </div>
              </div>
            </div>
          )}

          {/* Rebuilding Map Message & Holographic Reconstruction Screen */}
          {blackHoleCinematicTelemetry.event === 'REBUILDING_MAP' && (
            <div className="fixed inset-0 z-[98] bg-slate-950 flex flex-col items-center justify-center p-6 text-white font-mono select-none">
              {/* Subtle grid backdrop */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.18),transparent_75%)] pointer-events-none" />
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#0e749015_1px,transparent_1px),linear-gradient(to_bottom,#0e749015_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] pointer-events-none" />

              <div className="relative z-10 flex flex-col items-center max-w-md w-full text-center">
                {/* Tech loader spinner */}
                <div className="relative w-20 h-20 mb-6 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                  <div className="absolute inset-2 rounded-full border-4 border-purple-500/20 border-b-purple-400 animate-spin [animation-direction:reverse]" />
                  <div className="w-8 h-8 rounded-full bg-cyan-400/20 animate-pulse flex items-center justify-center">
                    <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  </div>
                </div>

                <div className="inline-block px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-[10px] font-bold tracking-[0.25em] uppercase mb-3">
                  Singularity Dissipated // Space-Time Recovery
                </div>

                <h1 className="text-3xl sm:text-4xl font-ui font-black uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-purple-300 drop-shadow-[0_0_25px_rgba(6,182,212,0.6)]">
                  REBUILDING MAP...
                </h1>

                <p className="mt-2 text-xs text-slate-400 tracking-wider">
                  Reconstructing track geometry, sector coordinates & quantum anchors
                </p>

                {/* Progress bar */}
                <div className="w-full mt-6 bg-slate-900 border border-cyan-500/30 rounded-full h-2.5 overflow-hidden p-0.5">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 via-sky-400 to-emerald-400 rounded-full transition-all duration-200"
                    style={{
                      width: `${Math.min(100, Math.round((blackHoleCinematicTelemetry.eventElapsed / 3.5) * 100))}%`,
                    }}
                  />
                </div>

                <div className="w-full flex justify-between text-[10px] text-cyan-400 mt-2 font-mono">
                  <span>ORBITAL RESTRUCTURING</span>
                  <span>{Math.min(100, Math.round((blackHoleCinematicTelemetry.eventElapsed / 3.5) * 100))}%</span>
                </div>

                {/* Status messages stream */}
                <div className="mt-5 w-full bg-black/70 border border-cyan-500/20 rounded-xl p-3 text-left font-mono text-[11px] text-slate-300 space-y-1.5 shadow-inner">
                  <div className="flex items-center gap-2 text-emerald-400">
                    <span>✓</span> <span>Evacuation shelter structural integrity: 100%</span>
                  </div>
                  <div className="flex items-center gap-2 text-emerald-400">
                    <span>✓</span> <span>Cosmic singularity shockwave safely dissipated</span>
                  </div>
                  <div className="flex items-center gap-2 text-cyan-300 animate-pulse">
                    <span>⚡</span> <span>Synthesizing orbital highway & race telemetry...</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Spaghettification Gravitational Glitch / Vignette */}
          {blackHoleCinematicTelemetry.event === 'SPAGHETTIFICATION' && (
            <div className="pointer-events-none fixed inset-0 z-[55] shadow-[inset_0_0_120px_rgba(239,68,68,0.45)] animate-pulse" />
          )}

          {/* Pure Full-Screen Cinematic Cutscene Title Badges (Only during dramatic camera cutscenes, never overlapping race HUD) */}
          {(blackHoleCinematicTelemetry.event === 'FINAL_SINGULARITY' ||
            blackHoleCinematicTelemetry.event === 'AFTERMATH_START' ||
            blackHoleCinematicTelemetry.event === 'WORLD_COLLAPSE' ||
            blackHoleCinematicTelemetry.event === 'TOWER_REVEAL' ||
            blackHoleCinematicTelemetry.event === 'PLANETARY_COLLISION' ||
            blackHoleCinematicTelemetry.event === 'SILENCE' ||
            blackHoleCinematicTelemetry.event === 'TOWER_REVEAL_RETURN' ||
            blackHoleCinematicTelemetry.event === 'SHIP_FINAL_SHOT') && (
            <div className="fixed inset-x-0 top-12 z-[65] flex flex-col items-center px-4 pointer-events-none animate-fadeIn">
              <div className="flex flex-col items-center text-center drop-shadow-[0_0_35px_rgba(0,0,0,0.9)]">
                <div className="inline-block px-4 py-1.5 rounded-full bg-black/85 border border-cyan-500/60 text-cyan-300 font-mono text-xs font-black tracking-[0.25em] uppercase mb-1 shadow-lg">
                  {blackHoleCinematicTelemetry.title}
                </div>
                {blackHoleCinematicTelemetry.subtitle && (
                  <p className="font-mono text-xs text-slate-200 tracking-wider bg-black/60 px-3 py-1 rounded-full border border-slate-700/50">
                    {blackHoleCinematicTelemetry.subtitle}
                  </p>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* Extended Path In-Race Cinematic Events & Sector HUD */}
      {appState === 'RACING' && (
        <CinematicEventHUD
          cinematicState={cinematicState}
          pathTelemetry={pathTelemetry}
          isRacing={appState === 'RACING'}
        />
      )}

      {/* AI Tactical Intelligence Telemetry HUD Overlay */}
      {appState === 'RACING' && isAIRaceActive && isAIDebugOpen && (
        <AIDebugOverlay
          telemetry={aiDebugTelemetry}
          onClose={() => {
            engineRef.current?.toggleAIDebug(false);
            setIsAIDebugOpen(false);
          }}
        />
      )}

      {/* Arcade Collision Feedback HUD */}
      {appState === 'RACING' && <CollisionHUD feedback={collisionFeedback} />}

      {/* Mode 21 — The Final Collapse Failure Cinematic Overlay (Exclusive to Mode 21 Submode 10) */}
      {gameMode === 'BLACK_HOLE' && blackHoleCinematicTelemetry?.evacuation && (
        <FinalCollapseFailureOverlay evacuation={blackHoleCinematicTelemetry.evacuation} />
      )}

      {/* Mode 21 — The Final Collapse Results Modal (16 exact values) */}
      {isFinalCollapseResultsOpen && finalCollapseStats && (
        <FinalCollapseResultsModal
          stats={finalCollapseStats}
          onRestart={handleRestartRace}
          onReturnToLobby={handleReturnToLobby}
        />
      )}

      {/* Post-Race Results Modal */}
      {isResultsOpen && (
        <ResultsModal
          results={resultsData}
          localPlayerId={isAIRaceActive ? 'player' : networkClient.playerId}
          onRestart={handleRestartRace}
          onReturnToLobby={handleReturnToLobby}
          earnedCredits={earnedCredits}
          gameMode={gameMode}
          onNextChampionshipStage={handleProceedToNextChampionshipStage}
        />
      )}

      {/* Game Over / Vessel Destroyed Modal */}
      {isGameOverOpen && (
        <GameOverModal
          stats={gameOverStats}
          onRestart={handleRestartRace}
          onReturnToLobby={handleReturnToLobby}
        />
      )}

      {/* In-Game Pause Modal */}
      {isPauseOpen && (
        <PauseModal
          isOpen={isPauseOpen}
          onResume={handleTogglePause}
          onRestart={handleRestartRace}
          onReturnToLobby={handleReturnToLobby}
          onOpenSettings={(tab) => {
            setSettingsTab(tab || 'COSMIC_TELEMETRY');
            setIsSettingsOpen(true);
          }}
        />
      )}

      {/* Settings & Audio Modal */}
      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          initialTab={settingsTab}
          currentCameraMode={cameraMode}
          onSelectCameraMode={m => {
            setCameraMode(m);
            engineRef.current?.setCameraMode(m);
          }}
          cameraShakeEnabled={cameraShakeEnabled}
          onToggleCameraShake={en => {
            setCameraShakeEnabled(en);
            engineRef.current?.setCameraShakeEnabled(en);
          }}
          graphicsQuality={graphicsQuality}
          onSelectGraphicsQuality={q => {
            setGraphicsQuality(q);
            engineRef.current?.setGraphicsQuality(q);
          }}
          collisionConfig={collisionConfig}
          onUpdateCollisionConfig={cfg => {
            setCollisionConfig(prev => (prev ? { ...prev, ...cfg } : prev));
            engineRef.current?.setCollisionConfig(cfg);
          }}
        />
      )}

      {/* Missions & Quests Modal */}
      {isMissionsOpen && (
        <MissionsModal
          isOpen={isMissionsOpen}
          onClose={() => setIsMissionsOpen(false)}
          missions={progression.dailyMissions}
          achievements={progression.achievements}
          credits={progression.credits}
          playerLevel={progression.level}
          xp={progression.xp}
          onClaimMission={id => {
            const m = progression.dailyMissions.find(x => x.id === id);
            if (m) {
              setProgression(prev => {
                const updatedMissions = prev.dailyMissions.map(x =>
                  x.id === id ? { ...x, claimed: true } : x
                );
                const updated = {
                  ...prev,
                  credits: prev.credits + m.rewardCredits,
                  dailyMissions: updatedMissions,
                };
                progressionStorage.save(updated);
                return updated;
              });
            }
          }}
          onClaimAchievement={id => {
            const a = progression.achievements.find(x => x.id === id);
            if (a) {
              setProgression(prev => {
                const updatedAchs = prev.achievements.map(x =>
                  x.id === id ? { ...x, unlocked: true } : x
                );
                const updated = {
                  ...prev,
                  credits: prev.credits + a.rewardCredits,
                  achievements: updatedAchs,
                };
                progressionStorage.save(updated);
                return updated;
              });
            }
          }}
        />
      )}

      {/* Global Leaderboards Modal */}
      {isLeaderboardsOpen && (
        <LeaderboardsModal
          isOpen={isLeaderboardsOpen}
          onClose={() => setIsLeaderboardsOpen(false)}
          entries={progression.leaderboards}
          currentTrackId={engineRef.current?.trackId || 'circuit_alpha'}
          userBestLap={
            ((progression.stats as any).bestLapTime || 0) > 0
              ? `${(((progression.stats as any).bestLapTime || 0) / 1000).toFixed(3)}s`
              : '--:--.---'
          }
          onSelectTrack={t => {
            if (engineRef.current) engineRef.current.setTrack(t);
          }}
        />
      )}

      {/* Pilot Profile Dossier Modal */}
      {isProfileOpen && (
        <ProfileModal
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          progression={progression}
          onUpdateName={handleUpdateName}
        />
      )}

      {/* INTO UNKNOWN — seven frontier concepts, launched through existing gameplay foundations */}
      <IntoUnknownModal
        isOpen={isIntoUnknownOpen}
        onClose={() => setIsIntoUnknownOpen(false)}
        onStartMode={mode => {
          setIsIntoUnknownOpen(false);
          setGameMode(mode);
          handleStartAIRace({
            mode,
            difficulty: mode === 'RIVAL_DUEL' ? 'ELITE' : 'ACE',
            trackId:
              mode === 'WORMHOLE_EXPRESS' || mode === 'PLASMA_STORM' || mode === 'ENERGY_HEIST'
                ? 'quantum_highway'
                : mode === 'DEBRIS_SURVIVAL'
                  ? 'asteroid_run'
                  : mode === 'GRAVITY_FREE'
                    ? 'nebula_rift'
                    : 'circuit_alpha',
            botCount:
              mode === 'RIVAL_DUEL'
                ? 1
                : mode === 'GRAVITY_FREE' || mode === 'ENERGY_HEIST' || mode === 'DEBRIS_SURVIVAL'
                  ? 3
                  : 4,
            laps: mode === 'DEBRIS_SURVIVAL' ? 99 : mode === 'GRAVITY_FREE' ? 2 : 3,
          });
        }}
      />

      {/* Game Mode Select Modal */}
      {isGameModesOpen && (
        <GameModeSelectModal
          isOpen={isGameModesOpen}
          onClose={() => setIsGameModesOpen(false)}
          onStartConfiguredRace={config => {
            setGameMode(config.mode);
            handleStartAIRace({
              mode: config.mode,
              difficulty: config.difficulty,
              trackId: config.trackId,
              botCount: config.botCount,
              laps: config.laps,
              ...(config.blackHoleSubmode
                ? { blackHoleSubmode: config.blackHoleSubmode }
                : {}),
              ...(config.initialCameraMode
                ? { initialCameraMode: config.initialCameraMode }
                : {}),
            });
          }}
          onSelectMode={mode => {
            setGameMode(mode);
            handleStartAIRace({
              mode,
              difficulty: 'ACE',
              trackId: 'circuit_alpha',
              botCount: 4,
              laps: 2,
            });
          }}
        />
      )}

      {/* Solo AI Battle Modal */}
      {isAIRaceModalOpen && (
        <AIRaceModal
          isOpen={isAIRaceModalOpen}
          onClose={() => setIsAIRaceModalOpen(false)}
          onStartAIRace={handleStartAIRace}
        />
      )}

      {/* Space Station Hub Modal */}
      {isSpaceHubOpen && (
        <SpaceHubModal
          onClose={() => setIsSpaceHubOpen(false)}
          pilotName={progression.playerName}
          credits={progression.credits}
          level={progression.level}
          onNavigateTo={view => {
            setIsSpaceHubOpen(false);
            if (view === 'GARAGE') setAppState('GARAGE');
            else if (view === 'MODE_SELECT') setIsGameModesOpen(true);
            else if (view === 'MISSIONS') setIsMissionsOpen(true);
            else if (view === 'STORY') setIsStoryOpen(true);
            else if (view === 'LEADERBOARDS') setIsLeaderboardsOpen(true);
            else if (view === 'PROFILE') setIsProfileOpen(true);
          }}
        />
      )}

      {/* Cosmic Chronicles & Factions Story Modal */}
      {isStoryOpen && (
        <StoryUniverseModal
          onClose={() => setIsStoryOpen(false)}
          onLaunchMission={(trackId, mode) => {
            setIsStoryOpen(false);
            setGameMode(mode);
            handleStartAIRace({
              mode,
              difficulty: 'ACE',
              trackId,
              botCount: mode === 'DUEL' ? 1 : 5,
              laps: mode === 'DUEL' ? 3 : 2,
            });
          }}
        />
      )}

      {/* Advanced Real-Time Multiplayer Modal */}
      <MultiplayerModal
        isOpen={isMultiplayerModalOpen}
        onClose={() => setIsMultiplayerModalOpen(false)}
        onQuickMatch={mode => {
          setIsMultiplayerModalOpen(false);
          handleQuickMatch(mode);
        }}
        onCreateRoom={(settings, isSpectator, team) => {
          setIsMultiplayerModalOpen(false);
          handleCreateRoom(settings, isSpectator, team);
        }}
        onJoinRoomCode={(code, isSpectator, team) => {
          setIsMultiplayerModalOpen(false);
          handleJoinRoom(code, isSpectator, team);
        }}
      />

      {/* Deep-Space Photo Mode Studio Overlay */}
      {isPhotoModeOpen && (
        <PhotoModeOverlay
          settings={photoModeSettings}
          onUpdateSettings={partial => {
            setPhotoModeSettings(prev => ({ ...prev, ...partial }));
            engineRef.current?.photoModeManager.updateSettings(partial);
          }}
          onCapture={() => {
            engineRef.current?.photoModeManager.captureScreenshot('void-rider-' + Date.now() + '.png');
          }}
          onClose={() => {
            engineRef.current?.exitPhotoMode();
            setIsPhotoModeOpen(false);
          }}
          shipName={currentShipId}
          speedKmh={speed}
        />
      )}

      {/* Galactic Championship Cups Modal */}
      {isChampionshipOpen && (
        <ChampionshipModal
          isOpen={isChampionshipOpen}
          onClose={() => setIsChampionshipOpen(false)}
          onStartStage={(trackId, laps) => {
            setIsChampionshipOpen(false);
            handleStartAIRace({
              mode: 'VOID_CHAMPIONSHIP',
              difficulty: 'ACE',
              trackId: trackId as any,
              botCount: 6,
              laps,
            });
          }}
          playerName={progression.playerName}
          playerLevel={progression.level}
          currentShipId={currentShipId}
          currentShipName={currentShipId}
        />
      )}

      {/* 3D Track Architect & Custom Circuit Builder Modal */}
      {isTrackBuilderOpen && (
        <TrackBuilderModal
          isOpen={isTrackBuilderOpen}
          onClose={() => setIsTrackBuilderOpen(false)}
          onTestDrive={() => {
            setIsTrackBuilderOpen(false);
            handleStartAIRace({
              mode: 'NEON_CIRCUIT',
              difficulty: 'NORMAL',
              trackId: 'circuit_alpha',
              botCount: 3,
              laps: 2,
            });
          }}
        />
      )}

      {/* Replay Theater & TV Broadcast Modal */}
      {isReplayOpen && (
        <ReplayTheaterModal
          isOpen={isReplayOpen}
          onClose={() => setIsReplayOpen(false)}
        />
      )}

      {/* Pilot Skill Tree & Cybernetics Modal */}
      {isSkillTreeOpen && (
        <PilotSkillTreeModal
          isOpen={isSkillTreeOpen}
          onClose={() => setIsSkillTreeOpen(false)}
          playerLevel={progression.level}
        />
      )}

      {/* Ship Livery & Decal Studio Modal */}
      {isLiveryOpen && (
        <LiveryPainterModal
          isOpen={isLiveryOpen}
          onClose={() => setIsLiveryOpen(false)}
          onApplyLivery={(_config) => {
            sound.playGatePowerUp();
          }}
        />
      )}

      {/* Synthwave Sequencer & Audio Studio Modal */}
      {isSynthStudioOpen && (
        <SynthStudioModal
          isOpen={isSynthStudioOpen}
          onClose={() => setIsSynthStudioOpen(false)}
        />
      )}

      {/* JUGGERNAUT SPACE COMBAT — Mode Selection & Role Assignment Modal */}
      <JuggernautModal
        isOpen={isJuggernautModalOpen}
        onClose={() => setIsJuggernautModalOpen(false)}
        onStartMatch={handleStartJuggernautCombat}
        currentShipId={currentShipId}
      />

      {/* JUGGERNAUT SPACE COMBAT — Victory / Defeat Match End Summary Modal */}
      {isJuggernautVictoryOpen && (
        <JuggernautVictoryModal
          stats={juggernautCombatTelemetry?.finalStats || null}
          onReplayMatch={handleReplayJuggernaut}
          onReturnToMainMenu={handleReturnFromJuggernaut}
        />
      )}

      {/* CONVOY GUARDIAN — Escort Mission Briefing Modal */}
      <ConvoyModal
        isOpen={isConvoyModalOpen}
        onClose={() => setIsConvoyModalOpen(false)}
        onStartMission={handleStartConvoyGuardian}
        currentShipName={getShipConfig(currentShipId)?.name || 'Vortex Nemesis'}
      />

      {/* CONVOY GUARDIAN — Victory / Defeat Results Modal */}
      {isConvoyVictoryOpen && (
        <ConvoyVictoryModal
          isOpen={isConvoyVictoryOpen}
          results={convoyTelemetry?.finalStats || null}
          variant={convoyVariant}
          onReplay={handleReplayConvoy}
          onReturnToMenu={handleReturnFromConvoy}
        />
      )}
    </div>
  );
}
